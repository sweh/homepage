<?php
require_once('../config.inc'); seite(__FILE__);

if ($_SESSION["login"] == "true"){ 

$img="../forschung/img/";
$doc="../forschung/doc/";

echo '<center><img src="../forschung/img/mi_publik.png" border="0" align="center"></center>';

$aktion=$_GET["aktion"];
$nr=$_GET["nr"];

switch($aktion){
case("add"):

	if($nr!=''){
		$aktion='edit';
		$abfrage = "SELECT name, datum, beschreibung, anhang, link  from mi_prof_publik where id='$nr'";
		$erg = mysql_query($abfrage);
		(list($name, $datum, $beschreibung, $anhang, $link) = mysql_fetch_row($erg));
//	$date=timestamp_to_date($datum);
	$datuma=explode('-', $datum);
	$datum1=$datuma[2];$datum2=$datuma[1];$datum3=$datuma[0];
	}

?>
	<script type="text/javascript">
	<!--
	function chkFormular()
	{
	if(document.Formular.name.value == "")  {
	alert("Bitte Publikationsnamen eingeben!");
	document.Formular.name.focus();
	return false;
	}

	if(document.Formular.datum3.value.length < 4)  {
	alert("Jahr muss vierstellig sein! (z.B. 2004)");
	document.Formular.datum1.focus();
	return false;
	}

	var chkZ = 1;
	for(i=0;i<document.Formular.datum1.value.length;++i)
	if(document.Formular.datum1.value.charAt(i) < "0"
	|| document.Formular.datum1.value.charAt(i) > "9")
		chkZ = -1;
	if(chkZ == -1) {
	alert("Datum (Tag) ist keine Zahl!");
	document.Formular.datum1.focus();
	return false;
	}

	var chkZ = 1;
	for(i=0;i<document.Formular.datum2.value.length;++i)
	if(document.Formular.datum2.value.charAt(i) < "0"
	|| document.Formular.datum2.value.charAt(i) > "9")
		chkZ = -1;
	if(chkZ == -1) {
	alert("Datum (Monat) keine Zahl!");
	document.Formular.datum2.focus();
	return false;
	}

	var chkZ = 1;
	for(i=0;i<document.Formular.datum3.value.length;++i)
	if(document.Formular.datum3.value.charAt(i) < "0"
	|| document.Formular.datum3.value.charAt(i) > "9")
		chkZ = -1;
	if(chkZ == -1) {
	alert("Datum (Jahr) keine Zahl!");
	document.Formular.datum3.focus();
	return false;
	}
	}
	-->
	</script>
<?php

if($link!=''){$link=substr($link,7);}

echo '
	<form name="Formular" action="?aktion='.$aktion.'2&nr='.$nr.'" method="POST" enctype=multipart/form-data onSubmit="return chkFormular()">
	<center>
	<table border="0" width="80%" align="center">
	<tr align="left"><th><b>Titel:&nbsp;</b><input type="text" size="60" maxlength="170" name="name" value="'.$name.'"></td></tr>
	<tr align="left"><td class="grau"><b>Datum:</b></td></tr>
	<tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;"><input type="text" size="2" name="datum1" value="'.$datum1.'"><input type="text" size="2" name="datum2" value="'.$datum2.'"><input type="text" size="4" name="datum3" value="'.$datum3.'"></td></tr>
	<tr valign="top"><td class="grau"><b>Beschreibung:</b></td></tr>
	<tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">
		<textarea name="beschreibung" cols="60" rows="5">'.$beschreibung.'</textarea></td></tr>
	<tr align="left"><td class="grau"><b>Anhang: (PDF/ZIP)</b></td>
	<tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">'; if($anhang!=''){echo '<a href="'.$doc.$anhang.'" target="_blank"><b>Anhang vorhanden</b> ('.datei_typ($anhang).' - '.round(filesize($doc.$anhang)/1000).'k)</a><input type="checkbox" name="delanhang">&nbsp;Anhang l�schen<br>';} echo '<input type="file" size="30" name="anhang"><input type="hidden" name="oldanhang" value="'.$anhang.'"></td></tr>
	<tr align="left"><td class="grau"><b>Link</b></td></tr>
	<tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">http://<input type="text" size="60" name="link" value="'.$link.'"></td></tr>
    </table></center>
    <input type="submit" value="Eintragen">
	</form>
';
break;

case("add2"):

    $anhang=$_FILES["anhang"]["tmp_name"];

		// "Funktion" setzt holt alle Variablen die mit POST �bergeben werden
		// (n�tig wenn rester_globals = off ist
	$vars="name,datum1,datum2,datum3,beschreibung,autoren_nr_a,link";
	$var=explode(",",$vars);
	$i=0;
	while($var[$i]!=''){
	$$var[$i]=$_POST["$var[$i]"];
	$i++;
	}

	if($link!=''){$link='http://'.$link;}

	$datum=$datum3.'-'.$datum2.'-'.$datum1;
//	$datum=date_to_timestamp($datum);
	$abfrage = "insert into mi_prof_publik set name='$name', datum='$datum', beschreibung='$beschreibung', link='$link'";
	$erg = mysql_query($abfrage);
	if($erg){

	$id=mysql_insert_id();
	$titelbildname="mi_publik_titel_".$id.".png";
	text_pic($name,"publik",$img,$titelbildname);

   if(is_uploaded_file($anhang)){
		$anhang = upload($anhang,$_FILES["anhang"][type],$id,$doc,"mi_prof_publik_");
		$abfrage = "update mi_prof_publik set anhang='$anhang' where id='$id'";
    	$erg = mysql_query($abfrage);
		// if($erg){echo ' Anhang erfolgreich hochgeladen.';$aktion='';}
	}

	echo 'Erfolgreich eingetragen';$aktion='';}
break;

case("edit2"):

    $anhang_i=$_FILES["anhang"]["tmp_name"];

		// "Funktion" setzt holt alle Variablen die mit POST �bergeben werden
		// (n�tig wenn rester_globals = off ist
	$vars="name,datum1,datum2,datum3,delanhang,oldanhang,beschreibung,autoren_nr_a,link";
	$var=explode(",",$vars);
	$i=0;
	while($var[$i]!=''){
	$$var[$i]=$_POST["$var[$i]"];
	$i++;
	}

	$i=0;
	while($autoren_nr_a[$i]!=''){
	$abfrage = "select publik_nr from mi_prof where id='$autoren_nr_a[$i]'";
	$erg = mysql_query($abfrage);
	(list($publik_nr) = mysql_fetch_row($erg));
	if(is_in($publik_nr,$autoren_nr_a[$i])!='true'){
	if($publik_nr!=''){$publik_nr.='_'.$nr;}
	else{$publik_nr=$nr;}
	$abfrage = "update mi_prof set publik_nr='$publik_nr' where id='$autoren_nr_a[$i]'";
	$erg = mysql_query($abfrage);}
	$i++;
	}

	if($link!=''){$link='http://'.$link;}

	$titelbildname="mi_publik_titel_".$nr.".png";
	text_pic($name,"publik",$img,$titelbildname);

	if(($oldanhang!='') and (is_uploaded_file($anhang_i) or $delanhang!='')){
        $erg = unlink($doc.$oldanhang);$oldanhang=$anhang='';}
    if(is_uploaded_file($anhang_i)){$anhang = upload($anhang_i,$_FILES["anhang"][type],$nr,$doc,"mi_prof_publik_");}
    else{$anhang=$oldanhang;}

	$datum=$datum3.'-'.$datum2.'-'.$datum1;
//	$datum=date_to_timestamp($datum);
	$abfrage = "update mi_prof_publik set name='$name', datum='$datum', beschreibung='$beschreibung', link='$link', anhang='$anhang' where id='$nr'";
	$erg = mysql_query($abfrage);
	if($erg){echo 'Erfolgreich ge�ndert';$aktion='';}
break;

case("del"):
$abfrage = "SELECT id, name, datum from mi_prof_publik where id='$nr'";
$erg = mysql_query($abfrage);
(list($id, $name, $datum) = mysql_fetch_row($erg));

echo '
<table width="100%" cellspacing="2" cellpadding="1" border="0">
<tr><th width="90">Datum</th><th>Name</th></tr>
<tr><td>'.timestamp_to_date($datum).'</td><td>'.$name.'</td></tr>
</table>
<p>Eintrag wirklich l�schen?&nbsp;<a href="?aktion=show">Nein</a>&nbsp;<a href="?aktion=del2&nr='.$nr.'">Ja</a></p>';
break;

case("del2"):

$abfrage = "SELECT anhang from mi_prof_publik where id='$nr'";
$erg = mysql_query($abfrage);
(list($bild, $anhang) = mysql_fetch_row($erg));
if($anhang!=''){unlink($doc.$anhang);}

$titelimg= $img.'mi_publik_titel_'.$nr.'.png';
if(is_readable($titelimg)){
unlink($titelimg);
}

$abfrage = "DELETE from mi_prof_publik where id='$nr'";
$erg = mysql_query($abfrage);
if($erg=='1'){echo 'Erfolgreich gel�scht.';$aktion='';}
break;
}

if($aktion=='' or $aktion=='show'){

$order=$_GET["order"];

echo '<p><a href="?aktion=add">Eintrag hinzuf�gen</a></p>
<table width="100%" cellspacing="2" cellpadding="1" border="0">
<tr><th>Optionen</th><th>Datum&nbsp;<a href="?aktion=show&order=1-datum"><img src="img/down.gif" border="0"></a>&nbsp;<a href="?aktion=show&order=datum"><img src="img/up.gif" border="0"></a></td><th>Name&nbsp;<a href="?aktion=show&order=1-name"><img src="img/down.gif" border="0"></a>&nbsp;<a href="?aktion=show&order=name"><img src="img/up.gif" border="0"></a></th></tr>';
$abfrage = "SELECT id, name, datum from mi_prof_publik";
if($order==''){$order='name';}
$abfrage.=' order by '.$order;
$erg = mysql_query($abfrage);
while (list($id, $name, $datum) = mysql_fetch_row($erg)){
if($i==1){$bgcolor='grau';$i=0;}else{$bgcolor='white';$i=1;}
echo '<tr class="'.$bgcolor.'"><th><a href="?aktion=add&nr='.$id.'"><img 
src="img/edit.gif" border="0" alt="Eintrag bearbeiten" title="Eintrag bearbeiten"></a>&nbsp;&nbsp;<a href="?aktion=del&nr='.$id.'"><img src="img/del.gif" border="0" 
alt="Eintrag l�schen" title="Eintrag l�schen"></a></th><td>'.date_conf($datum).'</td><td>'.$name.'</td></tr>'; }
echo '</table>';

}

}
else{ // kein Zutritt
include("keinzutritt.php");
} 
?>
