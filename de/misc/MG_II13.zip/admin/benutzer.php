<?php
##############################
#       benuter.php          #
#        Adminseite          #
#      created by sweh       #
#  last update: 22.01.2004   #
##############################
// TUC Corporate Design
require_once('../config.inc'); seite(__FILE__);

?>
<table width=100%> 
<tr>
	<td>
<?php
if (($_SESSION["login"] == "true") && ($_SESSION["benutzerid"] == "1"))
{
?>
		<center><img src="img/mi_titel_benutzer.png" align="center"></center>
	</td>
</tr>
<tr>
	<td>
<?php
	if ($_POST["action"] == "update")
	{
		if ($_POST["passwort1"] != $_POST["passwort2"])
		{	
			$fehler = 1;
			echo "Die eingegebenen Passw�rter sind nicht identisch!";
		}
		else
			mysql_query("UPDATE mi_benutzer SET passwort = md5('".$_POST["passwort1"]."'), vorname = '".$_POST["vorname"]."', nachname = '".$_POST["nachname"]."' WHERE id = '".$_POST["id"]."'")or die(mysql_error());
	}
	elseif ($_POST["action"] == "new")
	{
		if ($_POST["passwort1"] != $_POST["passwort2"])
		{	
			$fehler = 1;
			echo "Die eingegebenen Passw�rter sind nicht identisch!";
		}
		else
			mysql_query("INSERT into mi_benutzer (benutzername, passwort, vorname, nachname) VALUES ('".$_POST["benutzername"]."', md5('".$_POST["passwort1"]."'),'".$_POST["vorname"]."', '".$_POST["nachname"]."')")or die(mysql_error());
	}
	if ($_GET["edit"] == "delete")
	{
		if ($_GET["id"] == "1")
			echo "Dieser Benutzer kann nicht gel�scht werden!";
		else
		{
			mysql_query("DELETE from mi_benutzer WHERE id = '".$_GET["id"]."'");
			echo "Benutzer erfolgreich gel�scht! <a href=\"benutzer.php\">zur�ck zur �bersicht</a>";
		}
		
	}
	elseif(($_GET["edit"] == "edit") || ($fehler == 1))
	{
	?>
	<form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
	<?php
		if ($_REQUEST["id"])
		{
			$result_benutzer = mysql_query("SELECT benutzername, vorname, nachname from mi_benutzer WHERE id = '".$_REQUEST["id"]."'");
			if (mysql_num_rows($result_benutzer))
			{
				while($row_benutzer = mysql_fetch_array($result_benutzer))
				{
					$benutzername = $row_benutzer["benutzername"];
					$vorname = $row_benutzer["vorname"];
					$nachname = $row_benutzer["nachname"];
				}
			echo "<input type='hidden' name='action' value='update'>";
			echo "<input type='hidden' name='id' value='".$_REQUEST["id"]."'>";
			}

		}
		else
			echo "<input type='hidden' name='action' value='new'>";
	?>
	<table width=100%> 
		<tr><td class="liniehell">     
			    <b>Benutzer hinzuf�gen</b>
		    </td>
		</tr>
		<tr>
			<td>

			<table width="100%" cellspacing="2" cellpadding="1" border="0">
				<tr>
					<td align="right">Benutzername:</td>
					<td align="left" class="zehn"><input type="text" maxlength="25" name="benutzername" value="<?php echo $benutzername; ?>" <?php if ($benutzername) echo "disabled=\"disabled\""; ?>></td>
				</tr>
				<tr>
					<td align="right">Vorname:</td>
					<td align="left" class="zehn"><input type="text" maxlength="100" name="vorname" value="<?php echo $vorname; ?>"></td>
				</tr>
				<tr>
					<td align="right">Nachname:</td>
					<td align="left" class="zehn"><input type="text" maxlength="100" name="nachname" value="<?php echo $nachname; ?>"></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td align="right">Passwort:</td>
					<td align="left" class="zehn"><input type="password" maxlength="15" name="passwort1""></td>
				</tr>
				<tr>
					<td align="right">Passwort (Wiederholung):</td>
					<td align="left" class="zehn"><input type="password" maxlength="15" name="passwort2""></td>
				</tr>
				<tr>
					<td align="center" colspan="2"><input type="submit" value="absenden" >
			</table>

			</td>
		</tr>
	</table>
	</form>
	<?php
	}
	else
	{
	?>
			<table width=100%> 
			<tr><td class="liniehell">     
			    <b>aktuelle Benutzer</b>
			    </td>
			</tr>
			<tr><td>
				<table width="100%" cellspacing="2" cellpadding="1" border="0">
					<tr>
						<th>Optionen</th>
						<th>Benutzername</th>
						<th>Vorname</th>
						<th>Nachname</th>
						<th>letzer Login</th>
					</tr>
				
				<?php
					$result_benutzer = mysql_query("SELECT id, benutzername, vorname, nachname, last_login from mi_benutzer ORDER by id asc");
					if (mysql_num_rows($result_benutzer))
					{
						while($row_benutzer = mysql_fetch_array($result_benutzer))
						{
				
							if($i==1)
							{
								$bgcolor='white';
								$i=0;
							}
							else
							{
								$bgcolor='grau';
								$i=1;
							}
				
							echo "<tr class='$bgcolor'>";
						
						?>
						<th><a href="<?php echo $_SERVER["PHP_SELF"]; ?>?id=<?php echo $row_benutzer["id"]; ?>&edit=edit"><img src="img/edit.gif" border="0" alt="Daten �ndern" title="Daten �ndern"></a>
							<?php if ($row_benutzer["id"] != 1) { ?>
								&nbsp;&nbsp;<a href="<?php echo $_SERVER["PHP_SELF"]; ?>?id=<?php echo $row_benutzer["id"]; ?>&edit=delete"><img src="img/del.gif" border="0" alt="Benutzer l�schen" title="Benutzer l�schen"></a><?php } ?>
						</th>
				
						<td><?php echo $row_benutzer["benutzername"]; ?></td>
						<td>
							<?php echo $row_benutzer["vorname"]; ?>
						</td>
						<td><?php echo $row_benutzer["nachname"]; ?></td>

						<td align="center"><?php if (!$row_benutzer["last_login"]) echo "-"; else echo date("d.m.Y H:i:s", $row_benutzer["last_login"])."Uhr"; ?></td>
					</tr>
						<?php
						$alt_vart = $row_termine["vart"];
						}
					}
				?>
				</table>
				
			</td>
		</tr>
		<tr>
			<td coslpan="4" align="right"><a href="<?php echo $_SERVER["PHP_SELF"]; ?>?edit=edit"><img src="img/new_s.gif" title="Neuen Benutzer anlegen" border="0"></a>&nbsp;&nbsp;&nbsp;&nbsp;</td>
		</tr>
	</table>
	<?php
	}
}
else
	include_once("keinzutritt.php");
?>
	</td>
</tr>
</table>