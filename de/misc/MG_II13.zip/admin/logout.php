<?php
##############################
#        logout.php          #
#       Benutzerlogout       #
#      created by sweh       #
#  last update: 28.01.2004   #
##############################

// TUC Corporate Design
require_once('../config.inc'); seite(__FILE__);
?>
<table width="100%">
	<tr>
		<td align="center">     
			<img src="img/mi_titel_logout.png">
	    </td>
	</tr>
	<tr>
		<td>
<?php
if ($_SESSION["login"] == "true")
{
?>
	<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
	<input type="hidden" name="action" value="logout">
		<table>
			<tr>
				<td align="right" colspan="2">Sind Sie sicher, dass Sie sich vom System abmelden wollen?</td>
			</tr>
			<tr>
				<td align="center" class="zehn"><input type="submit" name="tues" value="JA"></td>
				<td align="center" class="zehn">&nbsp;</td>
			</tr>
		</table>
	</form>
<?php
}
else
	echo "Sie sind vom System abgemeldet";
?>
		</td>
	</tr>
</table>