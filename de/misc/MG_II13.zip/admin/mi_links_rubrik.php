<?php
require_once('../config.inc'); seite(__FILE__);

if ($_SESSION["login"] == "true"){ 

$img="../sonstig/links/img/";

echo '<center><img src="'.$img.'mi_links.png" border="0" align="center"></center>';

$aktion=$_GET["aktion"];
$nr=$_GET["nr"];

switch($aktion){
case("add"):

	if($nr!=''){
		$aktion='edit';
		$abfrage = "SELECT name, beschreibung from mi_links_rubrik where id='$nr'";
		$erg = mysql_query($abfrage);
		(list($name, $beschreibung) = mysql_fetch_row($erg));
	}

?>
	<script type="text/javascript">
	<!--
	function chkFormular()
	{
	if(document.Formular.name.value == "")  {
	alert("Bitte Rubriknamen eingeben!");
	document.Formular.name.focus();
	return false;
	}
	-->
	</script>
<?php
echo '
	<form name="Formular" action="?aktion='.$aktion.'2&nr='.$nr.'" method="POST" onSubmit="return chkFormular()">
	<center><table border="0" width="80%" align="center">
	<tr align="left"><th><b>Rubrikname:</b>&nbsp;<input type="text" size="30" name="name" value="'.$name.'"></th></tr>
	<tr align="left"><td class="grau"><b>Beschreibung:</b></td>
	<tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;"><textarea name="beschreibung" rows="5" cols="60">'.$beschreibung.'</textarea></td></tr>
	</table></center>
    <input type="submit" value="Eintragen">
	</form>
';
break;

case("add2"):

        // "Funktion" setzt holt alle Variablen die mit POST �bergeben werden
        // (n�tig wenn rester_globals = off ist
    $vars="name,beschreibung";
    $var=explode(",",$vars);
    $i=0;
    while($var[$i]!=''){
    $$var[$i]=$_POST["$var[$i]"];
    $i++;
    }

	$abfrage = "insert into mi_links_rubrik set name='$name', beschreibung='$beschreibung'";
    $erg = mysql_query($abfrage);
    if($erg){echo 'Erfolgreich eingetragen';$aktion='';}

break;

case("edit2"):

        // "Funktion" setzt holt alle Variablen die mit POST �bergeben werden
        // (n�tig wenn rester_globals = off ist
    $vars="name,beschreibung";
    $var=explode(",",$vars);
    $i=0;
    while($var[$i]!=''){
    $$var[$i]=$_POST["$var[$i]"];
    $i++;
    }

	$abfrage = "update mi_links_rubrik set name='$name', beschreibung='$beschreibung' where id='$nr'";
    $erg = mysql_query($abfrage);
    if($erg){echo 'Erfolgreich eingetragen';$aktion='';}
break;

case("del"):
$abfrage = "SELECT id, name, beschreibung from mi_links_rubrik where id='$nr'";
$erg = mysql_query($abfrage);
(list($id, $name, $beschreibung) = mysql_fetch_row($erg));

echo '
<table width="100%" cellspacing="2" cellpadding="1" border="0">
<tr><th>Name</th><th>Beschreibung</th></tr>
<tr><td>'.$name.'</a></td><td>'.kurzundknapp($beschreibung,60).'</td></tr>
</table>
<p>Eintrag wirklich l�schen?&nbsp;<a href="?aktion=show">Nein</a>&nbsp;<a href="?aktion=del2&nr='.$nr.'">Ja</a></p>';
break;

case("del2"):
$abfrage = "DELETE from mi_links_rubrik where id='$nr'";
$erg = mysql_query($abfrage);
if($erg=='1'){echo 'Erfolgreich gel�scht.';$aktion='';}
break;
}


if($aktion=='' or $aktion=='show'){

echo '<p><a href="?aktion=add">Eintrag hinzuf�gen</a></p>

<table width="100%" cellspacing="2" cellpadding="1" border="0">
<tr><th>Optionen</th><th>Name</th><th>Beschreibung</th></tr>';
$abfrage = "SELECT id, name, beschreibung from mi_links_rubrik";
$erg = mysql_query($abfrage);
while (list($id, $name, $beschreibung) = mysql_fetch_row($erg)){
if($i==1){$bgcolor='class="grau"';$i=0;}else{$bgcolor='class="white"';$i=1;}
echo '<tr '.$bgcolor.'><th><a href="?aktion=add&nr='.$id.'"><img src="img/edit.gif" border="0" alt="Eintrag bearbeiten" title="Eintrag bearbeiten"></a>&nbsp;&nbsp;<a ref="?aktion=del&nr='.$id.'"><img src="img/del.gif" border="0" 
alt="Eintrag l�schen" title="Eintrag l�schen"></a></th><td>'.$name.'</td><td>'.kurzundknapp($beschreibung,60).'</td></tr>'; }
echo '</table>';
}

}
else{ // kein Zutritt
include("keinzutritt.php");
} 
?>
