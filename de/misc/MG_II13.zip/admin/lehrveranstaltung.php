<?php
##############################
#   lehrveranstaltung.php    #
#        Adminseite          #
#      created by sweh       #
#  last update: 28.01.2004   #
##############################

// TUC Corporate Design
require_once('../config.inc'); seite(__FILE__);
?>
<style type="text/css">
<!--
td
{
	text-align:left;
}

td.zehn
{
	padding-left:10pt;
	padding-right:10pt;
	padding-top:10pt;
	padding-bottom:10pt;
}
-->
</style>

<?php
if ($_SESSION["login"] == "true")
{
	if ($_POST["eintragen"] == "vorlesung")
	{
		if ($_POST["id"]) // Updaten der Tabellen
		{
			$result_vorlesung = mysql_query("UPDATE mi_lehre_veranstaltung SET einheit = '".$_POST["einheit"]."', vname = '".$_POST["vname"]."', vart = '".$_POST["vart"]."', vinhalt = '".$_POST["vinhalt"]."', vsem = '".$_POST["vsem"]."', vabschluss = '".$_POST["vabschluss"]."', vliteratur = '".$_POST["vliteratur"]."', vhinweise = '".$_POST["vhinweise"]."' WHERE id = '".$_POST["id"]."'");
			$vl_id = $_POST["id"];
		}
		else // Erstellen der Tabellen
			if (!mysql_num_rows(mysql_query("SELECT id from mi_lehre_veranstaltung WHERE vart = '".$_POST["vart"]."' AND einheit = '".$_POST["einheit"]."'")))
			{
				$result_vorlesung = mysql_query("INSERT into mi_lehre_veranstaltung (einheit, vname, vart, vinhalt, vsem, vabschluss, vliteratur, vhinweise) VALUES ('".$_POST["einheit"]."', '".$_POST["vname"]."', '".$_POST["vart"]."', '".$_POST["vinhalt"]."', '".$_POST["vsem"]."', '".$_POST["vabschluss"]."', '".$_POST["vliteratur"]."', '".$_POST["vhinweise"]."')");
				$vl_id = mysql_insert_id();
			}

		text_pic($_POST["vname"], "lehre", "../lehre/veranstaltungen/img/", "mi_lehre_".$vl_id.".png");

		if (($_POST["praktikum"]) || ($_POST["vart"] == 4))
		{
			if (!$_POST["id"])
			{
				mt_srand(time());
				mysql_query("INSERT into mi_lehre_veranstaltung_zeit (einheit, vnr, vart, vperson, vaktiv) VALUES ('".$_REQUEST["einheit"]."', 'pra".mt_rand(100,999)."', '".$_POST["vart"]."', '".$_POST["vperson"]."', 0)")or die(mysql_error());
			}
			else
				mysql_query("UPDATE mi_lehre_veranstaltung_zeit SET vperson = '".$_POST["vperson"]."' WHERE einheit = ".$_POST["einheit"]." AND vart = ".$_POST["vart"]."")or die(mysql_error());
		}
	}
	elseif ($_POST["eintragen"] == "datum")
	{
		$_POST["vbeginn"] = str_replace(":","",$_POST["vbeginn"]);
		if (isset($_POST["id"])) // Updaten der Tabellen
			$result_vorlesung = mysql_query("UPDATE mi_lehre_veranstaltung_zeit SET einheit = '".$_POST["einheit"]."', vnr = '".$_POST["vnr"]."', vart = '".$_POST["vart"]."', vtag = '".$_POST["vtag"]."', vbeginn = '".$_POST["vbeginn"]."', vdauer = '".$_POST["vdauer"]."', vwoche = '".$_POST["vwoche"]."', vperson = '".$_POST["vperson"]."', vraum = '".$_POST["vraum"]."' WHERE id = '".$_POST["id"]."'");
		else
			if (!mysql_num_rows(mysql_query("SELECT id from mi_lehre_veranstaltung_zeit WHERE einheit = '".$_POST["einheit"]."' AND vnr = '".$_POST["vnr"]."' AND vart = '".$_POST["vart"]."' AND vtag = '".$_POST["vtag"]."' AND vbeginn = '".$_POST["vbeginn"]."' AND vdauer = '".$_POST["vdauer"]."' AND vwoche = '".$_POST["vwoche"]."' AND vperson = '".$_POST["vperson"]."' AND vraum = '".$_POST["vraum"]."'")))
				$result_vorlesung = mysql_query("INSERT into mi_lehre_veranstaltung_zeit (einheit, vnr, vart, vtag, vbeginn, vdauer, vwoche, vperson, vraum) VALUES ('".$_POST["einheit"]."', '".$_POST["vnr"]."', '".$_POST["vart"]."', '".$_POST["vtag"]."', '".$_POST["vbeginn"]."', '".$_POST["vdauer"]."', '".$_POST["vwoche"]."', '".$_POST["vperson"]."', '".$_POST["vraum"]."')");
	}
	elseif ($_POST["eintragen"] == "material")
	{
		if ($_FILES["file"]["name"])
		{
			$temp = explode(".",$_FILES["file"]["name"]);
			$anzahl_teile = count($temp)-1;
		
			mt_srand(time());
			$dateiname = "skripte/".mt_rand(1,999999999).".".$temp[$anzahl_teile];
		
			while (file_exists("../lehre/lehrmaterial/".$dateiname))
			{
				mt_srand(time());
				$dateiname = "skripte/".mt_rand(1,999999999).".".$temp[$anzahl_teile];
			}
		
			move_uploaded_file($_FILES["file"]["tmp_name"],"../lehre/lehrmaterial/".$dateiname);
		}
		else
			$dateiname = $_POST["dateiname"];
	
		$_POST["sem2"] = $_POST["jahr"]."".$_POST["sem"];
	
		if ($_POST["id"]) // Updaten der Tabellen
			$result_vorlesung = mysql_query("UPDATE mi_lehre_material SET einheit = '".$_POST["einheit"]."', art = '".$_POST["art"]."', beschreibung = '".$_POST["beschreibung"]."', link = '".$dateiname."', zeit = '".time()."', sem = '".$_POST["sem2"]."' WHERE id = '".$_POST["id"]."'");
		else
			if (!mysql_num_rows(mysql_query("SELECT id from mi_lehre_material WHERE einheit = '".$_POST["einheit"]."' AND link = '".$dateiname."'")))
				$result_vorlesung = mysql_query("INSERT into mi_lehre_material (einheit, art, beschreibung, link, zeit, sem) VALUES ('".$_POST["einheit"]."', '".$_POST["art"]."', '".$_POST["beschreibung"]."', '".$dateiname."', '".time()."', '".$_POST["sem2"]."')");
	
		$result_extra = mysql_query("SELECT id, vname from mi_lehre_veranstaltung WHERE einheit = '".$_POST["einheit"]."' AND vart = '1' LIMIT 1");
		if (mysql_num_rows($result_extra))
			while ($row = mysql_fetch_array($result_extra))
				text_pic($row["vname"], "skript", "../lehre/lehrmaterial/img/", "mi_skripte_".$row["id"].".png");

	}
	elseif ($_POST["eintragen"] == "p_themen")
	{
		if (isset($_POST["id"])) // Updaten der Tabellen
			$result_vorlesung = mysql_query("UPDATE mi_lehre_veranstaltung_praktika SET einheit = '".$_POST["einheit"]."', pkomplex = '".$_POST["pkomplex"]."', pthema = '".$_POST["pthema"]."', pperson = '".$_POST["pperson"]."', pinhalt = '".$_POST["pinhalt"]."', pliteratur = '".$_POST["pliteratur"]."', phinweise = '".$_POST["phinweise"]."' WHERE id = '".$_POST["id"]."'");
		else
			if (!mysql_num_rows(mysql_query("SELECT id from mi_lehre_veranstaltung_praktika WHERE einheit = '".$_POST["einheit"]."' AND pkomplex = '".$_POST["pkomplex"]."' AND pthema = '".$_POST["pthema"]."' AND pinhalt = '".$_POST["pinhalt"]."' AND pliteratur = '".$_POST["pliteratur"]."' AND phinweise = '".$_POST["phinweise"]."'")))
				$result_vorlesung = mysql_query("INSERT into mi_lehre_veranstaltung_praktika (einheit, pkomplex, pthema, pperson, pinhalt, pliteratur, phinweise) VALUES ('".$_POST["einheit"]."', '".$_POST["pkomplex"]."', '".$_POST["pthema"]."', '".$_POST["pperson"]."', '".$_POST["pinhalt"]."', '".$_POST["pliteratur"]."', '".$_POST["phinweise"]."')");
	}
	elseif ($_GET["eintragen"] == "status")
	{
		if ($_GET["akt_status"] == "3")
			$_GET["akt_status"] = "0";
		else
			$_GET["akt_status"]++;

		$result_vorlesung = mysql_query("UPDATE mi_lehre_veranstaltung_zeit SET vaktiv = '".$_GET["akt_status"]."' WHERE id = '".$_GET["id"]."'");
	}
	elseif ($_POST["loeschen"] == "vorlesung")
	{
		if ($_POST["tues"] == "JA")
		{
			if (!$_POST["id"])
			{
				$result_extra = mysql_query("SELECT id, vname from mi_lehre_veranstaltung WHERE einheit = '".$_POST["einheit"]."' LIMIT 1");
				if (mysql_num_rows($result_extra))
					while ($row = mysql_fetch_array($result_extra))
					{
						$vorlesungsname = $row["vname"];
						$vl_id = $row["id"];
					}

				mysql_query("DELETE from mi_lehre_veranstaltung WHERE einheit = '".$_POST["einheit"]."'")or die(mysql_error());
				mysql_query("DELETE from mi_lehre_material WHERE einheit = '".$_POST["einheit"]."'")or die(mysql_error());
				mysql_query("DELETE from mi_lehre_veranstaltung_zeit WHERE einheit = '".$_POST["einheit"]."'")or die(mysql_error());
				mysql_query("DELETE from mi_lehre_veranstaltung_praktika WHERE einheit = '".$_POST["einheit"]."'")or die(mysql_error());
				unset($_REQUEST["einheit"]);

				@unlink("../lehre/lehrmaterial/img/mi_skripte_".$vl_id.".png");
				@unlink("../lehre/veranstaltungen/img/mi_lehre_".$vl_id.".png");
			}
			else
				mysql_query("DELETE from mi_lehre_veranstaltung WHERE id = '".$_POST["id"]."'");
		}
	}
	elseif ($_POST["loeschen"] == "termine")
	{
		if ($_POST["tues"] == "JA")
			mysql_query("DELETE from mi_lehre_veranstaltung_zeit WHERE id = '".$_POST["id"]."'");
	}
	elseif ($_POST["loeschen"] == "p_themen")
	{
		if ($_POST["tues"] == "JA")
			mysql_query("DELETE from mi_lehre_veranstaltung_praktika WHERE id = '".$_POST["id"]."'");
	}
	elseif ($_POST["loeschen"] == "material")
	{
		if ($_POST["tues"] == "JA")
		{
			mysql_query("DELETE from mi_lehre_material WHERE id = '".$_POST["id"]."'");
			unlink("../lehre/lehrmaterial/".$_POST["loeschen_link"]);
		}
	}
	
	if ($result_vorlesung && $result_vorlesung2)
		echo "Die Daten konnten erfolgreich in die Datenbank �bernommen werden!";
	
	if ($_REQUEST["aktuelle_vorlesung"] == "aktualisieren")
	{
		$_REQUEST["id"] = mysql_insert_id();
		include_once("inc/datum.php");
	}
	elseif ($_POST["akt_p_themen"] == "aktualisieren")
	{
		$_REQUEST["id"] = mysql_insert_id();
		include_once("inc/datum.php");
	}
	elseif ($_POST["akt_praktikum"] == "aktualisieren")
	{
		$_REQUEST["id"] = mysql_insert_id();
		include_once("inc/praktikum.php");
	}
	elseif ($_REQUEST["weiter"] == "praktikum")
		include_once("inc/praktikum.php");
	elseif ($_REQUEST["weiter"] == "seminar")
		include_once("inc/seminar.php");
	elseif (($_REQUEST["weiter"] == "vorlesung") || (!$_REQUEST["einheit"]))
		include_once("inc/vorlesung.php");
	elseif ($_REQUEST["weiter"] == "uebung")
		include_once("inc/uebung.php");
	elseif ($_REQUEST["weiter"] == "datum")
		include_once("inc/datum.php");
	elseif ($_REQUEST["weiter"] == "p_themen")
		include_once("inc/p_themen.php");
	elseif ($_REQUEST["weiter"] == "material")
		include_once("inc/upload.php");
	elseif ($_REQUEST["weiter"] == "loeschen")
		include_once("inc/loeschen.php");
	else
	{
	
		$result_vorlesung = mysql_query("SELECT id, vname from mi_lehre_veranstaltung WHERE einheit = ".$_REQUEST["einheit"]." LIMIT 1");
		if ($_REQUEST["einheit"])
			if (@mysql_num_rows($result_vorlesung))
				while($row = mysql_fetch_array($result_vorlesung))
				{
					$veranstaltungsname = $row["vname"];
					$veranstaltungsid = $row["id"];
				}
		?>
		<center>
		<table width="100%" cellspacing="0" cellpadding="0">
		<?php
			$result_blub = mysql_query("SELECT vname from mi_lehre_veranstaltung WHERE einheit = '".$_REQUEST["einheit"]."' AND vart = 1 LIMIT 1");
			if (!mysql_num_rows($result_blub))
				$_POST["praktikum"] = "alleine";
		?>
			<tr>
				<td> </td>
				<td align="center"><center><img align="center" src="../lehre/veranstaltungen/img/mi_lehre_<?php echo $veranstaltungsid.".png"; ?>" align="center"></td></center>
				<td > </td>
			</tr>
		<?php
			if (!$_POST["praktikum"])
			{
		?>
			<tr>
				<td class="liniehell"> </td>
				<td>
			<?php
				include("uebersicht/vorlesung.php");
			?>
					<table width=100% align="center">
						<tr>
							<td width="90%" align="right">
							<form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
							<?php
								echo "<input type='hidden' name='id' value='".$veranstaltungsid."'>";	
								echo "<input type='hidden' name='einheit' value='".$_REQUEST["einheit"]."'>";
							?>
								<input type="hidden" name="weiter" value="vorlesung">
								<input type="image" src="img/edit_s.gif" title="Vorlesungsdaten �ndern">
							</form>
							</td>
							<td align="left">
							<form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
							<?php
								echo "<input type='hidden' name='einheit' value='".$_REQUEST["einheit"]."'>";
							 ?>
								<input type="hidden" name="loeschen" value="vorlesung">
								<input type="hidden" name="weiter" value="loeschen">
								<input type="image" src="img/del_s.gif" title="Vorlesung l�schen">
							</form>
							</td>
						</tr>
						<tr>
							<td class="liniehell" colspan="2"> </td>
						</tr>
					</table>
				</td>
				<td class="liniehell"> </td>
			</tr>
			<tr>
				<td class="liniehell"> </td>
				<td>
				<?php
					include("uebersicht/uebung.php");
				?>
				<table width=100% align="center">
					<tr>
						<td width="90%" align="right">
							<form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
								<?php
								$result_vorlesung = mysql_query("SELECT id from mi_lehre_veranstaltung WHERE einheit = ".$_REQUEST["einheit"]." AND vart = 2 LIMIT 1");
								if ($_REQUEST["einheit"])
									if (@mysql_num_rows($result_vorlesung))
										while($row = mysql_fetch_array($result_vorlesung))
											$id = $row["id"];

								echo "<input type='hidden' name='id' value='$id'>";			
								echo "<input type='hidden' name='einheit' value='".$_REQUEST["einheit"]."'>";
								echo "<input type='hidden' name='vname' value='".$veranstaltungsname."'>";
								 ?>
								<input type="hidden" name="weiter" value="uebung">
								<input type="image" src="img/edit_s.gif" title="�bungsdaten �ndern">
							</form>
						</td>
						<td align="left">
							<form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
								<?php
								echo "<input type='hidden' name='id' value='$id'>";
								echo "<input type='hidden' name='einheit' value='".$_REQUEST["einheit"]."'>";
								unset($id);
								 ?>
								<input type="hidden" name="weiter" value="loeschen">
								<input type="hidden" name="loeschen" value="uebung">
								<input type="image" src="img/del_s.gif" title="�bung l�schen">
							</form>
						</td>
					</tr>
					<tr>
						<td class="liniehell" colspan="2"> </td>
					</tr>
				</table>
				</td>
				<td class="liniehell"> </td>
			</tr>
			<?php
			}
			?>
			<tr>
				<td class="liniehell"> </td>
				<td>
				<?php
					include("uebersicht/praktikum.php");
				?>
				<table width=100% align="center">
					<tr>
						<td width="90%" align="right">
						<form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
							<?php
								$result_vorlesung = mysql_query("SELECT id from mi_lehre_veranstaltung WHERE einheit = ".$_REQUEST["einheit"]." AND (vart = 3 || vart = 4) LIMIT 1");
								if ($_REQUEST["einheit"])
									if (@mysql_num_rows($result_vorlesung))
										while($row = mysql_fetch_array($result_vorlesung))
											$id = $row["id"];
							echo "<input type='hidden' name='id' value='$id'>";			
							echo "<input type='hidden' name='einheit' value='".$_REQUEST["einheit"]."'>";
							echo "<input type='hidden' name='vname' value='".$veranstaltungsname."'>";
							 ?>
							<input type="hidden" name="weiter" value="praktikum">
							<input type="image" src="img/edit_s.gif" title="<?php if ($lehre_veranstaltung_vart == 3) echo "Praktikums"; else echo "Seminar"; ?>daten �ndern">
						</form>
						</td>
						<td align="left">
						<form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
							<?php
											echo "<input type='hidden' name='id' value='$id'>";
											echo "<input type='hidden' name='einheit' value='".$_REQUEST["einheit"]."'>";
							 ?>
							<input type="hidden" name="weiter" value="loeschen">
							<input type="hidden" name="loeschen" value="praktikum">
							<input type="image" src="img/del_s.gif" title="<?php if ($lehre_veranstaltung_vart == 3) echo "Praktikum"; else echo "Seminar"; ?> l�schen">
						</form>
						</td>
					</tr>
					<tr>
						<td class="liniehell" colspan="2"> </td>
					</tr>
				</table>
				</td>
				<td class="liniehell"> </td>
			</tr>
			<?php
			if ($p_themen != "false")
			{
			?>
			<tr>
				<td class="liniehell"> </td>
				<td>
				<?php
				include("uebersicht/p_themen.php");
				?>
				<table width=100% align="center">
					<tr>
						<td width="90%" align="right">
						<form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
							<?php
							echo "<input type='hidden' name='einheit' value='".$_REQUEST["einheit"]."'>"; ?>
							<input type="hidden" name="weiter" value="p_themen">
							<input type="image" src="img/new_s.gif" title="Praktikumsthema hinzuf�gen">
						</form>
						</td>
						<td align="left">
							&nbsp;
						</td>
					</tr>
					<tr>
						<td class="liniehell" colspan="2"> </td>
					</tr>
				</table>
				</td>
				<td class="liniehell"> </td>
			</tr>
			<?php
			}
			if (!$_POST["praktikum"])
			{
			?>
			<tr>
				<td class="liniehell"> </td>
				<td>
				<?php
					include("uebersicht/termine.php");
				?>
				<table width=100% align="center">
					<tr>
						<td width="90%" align="right">
						<form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
							<?php
							echo "<input type='hidden' name='einheit' value='".$_REQUEST["einheit"]."'>"; ?>
							<input type="hidden" name="weiter" value="datum">
							<input type="image" src="img/new_s.gif" title="Termin hinzuf�gen">
						</form>
						</td>
						<td align="left">
							&nbsp;
						</td>
					</tr>
					<tr>
						<td class="liniehell" colspan="2"> </td>
					</tr>
				</table>
				</td>
				<td class="liniehell"> </td>
			</tr>
			<tr>
				<td class="liniehell"> </td>
				<td>
				<?php
					include("uebersicht/material.php");
				?>
				<table width=100% align="center">
					<tr>
						<td width="90%" align="right">
						<form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
							<?php
							echo "<input type='hidden' name='einheit' value='".$_REQUEST["einheit"]."'>"; ?>
							<input type="hidden" name="weiter" value="material">
							<input type="image" src="img/new_s.gif" title="Material hinzuf�gen">
						</form>
						</td>
						<td align="left">
							&nbsp;
						</td>
					</tr>
					<tr>
						<td class="liniehell" colspan="2"> </td>
					</tr>
				</table>
				</td>
				<td class="liniehell"> </td>
			</tr>
		<?php
		}
		?>
		</table>
		</center>
	<?php
	}
}
else
	include_once("keinzutritt.php");
?>