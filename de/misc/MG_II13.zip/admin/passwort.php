<?php
##############################
#       passwort.php         #
#        Adminseite          #
#      created by sweh       #
#  last update: 29.01.2004   #
##############################

// TUC Corporate Design
require_once('../config.inc'); seite(__FILE__);

?>
<table width=100%> 
<tr>
	<td>
<?php
if ($_SESSION["login"] == "true")
{
?>
		<center><img src="img/mi_titel_passwort.png" align="center"></center>
	</td>
</tr>
<tr>
	<td align="center">
<?php
	if ($_POST["action"] == "update")
	{
		$result_passwort = mysql_query("SELECT passwort from mi_benutzer WHERE id = '".$_SESSION["benutzerid"]."'");
		if (mysql_num_rows($result_passwort))
			while ($row = mysql_fetch_array($result_passwort))
				$pw_db = $row["passwort"];

		if ($pw_db == MD5($_POST["passwort0"]))
			if ($_POST["passwort1"] != $_POST["passwort2"])
			{	
				$fehler = 1;
				echo "Die eingegebenen Passw�rter sind nicht identisch!";
			}
			else
			{
				mysql_query("UPDATE mi_benutzer SET passwort = md5('".$_POST["passwort1"]."') WHERE id = '".$_SESSION["benutzerid"]."'")or die(mysql_error());
				echo "Das Passwort wurde ge�ndert! Es wird empfohlen, sich jetzt mit dem neuen Passwort anzumelden!";
			}
		else
		{	
			$fehler = 1;
			echo "Das alte Passwort stimmt nicht mit dem in der Datenbank �berein!";
		}
	}
	if (($_POST["action"] != "update") || ($fehler == 1))
	{
		$result_benutzer = mysql_query("SELECT benutzername, vorname, nachname from mi_benutzer WHERE id = '".$_SESSION["benutzerid"]."'");
		if (mysql_num_rows($result_benutzer))
			while ($row_benutzer = mysql_fetch_array($result_benutzer))
			{
				$benutzername = $row_benutzer["benutzername"];
				$vorname = $row_benutzer["vorname"];
				$nachname = $row_benutzer["nachname"];
			}
?>
<center>
	<table width=100%> 
<!--		<tr><td class="liniehell">     
			    <b>Passwort �ndern</b>
		    </td>
		</tr>-->
		<tr>
			<td align="center">
			<form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
			<input type="hidden" name="action" value="update"><center>
			<table cellspacing="2" cellpadding="1" border="0">
				<tr>
					<td align="right">Benutzername:</td>
					<td align="left" class="zehn"><input type="text" name="benutzername" value="<?php echo $benutzername; ?>" disabled="disabled"></td>
				</tr>
				<tr>
					<td align="right">Vorname:</td>
					<td align="left" class="zehn"><input type="text" name="vorname" value="<?php echo $vorname; ?>" disabled="disabled"></td>
				</tr>
				<tr>
					<td align="right">Nachname:</td>
					<td align="left" class="zehn"><input type="text" name="nachname" value="<?php echo $nachname; ?>" disabled="disabled"></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td align="right">altes Passwort:</td>
					<td align="left" class="zehn"><input type="password" name="passwort0"></td>
				</tr>
				<tr>
					<td align="right">neues Passwort:</td>
					<td align="left" class="zehn"><input type="password" name="passwort1" maxlength="15"></td>
				</tr>
				<tr>
					<td align="right">neues Passwort (Wiederholung):</td>
					<td align="left" class="zehn"><input type="password" name="passwort2" maxlength="15"></td>
				</tr>
				<tr>
					<td align="center" colspan="2"><input type="submit" value="absenden" >
			</table></center>
			</form>
			</td>
		</tr>
	</table></center>
	<?php
	}
}
else
	include_once("keinzutritt.php");
?>
	</td>
</tr>
</table>