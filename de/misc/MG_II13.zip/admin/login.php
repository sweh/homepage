<?php
##############################
#        login.php           #
#       Benutzerlogin        #
#      created by sweh       #
#  last update: 28.01.2004   #
##############################

// TUC Corporate Design
require_once('../config.inc'); seite(__FILE__);
?>
<table width=100%> 
	<tr>
		<td align="center">     
			<img src="img/mi_titel_login.png">
	    </td>
	</tr>
	<tr>
		<td>
		<?php
		if ($_SESSION["login"] == "true")
		{
			echo "Sie wurden erfolgreich eingelogged! ";
			if (!$_SESSION["last_login"])
				echo "Sie sind zum ersten Mal hier.";
			else
				echo "Ihr letzter Login war am ".date("d.m.Y",$_SESSION["last_login"])." um ".date("H:i:s",$_SESSION["last_login"])."Uhr.";
		}
		else
		{
		?>
		<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
			<input type="hidden" name="action" value="login">
			<p>Bitte geben Sie den Benutzernamen und das Kennwort ein, um Zugang zum Administrationsssystem zu bekommen</p>
			<table>
				<tr>
					<td align="right">Benutzername:</td>
					<td align="left" class="zehn"><input type="text" name="benutzername"></td>
				</tr>
				<tr>
					<td align="right">Passwort:</td>
					<td align="left" class="zehn"><input type="password" name="passwort"></td>
				</tr>
				<tr>
					<td align="center" colspan="2"><input type="submit" value="login" ></td>
				</tr>
			</table>
		</form>
		<?php
		}
		?>
		</td>
	</tr>
</table>