<?php
require_once('../config.inc'); seite(__FILE__);

if ($_SESSION["login"] == "true"){ 

$img="../sonstig/links/img/";

echo '<center><img src="'.$img.'mi_links.png" border="0" align="center"></center>';

$aktion=$_GET["aktion"];
$nr=$_GET["nr"];

switch($aktion){
case("add"):

	if($nr!=''){
		$aktion='edit';
		$abfrage = "SELECT name, link,rubrik_id from mi_links where id='$nr'";
		$erg = mysql_query($abfrage);
		(list($name, $link, $rubrik) = mysql_fetch_row($erg));
	}

?>
	<script type="text/javascript">
	<!--
	function chkFormular()
	{
	if(document.Formular.name.value == "")  {
	alert("Bitte Veranstaltungsnamen eingeben!");
	document.Formular.name.focus();
	return false;
	}

	if(document.Formular.link.value == "")  {
	alert("Bitte Link eingeben!");
	document.Formular.link.focus();
	return false;
	}
	}
	-->
	</script>
<?php
echo '
	<form name="Formular" action="?aktion='.$aktion.'2&nr='.$nr.'" method="POST" onSubmit="return chkFormular()">
	<center><table border="0" width="80%" align="center">
	<tr align="left"><th><b>Name:</b>&nbsp;<input type="text" size="60" name="name" value="'.$name.'"></td></tr>
	<tr align="left"><td class="grau"><b>Rubrik:</b></td>
	<tr align="left"><td class="zehn">
		<select name="rubrik_id">';
	$abfrage = "SELECT id, name from mi_links_rubrik";
	$erg = mysql_query($abfrage);
	while (list($id, $name) = mysql_fetch_row($erg)){
	echo '<option value="'.$id.'"'; if($id==$rubrik){echo ' selected';} echo '>'.$name.'</option>';
	}
	echo '
		</select>&nbsp;&nbsp;<a href="mi_links_rubrik.php?aktion=add" target="_blank">Rubrik hinzuf�gen &gt;&gt;&gt;</a>
	</td></tr>
	<tr align="left"><td class="grau"><b>Link:</b></td>
	<tr align="left"><td class="zehn">http://<input type="text" name="link" size="60" value="'.substr($link,7).'"></td></tr>
	</table></center>
    <input type="submit" value="Eintragen">
	</form>
';
break;

case("add2"):

        // "Funktion" setzt holt alle Variablen die mit POST �bergeben werden
        // (n�tig wenn rester_globals = off ist
    $vars="name,link,rubrik_id";
    $var=explode(",",$vars);
    $i=0;
    while($var[$i]!=''){
    $$var[$i]=$_POST["$var[$i]"];
    $i++;
    }

	$link='http://'.$link;

	$abfrage = "insert into mi_links set name='$name', rubrik_id='$rubrik_id', link='$link'";
    $erg = mysql_query($abfrage);
    if($erg){echo 'Erfolgreich eingetragen';$aktion='';}

break;

case("edit2"):

        // "Funktion" setzt holt alle Variablen die mit POST �bergeben werden
        // (n�tig wenn rester_globals = off ist
    $vars="name,link,rubrik_id";
    $var=explode(",",$vars);
    $i=0;
    while($var[$i]!=''){
    $$var[$i]=$_POST["$var[$i]"];
    $i++;
    }

	$link='http://'.$link;

	$abfrage = "update mi_links set name='$name', rubrik_id='$rubrik_id', link='$link' where id='$nr'";
    $erg = mysql_query($abfrage);
    if($erg){echo 'Erfolgreich eingetragen';$aktion='';}
break;

case("del"):
$abfrage = "SELECT id, name, rubrik_id, link from mi_links where id='$nr'";
$erg = mysql_query($abfrage);
(list($id, $name, $rubrik_id, $link) = mysql_fetch_row($erg));
	$abfrage2="Select name from mi_links_rubrik where id='$rubrik_id'";
	$erg2 = mysql_query($abfrage2);
	list($rubrik) = mysql_fetch_row($erg2);

echo '
<table width="100%" cellspacing="2" cellpadding="1" border="0">
<tr><th>Name</th><th>Rubrik</th></tr>
<tr><td><a href="'.$link.'" target="_blank">'.kurzundknapp($name,50).'</a></td><td>'.$rubrik.'</td></tr>
</table>
<p>Eintrag wirklich l�schen?&nbsp;<a href="?aktion=show">Nein</a>&nbsp;<a href="?aktion=del2&nr='.$nr.'">Ja</a></p>';
break;

case("del2"):
$abfrage = "DELETE from mi_links where id='$nr'";
$erg = mysql_query($abfrage);
if($erg=='1'){echo 'Erfolgreich gel�scht.';$aktion='';}
break;
}


if($aktion=='' or $aktion=='show'){

$order=$_GET["order"];

echo '<p><a href="?aktion=add">Eintrag hinzuf�gen</a></p>
<p><a href="mi_links_rubrik.php">Rubriken Bearbeiten</a></p>
<table width="100%" cellspacing="2" cellpadding="1" border="0">
<tr><th>Optionen</th><th>Name&nbsp;<a href="?aktion=show&order=1-name"><img src="img/down.gif" border="0"></a>&nbsp;<a href="?aktion=show&order=name"><img src="img/up.gif" border="0"></a></th><th>Rubrik&nbsp;<a href="?aktion=show&order=1-rubrik_id"><img src="img/down.gif" border="0"></a>&nbsp;<a href="?aktion=show&order=rubrik_id"><img src="img/up.gif" border="0"></a></th></tr>';
$abfrage = "SELECT id, name, rubrik_id, link from mi_links";
if($order==''){$order='name';}
$abfrage.=' order by '.$order;
$erg = mysql_query($abfrage);
while (list($id, $name, $rubrik_id, $link) = mysql_fetch_row($erg)){
if($i==1){$bgcolor='grau';$i=0;}else{$bgcolor='white';$i=1;}
	$abfrage2="Select name from mi_links_rubrik where id='$rubrik_id'";
	$erg2 = mysql_query($abfrage2);
	list($rubrik) = mysql_fetch_row($erg2);
echo '<tr class="'.$bgcolor.'"><th><a href="?aktion=add&nr='.$id.'"><img 
src="img/edit.gif" border="0" alt="Eintrag bearbeiten" title="Eintrag bearbeiten"></a>&nbsp;&nbsp;<a href="?aktion=del&nr='.$id.'"><img src="img/del.gif" border="0" alt="Eintrag l�schen" title="Eintrag l�schen"></a></th><td><a href="'.$link.'" target="_blank">'.kurzundknapp($name,50).'</a></td><td>'.$rubrik.'</td></tr>';
}
echo '</table>';
}

}
else{//kein Zutritt
include("keinzutritt.php");
}

?>
