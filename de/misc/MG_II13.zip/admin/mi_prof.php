<?php
require_once('../config.inc'); seite(__FILE__);

if ($_SESSION["login"] == "true"){ 

function mi_prof($funktion){
switch($funktion){
    case(0):$funktion='Sonstige (an der Prof. MI)';break;
    case(1):$funktion='Lehrstuhlinhaber';break;
    case(2):$funktion='Wissentschaftlicher Mitarbeiter';break;
    case(3):$funktion='Hilfswissenschaftler';break;
    case(4):$funktion='Sekret�r(in)';break;
    case(5):$funktion='Vetretretung Lehrstuhlinhaber';break;
    case(6):$funktion='Student';break;
    case(7):$funktion='andere Professur';break;
    }
return $funktion;
}


$img="../prof/img/";

echo '<br>
<center><img src="'.$img.'mi_prof.png" border="0" align="center"></center>';

$aktion=$_GET["aktion"];
$nr=$_GET["nr"];

switch($aktion){
case("add"):

    if($nr!=''){
        $aktion='edit';
        $abfrage = "SELECT name, vname, titel, zimmer, telefon, fax, email, funktion, anfang, ende, photo, sprechstunde, lebenslauf, publik_nr from mi_prof where id='$nr'";
        $erg = mysql_query($abfrage);
        (list($name, $vname, $titell, $zimmer, $telefon, $fax, $email, $funktion, $anfang, $ende, $photo, $sprechstunde, $lebenslauf, $publik_nr) = mysql_fetch_row($erg));

    }
?>
	<script type="text/javascript">
	<!--
	function chkFormular()
	{
	if(document.Formular.name.value == "")  {
	alert("Bitte Namen eingeben!");
	document.Formular.name.focus();
	return false;
	}

	if(document.Formular.vname.value == "")  {
	alert("Bitte Vornamen eingeben!");
	document.Formular.vname.focus();
	return false;
	}
	}

	-->
	</script>
<?
echo'
<form name="Formular" action="?aktion='.$aktion.'2&nr='.$nr.'" method="POST" enctype=multipart/form-data onSubmit="return chkFormular()">

<center>
<table width=80% align="center">

  <tr align="left"><td class="grau"><b>Kontakt / T�tigkeit</b></td></tr>
  <tr align="left"><td align="center" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">
	<table width="90%" bgcolor="#CCE7E7">
	<tr valign="top"><td align="left">Titel:</td><td align="left"><input type="text" size="10" name="titell" value="'.$titell.'"></td></tr>
	<tr valign="top"><td align="left">Nachname:</td><td align="left"><input type="text" size="30" name="name" value="'.$name.'"></td></tr>
    <tr valign="top"><td align="left" >Vorname:</td><td align="left"><input type="text" size="30" name="vname" value="'.$vname.'"></td></tr>
    <tr valign="top"><td align="left">Funktion:</td><td align="left"><select name="funktion">
        <option value="0"'; if($funktion==0){echo ' selected';} echo '>Sonstige (an der Prof. MI)</option>
        <option value="1"'; if($funktion==1){echo ' selected';} echo '>Lehrstuhlinhaber</option>
        <option value="2"'; if($funktion==2){echo ' selected';} echo '>Wissentschaftlicher Mitarbeiter</option>
        <option value="3"'; if($funktion==3){echo ' selected';} echo '>Hilfswissentschaftler</option>
        <option value="4"'; if($funktion==4){echo ' selected';} echo '>Sekrer�r(in)</option>
        <option value="5"'; if($funktion==5){echo ' selected';} echo '>Vertretung Lehrstuhlinhaber</option>
        <option value="6"'; if($funktion==6){echo ' selected';} echo '>Student</option>
	<option value="7"'; if($funktion==7){echo ' selected';} echo '>andere Professur</option>
        </select></td></tr>
    <tr valign="top"><td align="left">Begin der T�tigkeit:</td><td align="left"><select name="anfang1">
        <option value="x"'; if(substr($ende,4,1)=='x'){echo ' selected';} echo '>keine Angabe</option>
        <option value="s"'; if(substr($anfang,4,1)=='s'){echo ' selected';} echo '>Sommersemester</option>
        <option value="w"'; if(substr($anfang,4,1)=='w'){echo ' selected';} echo '>Wintersemester</option>
        </select><select name="anfang2">';$jahr=jahre(1999,0);
        for($i=1;$i<$jahr[0]+1;$i++){echo '<option value='.$jahr[$i]; if($jahr[$i]==substr($anfang,0,4)){echo ' selected';} echo '>'.$jahr[$i].'</option>';}
    echo '</select></td></tr>
    <tr valign="top"><td align="left">Ende der T�tigkeit:</td><td align="left"><select name="ende1">
        <option value="x"'; if(substr($ende,4,1)=='x'){echo ' selected';} echo '>keine Angabe</option>
        <option value="s"'; if(substr($ende,4,1)=='s'){echo ' selected';} echo '>Sommersemester</option>
        <option value="w"'; if(substr($ende,4,1)=='w'){echo ' selected';} echo '>Wintersemester</option>
        </select><select name="ende2">';$jahr=jahre(1999,15);
        for($i=1;$i<$jahr[0]+1;$i++){echo '<option value='.$jahr[$i]; if($jahr[$i]==substr($ende,0,4)){echo ' selected';} echo '>'.$jahr[$i].'</option>';}
    echo '</select></td></tr>
    <tr valign="top"><td align="left">Zimmer:</td><td align="left"><input type="text" size="7" name="zimmer" value="'.$zimmer.'">&nbsp;(z.B. 2/N115)</td></tr>
    <tr valign="top"><td align="left">EMail:</td><td align="left"><input type="text" size="30" name="email" value="'.$email.'"></td></tr>
    <tr valign="top"><td align="left">Telefon:</td><td align="left"><input type="text" size="15" name="telefon" value="'.$telefon.'">&nbsp;(z.B. 0371/241144)</td></tr>
    <tr valign="top"><td align="left">Fax:</td><td align="left"><input type="text" size="15" name="fax" value="'.$fax.'">&nbsp;(z.B. 0371/241134)</td></tr>
    <tr valign="top"><td align="left">Sprechstunde:</td><td align="left"><textarea name="sprechstunde" cols="30" rows="3">'.$sprechstunde.'</textarea></td></tr>
	</table>
  </td></tr>

  <tr align="left"><td class="grau"><b>Foto</b></td></tr>
  <tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">
	'; if($photo!=''){echo '<img src="'.$img.$photo.'" border="0"><br><input type="checkbox" name="delphoto">&nbsp;Bild l�schen<br>';} echo '<input type="file" size="30" name="photo"><input type="hidden" name="oldphoto" value="'.$photo.'">
 </td></tr>

  <tr align="left"><td class="grau"><b>Lebenslauf</b></td></tr>
  <tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;"><textarea name="lebenslauf" rows="5" cols="60">'.$lebenslauf.'</textarea></td></tr>

  <tr align="left"><td class="grau"><b>Ver�ffentlichungen</b></td></tr>
  <tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">
  		<p align="right"><a href="mi_prof_publik.php" target="_blank">neue Ver�ffentlichungen hinzuf�gen &gt;&gt;&gt;</a></p>
        <select name="publik_nr_a[]" size="5" multiple>';
        $abfrage = "SELECT id, datum, name from mi_prof_publik order by 1-datum";
        $erg = mysql_query($abfrage);
        while (list($id, $datum, $name) = mysql_fetch_row($erg)){
        echo '<option value="'.$id.'"'; if(is_in($publik_nr,$id)=='true'){echo ' selected';} echo '>'.date_conf($datum).' - '.kurzundknapp($name,60).'</option>';
        }
    echo '
        </select><br>(Auswahl von mehreren Ver�ffentlichungen durch dr�cken von [Strg])
  </td></tr>
</table>
</center>

<input type="submit" value="Eintragen">
</form>
';

break;

case("add2"):

	$photo=$_FILES["photo"]["tmp_name"];

        // "Funktion" setzt holt alle Variablen die mit POST �bergeben werden
        // (n�tig wenn rester_globals = off ist
    $vars="name,vname,titell,zimmer,telefon,fax,email,funktion,anfang1,anfang2,ende1,ende2,lebenslauf,publik_nr_a,sprechstunde";
    $var=explode(",",$vars);
    $i=0;
    while($var[$i]!=''){
    $$var[$i]=$_POST["$var[$i]"];
    $i++;
    }

    $publik_nr = add($publik_nr_a);
    if($anfang1=='x'){$anfang='';}
    else{$anfang=$anfang2.$anfang1;}
    if($ende1=='x'){$ende='';}
    else{$ende=$ende2.$ende1;}

	$abfrage = "insert into mi_prof set name='$name', vname='$vname', titel='$titell', zimmer='$zimmer', telefon='$telefon', fax='$fax', email='$email', funktion='$funktion', anfang='$anfang', ende='$ende', lebenslauf='$lebenslauf', publik_nr='$publik_nr', sprechstunde='$sprechstunde'";
    $erg = mysql_query($abfrage);
    if($erg){echo 'Erfolgreich eingetragen. ';$aktion='';}
	$id=mysql_insert_id(); // ID die zum INSERT geh�rt

	if(is_uploaded_file($photo)){$photo = upload($photo,$_FILES["photo"][type],$id,$img,"mi_prof_");
	$abfrage = "update mi_prof set photo='$photo' where id='$id'";
    $erg = mysql_query($abfrage);}

	if($funktion==1 or $funktion==5){ // es darf nur einen aktiven Lehrstuhlinhaber/Vertreter geben

	$nr=$id;
	$titelbildname="mi_prof_titel_".$nr.".png";
	text_pic($titell.' '.$vname.' '.$name,"prof",$img,$titelbildname);

	$semester=akt_semester();
	$prev_anfang=prev_sem($anfang);
	$abfrage1 = "update mi_prof set ende='$prev_anfang' where (funktion=1 or funktion=5) and (ende>'$prev_anfang' or ende='') and not(anfang>'$prev_anfang') and not(id='$nr')";
	$erg = mysql_query($abfrage1);

	if($ende==''){
	$abfrage = "select min(anfang) from mi_prof where (funktion=1 or funktion=5) and anfang>'$anfang'";
	$erg = mysql_query($abfrage);
	(list($anfang2) = mysql_fetch_row($erg));
	$abfrage = "update mi_prof set ende='$anfang2' where id='$nr'";
	$erg = mysql_query($abfrage);
	if($anfang2!=''){echo '<p><b>Lehrstuhlinhaber/Vertreter wurde autmatisch geschlossen, da neuere Lehrstuhlinhaber/Vertreter aktiv ist.</b></p>';}	
	}
	}

break;

case("edit2"):

        // "Funktion" setzt holt alle Variablen die mit POST �bergeben werden
        // (n�tig wenn rester_globals = off ist
    $vars="name,vname,titell,zimmer,telefon,fax,email,funktion,anfang1,anfang2,ende1,ende2,lebenslauf,oldphoto,delphoto,publik_nr_a,sprechstunde";
    $var=explode(",",$vars);
    $i=0;
    while($var[$i]!=''){
    $$var[$i]=$_POST["$var[$i]"];
    $i++;
    }

        $photo_i=$_FILES["photo"]["tmp_name"];

    $publik_nr = add($publik_nr_a);
    if($anfang1=='x'){$anfang='';}
    else{$anfang=$anfang2.$anfang1;}
    if($ende1=='x'){$ende='';}
    else{$ende=$ende2.$ende1;}
    if(($oldphoto!='') and (is_uploaded_file($photo_i) or $delphoto!='')){
        $erg = unlink($img.$oldphoto);$oldphoto=$photo='';}
    if(is_uploaded_file($photo_i)){$photo = upload($photo_i,$_FILES["photo"][type],$nr,$img,"mi_prof_");}
    else{$photo=$oldphoto;}
    $abfrage = "update mi_prof set name='$name', vname='$vname', titel='$titell', zimmer='$zimmer', telefon='$telefon', fax='$fax', email='$email', funktion='$funktion', anfang='$anfang', ende='$ende', photo='$photo', lebenslauf='$lebenslauf', publik_nr='$publik_nr', sprechstunde='$sprechstunde' where id='$nr'";
    $erg = mysql_query($abfrage);
    if($erg){echo 'Erfolgreich ge�ndert';$aktion='';}


	if($funktion==1 or $funktion==5){ // es darf nur einen aktiven Lehrstuhlinhaber/Vertreter geben

	$titelbildname="mi_prof_titel_".$nr.".png";
	text_pic($titell.' '.$vname.' '.$name,"prof",$img,$titelbildname);

	$semester=akt_semester();
	$prev_anfang=prev_sem($anfang);
	$abfrage1 = "update mi_prof set ende='$prev_anfang' where (funktion=1 or funktion=5) and (ende>'$prev_anfang' or ende='') and not(anfang>'$prev_anfang') and not(id='$nr')";
	$erg = mysql_query($abfrage1);

	if($ende==''){
	$abfrage = "select min(anfang) from mi_prof where (funktion=1 or funktion=5) and anfang>'$anfang'";
	$erg = mysql_query($abfrage);
	(list($anfang2) = mysql_fetch_row($erg));
	$abfrage = "update mi_prof set ende='$anfang2' where id='$nr'";
	$erg = mysql_query($abfrage);
	if($anfang2!=''){echo '<p><b>Lehrstuhlinhaber/Vertreter wurde autmatisch geschlossen, da neuere Lehrstuhlinhaber/Vertreter aktiv ist.</b></p>';}
	}
	}
break;

case("del"):
$abfrage = "SELECT id, name, vname, telefon, email, funktion from mi_prof where id='$nr'";
$erg = mysql_query($abfrage);
(list($id, $name, $vname, $telefon, $email, $funktion) = mysql_fetch_row($erg));
$funktion=mi_prof($funktion);

echo '
<table width="100%" cellspacing="2" cellpadding="1" border="0">
<tr><th>Nachname</th><th>Vorname</th><th>Funktion</th><th>eMail</th><th>Telefon</th></tr>
<tr><td>'.$name.'</td><td>'.$vname.'</td><td>'.$funktion.'</td><td>'.$email.'</td><td>'.$telefon.'</td></tr>
</table>
<p>Eintrag wirklich l�schen?&nbsp;<a href="?aktion=show">Nein</a>&nbsp;<a href="?aktion=del2&nr='.$nr.'">Ja</a></p>';
break;

case("del2"):
$abfrage = "SELECT photo from mi_prof where id='$nr'";
$erg = mysql_query($abfrage);
(list($photo) = mysql_fetch_row($erg));
if($photo!=''){unlink($img.$photo);}

$titelimg= $img.'mi_prof_titel_'.$nr.'.png';
if(is_readable($titelimg)){
unlink($titelimg);
}

$abfrage = "DELETE from mi_prof where id='$nr'";
$erg = mysql_query($abfrage);
if($erg=='1'){echo 'Erfolgreich gel�scht.';$aktion='';}
break;
}

if($aktion=='' or $aktion=='show'){

$order=$_GET["order"];

echo '<p><a href="?aktion=add">Eintrag hinzuf�gen</a></p>

<table width="100%" cellspacing="2" cellpadding="1" border="0">
<tr><th>Optionen</th><th>Nachname&nbsp;<a href="?aktion=show&order=1-name"><img src="img/down.gif" border="0"></a>&nbsp;<a href="?aktion=show&order=name"><img src="img/up.gif" border="0"></a></th><th>Vorname&nbsp;<a href="?aktion=show&order=1-vname"><img src="img/down.gif" border="0"></a>&nbsp;<a href="?aktion=show&order=vname"><img src="img/up.gif" border="0"></a></th><th>Funktion&nbsp;<a href="?aktion=show&order=1-funktion"><img src="img/down.gif" border="0"></a>&nbsp;<a href="?aktion=show&order=funktion"><img src="img/up.gif" border="0"></a></th><th>Anfang&nbsp;<a href="?aktion=show&order=1-anfang"><img src="img/down.gif" border="0"></a>&nbsp;<a href="?aktion=show&order=anfang"><img src="img/up.gif" border="0"></a></th><th>Ende&nbsp;<a href="?aktion=show&order=1-ende"><img src="img/down.gif" border="0"></a>&nbsp;<a href="?aktion=show&order=ende"><img src="img/up.gif" border="0"></a></th></tr>';
$abfrage = "SELECT id, name, vname, anfang, ende, funktion from mi_prof";
if($order==''){$order='name';}
$abfrage.=' order by '.$order;
$erg = mysql_query($abfrage);
while (list($id, $name, $vname, $anfang, $ende, $funktion) = mysql_fetch_row($erg)){
$funktion=mi_prof($funktion);
if($i==1){$bgcolor='grau';$i=0;}else{$bgcolor='white';$i=1;}
echo '<tr class="'.$bgcolor.'"><th><a href="?aktion=add&nr='.$id.'"><img 
src="img/edit.gif" border="0" alt="Eintrag bearbeiten" title="Eintrag bearbeiten"></a>&nbsp;&nbsp;<a href="?aktion=del&nr='.$id.'"><img src="img/del.gif" border="0" alt="Eintrag l�schen" title="Eintrag l�schen"></a></th><td>'.$name.'</td><td>'.$vname.'</td><td>'.$funktion.'</td><td>'.$anfang.'</td><td>'.$ende.'</td></tr>';
}
echo '</table>';
}


}
else{ // kein Zutritt
include("keinzutritt.php");
} 
?>
