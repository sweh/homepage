<?php
require_once('../config.inc'); seite(__FILE__);

if ($_SESSION["login"] == "true"){ 

$img="../sonstig/veranstaltung/img/";

echo '<center><img src="'.$img.'mi_veranstaltungen.png" border="0" align="center"></center>';

$aktion=$_GET["aktion"];
$nr=$_GET["nr"];

switch($aktion){
case("add"):

	if($nr!=''){
		$aktion='edit';
		$abfrage = "SELECT name, rubrik, beschreibung, link, pid, anfang, ende, bild from mi_veranstaltung where id='$nr'";
		$erg = mysql_query($abfrage);
		(list($name, $rubrik, $beschreibung, $link, $pid, $anfang, $ende, $bild) = mysql_fetch_row($erg));
	$date=timestamp_to_date($anfang);
	$datum=explode('.', $date);
	$a1=$datum[0];$a2=$datum[1];$a3=$datum[2];
	$date=timestamp_to_time($anfang);
	$datum=explode(':', $date);
	$a4=$datum[0];$a5=$datum[1];
	$date=timestamp_to_date($ende);
	$datum=explode('.', $date);
	$e1=$datum[0];$e2=$datum[1];$e3=$datum[2];
	$date=timestamp_to_time($ende);
	$datum=explode(':', $date);
	$e4=$datum[0];$e5=$datum[1];

	}

?>
	<script type="text/javascript">
	<!--
	function chkFormular()
	{
	if(document.Formular.name.value == "")  {
	alert("Bitte Veranstaltungsnamen eingeben!");
	document.Formular.name.focus();
	return false;
	}

	if(document.Formular.a3.value.length < 4)  {
	alert("Jahr muss vierstellig sein! (z.B. 2004)");
	document.Formular.a3.focus();
	return false;
	}

	var chkZ = 1;
	for(i=0;i<document.Formular.a1.value.length;++i)
	if(document.Formular.a1.value.charAt(i) < "0"
	|| document.Formular.a1.value.charAt(i) > "9")
		chkZ = -1;
	if(chkZ == -1) {
	alert("Anfang (Tag) ist keine Zahl!");
	document.Formular.a1.focus();
	return false;
	}

	var chkZ = 1;
	for(i=0;i<document.Formular.a2.value.length;++i)
	if(document.Formular.a2.value.charAt(i) < "0"
	|| document.Formular.a2.value.charAt(i) > "9")
		chkZ = -1;
	if(chkZ == -1) {
	alert("Anfang (Monat) keine Zahl!");
	document.Formular.a2.focus();
	return false;
	}

	var chkZ = 1;
	for(i=0;i<document.Formular.a3.value.length;++i)
	if(document.Formular.a3.value.charAt(i) < "0"
	|| document.Formular.a3.value.charAt(i) > "9")
		chkZ = -1;
	if(chkZ == -1) {
	alert("Anfang (Jahr) keine Zahl!");
	document.Formular.a3.focus();
	return false;
	}

	var chkZ = 1;
	for(i=0;i<document.Formular.a4.value.length;++i)
	if(document.Formular.a4.value.charAt(i) < "0"
	|| document.Formular.a4.value.charAt(i) > "9")
		chkZ = -1;
	if(chkZ == -1) {
	alert("Anfang (Stunde) keine Zahl!");
	document.Formular.a4.focus();
	return false;
	}

	var chkZ = 1;
	for(i=0;i<document.Formular.a5.value.length;++i)
	if(document.Formular.a5.value.charAt(i) < "0"
	|| document.Formular.a5.value.charAt(i) > "9")
		chkZ = -1;
	if(chkZ == -1) {
	alert("Anfang (Minuten) keine Zahl!");
	document.Formular.a5.focus();
	return false;
	}

	if(document.Formular.e3.value.length < 4)  {
	alert("Jahr muss vierstellig sein! (z.B. 2004)");
	document.Formular.e3.focus();
	return false;
	}

	var chkZ = 1;
	for(i=0;i<document.Formular.e1.value.length;++i)
	if(document.Formular.e1.value.charAt(i) < "0"
	|| document.Formular.e1.value.charAt(i) > "9")
		chkZ = -1;
	if(chkZ == -1) {
	alert("Ende (Tag) ist keine Zahl!");
	document.Formular.e1.focus();
	return false;
	}

	var chkZ = 1;
	for(i=0;i<document.Formular.e2.value.length;++i)
	if(document.Formular.e2.value.charAt(i) < "0"
	|| document.Formular.e2.value.charAt(i) > "9")
		chkZ = -1;
	if(chkZ == -1) {
	alert("Ende (Monat) keine Zahl!");
	document.Formular.e2.focus();
	return false;
	}

	var chkZ = 1;
	for(i=0;i<document.Formular.e3.value.length;++i)
	if(document.Formular.e3.value.charAt(i) < "0"
	|| document.Formular.e3.value.charAt(i) > "9")
		chkZ = -1;
	if(chkZ == -1) {
	alert("Ende (Jahr) keine Zahl!");
	document.Formular.e3.focus();
	return false;
	}

	var chkZ = 1;
	for(i=0;i<document.Formular.e4.value.length;++i)
	if(document.Formular.e4.value.charAt(i) < "0"
	|| document.Formular.e4.value.charAt(i) > "9")
		chkZ = -1;
	if(chkZ == -1) {
	alert("Ende (Stunde) keine Zahl!");
	document.Formular.e4.focus();
	return false;
	}

	var chkZ = 1;
	for(i=0;i<document.Formular.e5.value.length;++i)
	if(document.Formular.e5.value.charAt(i) < "0"
	|| document.Formular.e5.value.charAt(i) > "9")
		chkZ = -1;
	if(chkZ == -1) {
	alert("Ende (Minuten) keine Zahl!");
	document.Formular.e5.focus();
	return false;
	}
	}
	-->
	</script>
<?php
if($link!=''){$link=substr($link,7);} 

echo '
	<form name="Formular" action="?aktion='.$aktion.'2&nr='.$nr.'" method="POST" enctype=multipart/form-data onSubmit="return chkFormular()">
	<center><table border="0" width="80%" align="center">
	<tr align="left"><th><b>Name:</b>&nbsp;<input type="text" size="60" name="name" value="'.$name.'"></th></tr>
	<tr align="left"><td class="grau"><b>Rubrik:</b></td>
	<tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">
		<select name="rubrik">
		<option value="0"'; if($rubrik==0){echo ' selected';} echo '>Sonstiges</option>
		<option value="1"'; if($rubrik==1){echo ' selected';} echo '>Kolloquium</option>
		<option value="2"'; if($rubrik==2){echo ' selected';} echo '>Pr�sentation</option>
		<option value="3"'; if($rubrik==3){echo ' selected';} echo '>Seminar</option>
		<option value="4"'; if($rubrik==4){echo ' selected';} echo '>Feierlichkeit</option>
		</select>
	</td></tr>
	<tr align="left"><td class="grau"><b>Anfang:</b></td>
	<tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;"><input type="text" name="a1" size="2" value="'.$a1.'"><input type="text" name="a2" size="2" value="'.$a2.'"><input type="text" name="a3" size="4" value="'.$a3.'">&nbsp;&nbsp;<input type="text" name="a4" size="2" value="'.$a4.'">:<input type="text" name="a5" size="2" value="'.$a5.'">Uhr</td></tr>
	<tr align="left"><td class="grau"><b>Ende:</b></td>
	<tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;"><input type="text" name="e1" size="2" value="'.$e1.'"><input type="text" name="e2" size="2" value="'.$e2.'"><input type="text" name="e3" size="4" value="'.$e3.'">&nbsp;&nbsp;<input type="text" name="e4" size="2" value="'.$e4.'">:<input type="text" name="e5" size="2" value="'.$e5.'">Uhr</td></tr>
	<tr align="left"><td class="grau"><b>Beschreibung:</b></td>
	<tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;"><textarea name="beschreibung" cols="60" rows="5">'.$beschreibung.'</textarea></td></tr>
	<tr align="left"><td class="grau"><b>Teilnehmer:</b></td>
	<tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">
		<p align="right"><a href="mi_prof.php?aktion=add" target="_blank">neue Person hinzuf�gen&nbsp;&gt;&gt;&gt;</a></p>
        <select name="pid_a[]" size="5" multiple>';
        $abfrage = "SELECT id, vname, name, publik_nr from mi_prof order by name";
        $erg = mysql_query($abfrage);
        while (list($id, $vname, $name, $publik_nr) = mysql_fetch_row($erg)){
        echo '<option value="'.$id.'"'; if(is_in($pid,$id)=='true'){echo ' selected';} echo '>'.$name.', '.$vname.'</option>';
        }
    echo '
        </select><br>(Auswahl von mehreren Teilnehmern durch dr�cken von [Strg])
	</td></tr>
	<tr align="left"><td class="grau"><b>Link:</b></td>
	<tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">http://<input type="text" name="link" size="60" value="'.$link.'"></td></tr>
    <tr align="left"><td class="grau"><b>Bild:</b></td>
    <tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">'; if($bild!=''){echo '<img src="'.$img.$bild.'" border="0"><input type="checkbox" name="delbild">&nbsp;Bild l�schen<br>';} echo '<input type="file" size="30" name="bild"><input type="hidden" name="oldbild" value="'.$bild.'"></td></tr> 
	</table></center>
    <input type="submit" value="Eintragen">
	</form>
';
break;

case("add2"):

    $bild=$_FILES["bild"]["tmp_name"]; 

        // "Funktion" setzt holt alle Variablen die mit POST �bergeben werden
        // (n�tig wenn rester_globals = off ist
    $vars="rubrik,name,beschreibung,a1,a2,a3,a4,a5,e1,e2,e3,e4,e5,pid_a,link";
    $var=explode(",",$vars);
    $i=0;
    while($var[$i]!=''){
    $$var[$i]=$_POST["$var[$i]"];
    $i++;
    }

    $pid = add($pid_a);
	if($link!=''){$link='http://'.$link;}
	$anfang=date_to_timestamp($a3.'-'.$a2.'-'.$a1.'-'.$a4.'-'.$a5);
	$ende=date_to_timestamp($e3.'-'.$e2.'-'.$e1.'-'.$e4.'-'.$e5);

	$abfrage = "insert into mi_veranstaltung set rubrik='$rubrik', name='$name', beschreibung='$beschreibung', pid='$pid', anfang='$anfang', ende='$ende', link='$link'";
    $erg = mysql_query($abfrage);
    if($erg){echo 'Erfolgreich eingetragen';$aktion='';}

	$id=mysql_insert_id(); // ID die zum INSERT geh�rt
    if(is_uploaded_file($bild)){
		$bild = upload($bild,$_FILES["bild"][type],$id,$img,"mi_veranstaltung_");
		$abfrage = "update mi_veranstaltung set bild='$bild'";
    	$erg = mysql_query($abfrage);
		if($erg){echo ' Bild erfolgreich hochgeladen.';$aktion='';}
	}
break;

case("edit2"):

    $bild_i=$_FILES["bild"]["tmp_name"]; 

		// "Funktion" setzt holt alle Variablen die mit POST �bergeben werden
		// (n�tig wenn rester_globals = off ist
    $vars="rubrik,name,beschreibung,oldbild,delbild,a1,a2,a3,a4,a5,e1,e2,e3,e4,e5,pid_a,link";
	$var=explode(",",$vars);
	$i=0;
	while($var[$i]!=''){
	$$var[$i]=$_POST["$var[$i]"];
	$i++;
	}

    $pid = add($pid_a);
	if($link!=''){$link='http://'.$link;}
	$anfang=date_to_timestamp($a3.'-'.$a2.'-'.$a1.'-'.$a4.'-'.$a5);
	$ende=date_to_timestamp($e3.'-'.$e2.'-'.$e1.'-'.$e4.'-'.$e5);

    if(($oldbild!='') and (is_uploaded_file($bild_i) or $delbild!='')){
        $erg = unlink($img.$oldbild);$oldbild=$bild='';}
    if(is_uploaded_file($bild_i)){$bild = upload($bild_i,$_FILES["bild"][type],$id,$img,"mi_veranstaltung_");}
    else{$bild=$oldbild;}

	$abfrage = "update mi_veranstaltung set rubrik='$rubrik', name='$name', beschreibung='$beschreibung', pid='$pid', anfang='$anfang', ende='$ende', link='$link', bild='$bild' where id='$nr'";
    $erg = mysql_query($abfrage);
    if($erg){echo 'Erfolgreich ge�ndert.';$aktion='';}
break;

case("del"):
$abfrage = "SELECT id, name, anfang, ende, link from mi_veranstaltung where id='$nr'";
$erg = mysql_query($abfrage);
(list($id, $name, $anfang, $ende, $link) = mysql_fetch_row($erg));

echo '
<table width="100%" cellspacing="2" cellpadding="1" border="0">
<tr><th>Name</th><th>Anfang</th><th>Ende</th></tr>
<tr><td>'; if($link!='http://'){echo '<a href="'.$link.'" target="_blank">'.kurzundknapp($name,50).'</a>';} else {echo kurzundknapp($name,30);}echo '</td><td>'.timestamp_to_date($anfang).' '.timestamp_to_time($anfang).'</td><td>'.timestamp_to_date($ende).' '.timestamp_to_time($ende).'</td></tr>
</table>
<p>Eintrag wirklich l�schen?&nbsp;<a href="?aktion=show">Nein</a>&nbsp;<a href="?aktion=del2&nr='.$nr.'">Ja</a></p>';
break;

case("del2"):
$abfrage = "SELECT bild from mi_veranstaltung where id='$nr'";
$erg = mysql_query($abfrage);
(list($bild) = mysql_fetch_row($erg));
if($bild!=''){unlink($img.$bild);}

$abfrage = "DELETE from mi_veranstaltung where id='$nr'";
$erg = mysql_query($abfrage);
if($erg=='1'){echo 'Erfolgreich gel�scht.';$aktion='';}
break;
}


if($aktion=='' or $aktion=='show'){

$order=$_GET["order"];

echo '<p><a href="?aktion=add">Eintrag hinzuf�gen</a></p>

<table width="100%" cellspacing="2" cellpadding="1" border="0">
<tr><th>Optionen</th><th>Name&nbsp;<a href="?aktion=show&order=1-name"><img src="img/down.gif" border="0"></a>&nbsp;<a href="?aktion=show&order=name"><img src="img/up.gif" border="0"></a></th><th>Anfang&nbsp;<a href="?aktion=show&order=1-anfang"><img src="img/down.gif" border="0"></a>&nbsp;<a href="?aktion=show&order=anfang"><img src="img/up.gif" border="0"></a></th><th>Ende&nbsp;<a href="?aktion=show&order=1-ende"><img src="img/down.gif" border="0"></a>&nbsp;<a href="?aktion=show&order=ende"><img src="img/up.gif" border="0"></a></th></tr>';
$abfrage = "SELECT id, name, anfang, ende, link from mi_veranstaltung";
if($order==''){$order='name';}
$abfrage.=' order by '.$order;
$erg = mysql_query($abfrage);
while (list($id, $name, $anfang, $ende, $link) = mysql_fetch_row($erg)){
if($i==1){$bgcolor='grau';$i=0;}else{$bgcolor='white';$i=1;}
echo '<tr class="'.$bgcolor.'"><th><a href="?aktion=add&nr='.$id.'"><img 
src="img/edit.gif" border="0" alt="Eintrag bearbeiten" title="Eintrag bearbeiten"></a>&nbsp;&nbsp;<a href="?aktion=del&nr='.$id.'"><img src="img/del.gif" border="0" alt="Eintrag l�schen" title="Eintrag l�schen"></a></th><td>'; if($link!='http://' AND $link!=''){echo '<a href="'.$link.'" target="_blank">'.kurzundknapp($name,30).'</a>';} else {echo kurzundknapp($name,50);}echo '</td><td>'.timestamp_to_date($anfang).' '.timestamp_to_time($anfang).'</td><td>'.timestamp_to_date($ende).' '.timestamp_to_time($ende).'</td></tr>';
}
echo '</table>';
}

}
else{ // kein Zutritt
include("keinzutritt.php");
} 
?>
