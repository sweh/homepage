<?php
require_once('../config.inc'); seite(__FILE__);

if ($_SESSION["login"] == "true"){

$img = "../forschung/img/";
$doc = "../forschung/doc/";

echo '<br>
<center><img src="'.$img.'mi_forschung.png" border="0" align="center"></center>';

$aktion=$_GET["aktion"];
$nr=$_GET["nr"];

switch($aktion){
case("add"):

    if($nr!=''){
        $aktion='edit';
        $abfrage = "SELECT name, anfang, ende, foerderung, literatur,anhang, beschreibung, pid, link, bild from mi_forschung where id='$nr'";
        $erg = mysql_query($abfrage);
        (list($name, $anfang, $ende, $foerderung, $literatur,$anhang, $beschreibung, $pid, $link, $bild) = mysql_fetch_row($erg));
	$date=timestamp_to_date($datum);
	$datuma=explode('.', $date);
	$datum1=$datuma[0];$datum2=$datuma[1];$datum3=$datuma[2];
    }
?>
	<script type="text/javascript">
	<!--
	function chkFormular()
	{
	if(document.Formular.name.value == "")  {
	alert("Bitte Namen eingeben!");
	document.Formular.name.focus();
	return false;
	}
	}
	-->
	</script>
<?php
if($link!=''){$link=substr($link,7);}

echo '
    <form name="Formular" action="?aktion='.$aktion.'2&nr='.$nr.'" method="POST" enctype=multipart/form-data onSubmit="return chkFormular()">
	<center>
	<table border="0" width="80%" align="center">
	<tr align="left"><th><b>Name:</b>&nbsp;<input type="text" size="60" name="name" value="'.$name.'"></th></tr>
    <tr align="left"><td class="grau"><b>Beginn:</b></td></tr>
	<tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;"><select name="anfang"><option value="">-</option>';$jahr=jahre(1990,1);
        for($i=1;$i<$jahr[0]+1;$i++){echo '<option value='.$jahr[$i]; if($jahr[$i]==$anfang){echo ' selected';} echo '>'.$jahr[$i].'</option>';}
    echo '</select></td></tr>
    <tr align="left"><td class="grau"><b>Ende:</b></td></tr>
	<tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;"><select name="ende"><option value="">-</option>';$jahr=jahre(1999,5);
        for($i=1;$i<$jahr[0]+1;$i++){echo '<option value='.$jahr[$i]; if($jahr[$i]==$ende){echo ' selected';} echo '>'.$jahr[$i].'</option>';}
    echo '</select></td></tr>
	<tr align="left"><td class="grau"><b>Beschreibung:</b></td></tr>
	<tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;"><textarea name="beschreibung" rows="5" cols="60">'.$beschreibung.'</textarea></td></tr>
	<tr align="left"><td class="grau"><b>Link:</b></td></tr>
	<tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">http://<input type="text" name="link" size="60" value="'.$link.'"></td></tr>
	<tr align="left"><td class="grau"><b>Mitwirkende:</b></td></tr>
	<tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">
        <select name="pid_a[]" size="5" multiple>';
        $abfrage = "SELECT id, vname, name, publik_nr from mi_prof order by name";
        $erg = mysql_query($abfrage);
        while (list($id, $vname, $name, $publik_nr) = mysql_fetch_row($erg)){
        echo '<option value="'.$id.'"'; if(is_in($pid,$id)=='true'){echo ' selected';} echo '>'.$name.', '.$vname.'</option>';
        }
    echo '
        </select><br>(Auswahl von mehreren Autoren durch dr�cken von [Strg])
	</td></tr>
	<tr align="left"><td class="grau"><b>F�rderung:</b></td></tr>
	<tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;"><input type="text" size="60" name="foerderung" value="'.$foerderung.'"></td></tr>
	<tr align="left"><td class="grau"><b>Literatur:</b></td>
	<tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;"><input type="text" size="60" name="literatur" value="'.$literatur.'"></td></tr>
	<tr align="left"><td class="grau"><b>Anhang: (PDF/ZIP)</b></td>
	<tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">'; if($anhang!=''){echo '<a href="'.$doc.$anhang.'" target="_blank"><b>Anhang vorhanden</b> ('.datei_typ($anhang).' - '.round(filesize($doc.$anhang)/1000).'k)</a>  <input type="checkbox" name="delanhang">&nbsp;Anhang l�schen<br>';} echo '<input type="file" size="30" name="anhang"><input type="hidden" name="oldanhang" value="'.$anhang.'"></td></tr>
	<tr align="left"><td class="grau"><b>Bild:</b></td>
	<tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">'; if($bild!=''){echo '<img src="'.$img.$bild.'" border="0"><input type="checkbox" name="delbild">&nbsp;Bild l�schen<br>';} echo '<input type="file" size="30" name="bild"><input type="hidden" name="oldbild" value="'.$bild.'"></td></tr>
	</table></center>
    <input type="submit" value="Eintragen">
    </form>
    ';
break;

case("add2"):

    $bild=$_FILES["bild"]["tmp_name"];
    $anhang=$_FILES["anhang"]["tmp_name"];


        // "Funktion" setzt holt alle Variablen die mit POST �bergeben werden
        // (n�tig wenn rester_globals = off ist
    $vars="name,pid_a,beschreibung,link,anfang,ende,literatur,foerderung";
    $var=explode(",",$vars);
    $i=0;
    while($var[$i]!=''){
    $$var[$i]=$_POST["$var[$i]"];
    $i++;
    }

    $pid = add($pid_a);
	if($link!=''){$link='http://'.$link;}

	$abfrage = "insert into mi_forschung set name='$name', beschreibung='$beschreibung', pid='$pid', link='$link', anfang='$anfang', ende='$ende', literatur='$literatur', foerderung='$foerderung'";
    $erg = mysql_query($abfrage);
    if($erg){echo 'Erfolgreich eingetragen';$aktion='';}
	$id=mysql_insert_id(); // ID die zum INSERT geh�rt

	$titelbildname="mi_forschung_titel_".$id.".png";
	text_pic($name,"forschung",$img,$titelbildname);

    if(is_uploaded_file($bild)){
		$bild = upload($bild,$_FILES["bild"][type],$id,$img,"mi_forschung_");
		$abfrage = "update mi_forschung set bild='$bild' where id='$id'";
    	$erg = mysql_query($abfrage);
		// if($erg){echo ' Bild erfolgreich hochgeladen.';$aktion='';}
	}

    if(is_uploaded_file($anhang)){
		$anhang = upload($anhang,$_FILES["anhang"][type],$id,$doc,"mi_forschung_");
		$abfrage = "update mi_forschung set anhang='$anhang' where id='$id'";
    	$erg = mysql_query($abfrage);
		// if($erg){echo ' Anhang erfolgreich hochgeladen.';$aktion='';}
	}

break;

case("edit2"):

    $bild_i=$_FILES["bild"]["tmp_name"];
    $anhang_i=$_FILES["anhang"]["tmp_name"];

        // "Funktion" setzt holt alle Variablen die mit POST �bergeben werden
        // (n�tig wenn rester_globals = off ist
    $vars="name,pid_a,delbild,oldbild,delanhang,oldanhang,beschreibung,link,anfang,ende,literatur,foerderung";
    $var=explode(",",$vars);
    $i=0;
    while($var[$i]!=''){
    $$var[$i]=$_POST["$var[$i]"];
    $i++;
    }

    $pid = add($pid_a);
	if($link!=''){$link='http://'.$link;}

	$titelbildname="mi_forschung_titel_".$nr.".png";
	text_pic($name,"forschung",$img,$titelbildname);

	if(($oldbild!='') and (is_uploaded_file($bild_i) or $delbild!='')){
        $erg = unlink($img.$oldbild);$oldbild=$bild='';}
    if(is_uploaded_file($bild_i)){$bild = upload($bild_i,$_FILES["bild"][type],$nr,$img,"mi_forschung_");}
    else{$bild=$oldbild;}

	if(($oldanhang!='') and (is_uploaded_file($anhang_i) or $delanhang!='')){
        $erg = unlink($doc.$oldanhang);$oldanhang=$anhang='';}
    if(is_uploaded_file($anhang_i)){$anhang = upload($anhang_i,$_FILES["anhang"][type],$nr,$doc,"mi_forschung_");}
    else{$anhang=$oldanhang;}

	$abfrage = "update mi_forschung set name='$name', beschreibung='$beschreibung', pid='$pid', link='$link', bild='$bild',anhang='$anhang', anfang='$anfang', ende='$ende', literatur='$literatur', foerderung='$foerderung' where id='$nr'";
	$erg = mysql_query($abfrage);
    if($erg){echo 'Erfolgreich ge�ndert.';$aktion='';}

break;

case("del"):

$abfrage = "SELECT id, name, anfang, ende, link from mi_forschung where id='$nr'";
$erg = mysql_query($abfrage);
(list($id, $name, $anfang, $ende, $beschreibung, $link) = mysql_fetch_row($erg));

echo '
<table width="100%" cellspacing="2" cellpadding="1" border="0">
<tr><th>Name</th><th>Anfang</th><th>Ende</th></tr>
<tr><td>'; if($link!='http://'){echo '<a href="'.$link.'" target="_blank">'.kurzundknapp($name,50).'</a>';} else {echo kurzundknapp($name,30);}echo '</td><td>'.$anfang.'</td><td>'.$ende.'</td></tr>
</table>
<p>Eintrag wirklich l�schen?&nbsp;<a href="?aktion=show">Nein</a>&nbsp;<a href="?aktion=del2&nr='.$nr.'">Ja</a></p>';
break;

case("del2"):
$abfrage = "SELECT bild, anhang from mi_forschung where id='$nr'";
$erg = mysql_query($abfrage);
(list($bild, $anhang) = mysql_fetch_row($erg));
if($bild!=''){unlink($img.$bild);}
if($anhang!=''){unlink($doc.$anhang);}

$titelimg= $img.'mi_forschung_titel_'.$nr.'.png';
if(is_readable($titelimg)){
unlink($titelimg);
}

$abfrage = "DELETE from mi_forschung where id='$nr'";
$erg = mysql_query($abfrage);
if($erg=='1'){echo 'Erfolgreich gel�scht.';$aktion='';
}
break;

}
if($aktion=='' or $aktion=='show'){

$order=$_GET["order"];

echo '<p><a href="?aktion=add">Eintrag hinzuf�gen</a></p>

<table width="100%" cellspacing="2" cellpadding="1" border="0">
<tr><th>Optionen</th><th>Name&nbsp;<a href="?aktion=show&order=1-name"><img src="img/down.gif" border="0"></a>&nbsp;<a href="?aktion=show&order=name"><img src="img/up.gif" border="0"></a></th><th>Anfang&nbsp;<a href="?aktion=show&order=1-anfang"><img src="img/down.gif" border="0"></a>&nbsp;<a href="?aktion=show&order=anfang"><img src="img/up.gif" border="0"></a></th><th>Ende&nbsp;<a href="?aktion=show&order=1-ende"><img src="img/down.gif" border="0"></a>&nbsp;<a href="?aktion=show&order=ende"><img src="img/up.gif" border="0"></a></th></tr>';
$abfrage = "SELECT id, name, anfang, ende, beschreibung, link from mi_forschung";
if($order==''){$order='name';}
$abfrage.=' order by '.$order;
$erg = mysql_query($abfrage);
while (list($id, $name, $anfang, $ende, $beschreibung, $link) = mysql_fetch_row($erg)){
if($i==1){$bgcolor='grau';$i=0;}else{$bgcolor='white';$i=1;}
echo '<tr class="'.$bgcolor.'"><th><a href="?aktion=add&nr='.$id.'"><img 
src="img/edit.gif" border="0" alt="Eintrag bearbeiten" title="Eintrag bearbeiten"></a>&nbsp;&nbsp;<a href="?aktion=del&nr='.$id.'"><img src="img/del.gif" border="0" alt="Eintrag l�schen" title="Eintrag l�schen"></a></th><td>'; if($link!='' and $link!='http://'){echo '<a href="'.$link.'" target="_blank">'.kurzundknapp($name,30).'</a>';} else {echo kurzundknapp($name,50);}echo '</td><td>'.$anfang.'</td><td>'.$ende.'</td></tr>';
}
echo '</table>';
}


}
else{ // kein Zutritt
include("keinzutritt.php");
}

?>
