<?php
##############################
#      praktikum.php         #
#        Adminseite          #
#      created by sweh       #
#  last update: 28.01.2004   #
##############################
?>
<script type="text/javascript">
	<!--
	function chkFormular()
	{
	if(document.Formular.vname.value == "")  {
	alert("Bitte einen Titel f�r das Praktikum eingeben!");
	document.Formular.vname.focus();
	return false;
	}
	}
	-->
</script>

<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" name="Formular" onSubmit="return chkFormular()">
	<?php
		// bearbeiten der Eintr�ge
		if (preg_match("/[0-9]$/", $_REQUEST["id"]))
		{
			$result_lehre_veranstaltung = mysql_query("SELECT einheit, vname, vart, vinhalt, vsem, vabschluss, vliteratur, vhinweise from mi_lehre_veranstaltung WHERE id = '".$_REQUEST["id"]."'");
			if (mysql_num_rows($result_lehre_veranstaltung))
			{
				while($row_veranstaltung = mysql_fetch_array($result_lehre_veranstaltung))
				{
					$lehre_veranstaltung_einheit = $row_veranstaltung["einheit"];
					$lehre_veranstaltung_vname = $row_veranstaltung["vname"];
					$lehre_veranstaltung_vart = $row_veranstaltung["vart"];
					$lehre_veranstaltung_vinhalt = $row_veranstaltung["vinhalt"];
					$lehre_veranstaltung_vsem = $row_veranstaltung["vsem"];
					$lehre_veranstaltung_vabschluss = $row_veranstaltung["vabschluss"];
					$lehre_veranstaltung_vliteratur = $row_veranstaltung["vliteratur"];
					$lehre_veranstaltung_vhinweise = $row_veranstaltung["vhinweise"];
				}
			$result_prof = mysql_query("SELECT vperson from mi_lehre_veranstaltung_zeit WHERE einheit = $lehre_veranstaltung_einheit LIMIT 1");
			if (@mysql_num_rows($result_prof))
				while($row_prof = mysql_fetch_array($result_prof))
					$lehre_material_pperson = $row_prof["vperson"];


				echo '<input type="hidden" name="id" value="'.$_REQUEST["id"].'">';
			}

		}

		if ($_POST["vname"])
			$lehre_vname = $_POST["vname"];
		else
			$lehre_vname = $lehre_veranstaltung_vname;
	?>
	<input type="hidden" name="eintragen" value="vorlesung">
	<?php
		if (!$_REQUEST["einheit"])
		{
			echo "<input type='hidden' name='praktikum' value='allein'>";
			mt_srand(time());
			$_POST["einheit"] = mt_rand(1,99999);
		}
	?>
	<input type="hidden" name="einheit" value="<?php echo $_POST["einheit"]; ?>">
	<input type="hidden" name="vname" value="<?php echo $lehre_vname; ?>">

	<table width=80% align="center">
		<tr>
			<td class="liniehell">
		    	<b><select name="vart" size="1">
						<option value="3" <?php if ($lehre_veranstaltung_vart == 3) echo 'selected="selected"'; ?>>Praktikum</option>
						<option value="4" <?php if ($lehre_veranstaltung_vart == 4) echo 'selected="selected"'; ?>>Seminar</option>
					</select>
 <input type="text" maxlength="255" name="vname" value="<?php echo $lehre_vname; ?>"></b>
		    </td>
		</tr>
		<tr valign="top">
			<td class="grau">
				<b>Lehrender:</b>
			</td>
		</tr>
		<tr>
			<td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">
				<select name="vperson" size="1">
					<?php
						$result_prof = mysql_query("SELECT id, name, vname, titel from mi_prof ORDER by id asc");
						if (mysql_num_rows($result_prof))
							while($row_prof = mysql_fetch_array($result_prof))
							{
								echo '<option value="'.$row_prof["id"].'" ';
								if ($row_prof["id"] == $lehre_material_pperson)
									echo 'selected="selected"';
								echo '>'.$row_prof["titel"].' '.$row_prof["vname"].' '.$row_prof["name"].'</option>';
							}
					?>
				</select>
				&nbsp;&nbsp;
				<a href="mi_prof.php?aktion=add" target="_blanc">Lehrenden hinzuf�gen</a>
		    </td>
		</tr>
		<tr>
			<td>
		    	<br>
		    </td>
		</tr>
		<tr>
			<td class="grau">
		    	<b>Inhalt:</b>
		    </td>
		</tr>
		<tr>
			<td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">
				<textarea name="vinhalt" cols="60" rows="8"><?php echo $lehre_veranstaltung_vinhalt; ?></textarea>   
		    </td>
		</tr>
		<tr>
			<td class="grau">
		    	<b>Literaturempfehlung:</b>
		    </td>
		</tr>
		<tr>
			<td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">
		    	<textarea name="vliteratur" cols="60" rows="8"><?php echo $lehre_veranstaltung_vliteratur; ?></textarea>
		      </td>
		</tr>
		<tr>
			<td class="grau">
		    	<b>Hinweise:</b>
		    </td>
		</tr>
		<tr>
			<td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">
		    	<textarea name="vhinweise" cols="60" rows="8"><?php echo $lehre_veranstaltung_vhinweise; ?></textarea>
		    </td>
		</tr>
		<tr>
			<td>
		    	<input type="submit" value="weiter">&nbsp;&nbsp;<input type="submit" name="akt_praktikum" value="aktualisieren">
		    </td>
		</tr>
	</table>
</form>

