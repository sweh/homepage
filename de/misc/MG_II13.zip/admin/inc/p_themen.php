<?php
##############################
#       p_themen.php         #
#        Adminseite          #
#      created by sweh       #
#  last update: 28.01.2004   #
##############################
?>
<script type="text/javascript">
	<!--
	function chkFormular()
	{
	if(document.Formular.pkomplex.value == "")  {
	alert("Bitte Komplex eingeben!");
	document.Formular.pkomplex.focus();
	return false;
	}
	else if(document.Formular.pthema.value == "")  {
	alert("Bitte Thema eingeben!");
	document.Formular.pthema.focus();
	return false;
	}
	}
	-->
</script>

<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" name="Formular" onSubmit="return chkFormular()">
	<?php
	// bearbeiten der Eintr�ge
		if (preg_match("/[0-9]$/", $_GET["id"]))
		{
			$result_lehre_material = mysql_query("SELECT pkomplex, pthema, pperson, pinhalt, pliteratur, phinweise from mi_lehre_veranstaltung_praktika WHERE id = '".$_GET["id"]."'");
			if (mysql_num_rows($result_lehre_material))
			{
				while($row_material = mysql_fetch_array($result_lehre_material))
				{
					$lehre_material_pkomplex = $row_material["pkomplex"];
					$lehre_material_pthema = $row_material["pthema"];
					$lehre_material_pperson = $row_material["pperson"];
					$lehre_material_pinhalt = $row_material["pinhalt"];
					$lehre_material_pliteratur = $row_material["pliteratur"];
					$lehre_material_phinweise = $row_material["phinweise"];
				}
		
				echo '<input type="hidden" name="id" value="'.$_GET["id"].'">';
			}
		
		}
		else
		{
		$result_lehre_material = mysql_query("SELECT vname from mi_lehre_veranstaltung WHERE einheit = '".$_REQUEST["einheit"]."' LIMIT 1");
		if(mysql_num_rows($result_lehre_material))
			while($row=mysql_fetch_array($result_lehre_material))
				$lehre_vname = $row["vname"];
		}
	?>

	<input type="hidden" name="eintragen" value="p_themen">
	<input type="hidden" name="einheit" value="<?php echo $_REQUEST["einheit"]; ?>">

	<table width=80%> 
		<tr>
			<td class="liniehell">      
		    	<b>Komplex: <input type="text" maxlength="30" name="pkomplex" value="<?php if (!$_GET["pkomplex"]) echo $lehre_material_pkomplex; else echo $_GET["pkomplex"]; ?>"></b> 
		    </td> 
		</tr> 
		<tr>
			<td> 
		    	<br> 
		    </td> 
		</tr> 
		<tr>
			<td class="grau"> 
		    	<b>Thema:</b> 
		    </td> 
		</tr> 
		<tr>
			<td class="zehn"> 
				<input type="text" maxlength="100" name="pthema" value="<?php echo $lehre_material_pthema; ?>">
		    </td> 
		</tr> 
		<tr valign="top">
			<td>
				Lehrender:
			</td>
		</tr>
		<tr>
			<td class="zehn">
				<select name="pperson" size="1">
					<?php
						$result_prof = mysql_query("SELECT id, name, vname, titel from mi_prof ORDER by id asc");
						if (mysql_num_rows($result_prof))
							while($row_prof = mysql_fetch_array($result_prof))
							{
								echo '<option value="'.$row_prof["id"].'" ';
								if ($row_prof["id"] == $lehre_material_pperson)
									echo 'selected="selected"';
								echo '>'.$row_prof["titel"].' '.$row_prof["vname"].' '.$row_prof["name"].'</option>';
							}
					?>
				</select>
				&nbsp;&nbsp;
				<a href="http://www-user.tu-chemnitz.de/~sweh/MG_II13/admin/mi_prof.php?aktion=add" target="_blanc">Lehrenden hinzuf�gen</a>
		    </td>
		</tr> 
		<tr>
			<td class="grau"> 
		    	<b>Inhalt:</b> 
		    </td> 
		</tr> 
		<tr>
			<td class="zehn">
		    	<textarea name="pinhalt" cols="60" rows="8"><?php echo $lehre_material_pinhalt; ?></textarea>
		    </td>
		</tr>
		<tr>
			<td class="grau"> 
		    	<b>Literaturempfehlung:</b> 
		    </td> 
		</tr> 
		<tr>
			<td class="zehn">
		    	<textarea name="pliteratur" cols="60" rows="8"><?php echo $lehre_material_pliteratur; ?></textarea>
		    </td>
		</tr>
		<tr>
			<td class="grau"> 
		    	<b>Hinweise:</b> 
		    </td> 
		</tr> 
		<tr>
			<td class="zehn">
		    	<textarea name="phinweise" cols="60" rows="8"><?php echo $lehre_material_phinweise; ?></textarea>
		    </td>
		</tr>	
		<tr>
			<td>
				<input type="submit" value="weiter" >&nbsp;&nbsp;<input type="submit" name="akt_p_themen" value="aktualisieren" title="Aktualisieren" >
		    </td>
		</tr>	
	</table>
</form>
