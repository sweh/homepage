<?php
##############################
#         datum.php          #
#        Adminseite          #
#      created by sweh       #
#  last update: 28.01.2004   #
##############################
?>
<script type="text/javascript">
	<!--
	function chkFormular()
	{
	if(document.Formular.vnr.value == "")  {
	alert("Bitte Vorlesungsnummer eingeben!");
	document.Formular.vnr.focus();
	return false;
	}
	else if(document.Formular.vbeginn.value == "")  {
	alert("Bitte Beginn eingeben!");
	document.Formular.vbeginn.focus();
	return false;
	}
	}
	-->
</script>

<form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>" name="Formular" onSubmit="return chkFormular()">
	<?php
		if (preg_match("/[0-9]$/", $_REQUEST["id"]))
		{
			$result_lehre_veranstaltung_extra = mysql_query("SELECT einheit, vnr, vart, vtag, vbeginn, vdauer, vwoche, vperson, vraum from mi_lehre_veranstaltung_zeit WHERE id = '".$_REQUEST["id"]."'");
			if (mysql_num_rows($result_lehre_veranstaltung_extra))
			{
				while ($row_extra = mysql_fetch_array($result_lehre_veranstaltung_extra))
				{
					$lehre_veranstaltung_einheit = $row_extra["einheit"];
					$lehre_veranstaltung_vnr = $row_extra["vnr"];
					$lehre_veranstaltung_vart = $row_extra["vart"];
					$lehre_veranstaltung_vtag = $row_extra["vtag"];
					$lehre_veranstaltung_vbeginn = $row_extra["vbeginn"];
					$lehre_veranstaltung_vdauer = $row_extra["vdauer"];
					$lehre_veranstaltung_vwoche = $row_extra["vwoche"];
					$lehre_veranstaltung_profid = $row_extra["vperson"];
					$lehre_veranstaltung_vraum = $row_extra["vraum"];
				}
				echo "<input type='hidden' name='id' value='".$_REQUEST["id"]."'>";
			}
		}
	?>
	<input type="hidden" name="eintragen" value="datum">
	<input type="hidden" name="einheit" value="<?php echo $_REQUEST["einheit"]; ?>">
	<table width=90% bgcolor="#CCE7E7">
		<tr>
			<td width="100">Art der Veranstaltung:</td>
			<td class="zehn">
				<select name="vart">
					<option value="1" <?php if ($lehre_veranstaltung_vart == "1") echo "selected=\"selected\""; ?>>Vorlesung</option>
					<option value="2" <?php if ($lehre_veranstaltung_vart == "2") echo "selected=\"selected\""; ?>>�bung</option>
					<option value="3" <?php if ($lehre_veranstaltung_vart == "3") echo "selected=\"selected\""; ?>>Praktikum</option>
					<option value="4" <?php if ($lehre_veranstaltung_vart == "4") echo "selected=\"selected\""; ?>>Seminar</option>
				</select>
			</td>
		</tr>
		<tr>
			<td>Vorlesungsnummer:</td>
			<td class="zehn">
				<input type="text" name="vnr" maxlength="7" value="<?php echo $lehre_veranstaltung_vnr; ?>">
			</td>
		</tr>
	    <tr>
			<td width="100">Wochentag:</td>
			<td class="zehn">
				<select name="vtag">
					<option value="Mo" <?php if ($lehre_veranstaltung_vtag == "Mo") echo "selected=\"selected\""; ?>>Montag</option>
					<option value="Di" <?php if ($lehre_veranstaltung_vtag == "Di") echo "selected=\"selected\""; ?>>Dienstag</option>
					<option value="Mi" <?php if ($lehre_veranstaltung_vtag == "Mi") echo "selected=\"selected\""; ?>>Mittwoch</option>
					<option value="Do" <?php if ($lehre_veranstaltung_vtag == "Do") echo "selected=\"selected\""; ?>>Donnerstag</option>
					<option value="Fr" <?php if ($lehre_veranstaltung_vtag == "Fr") echo "selected=\"selected\""; ?>>Freitag</option>
					<option value="Sa" <?php if ($lehre_veranstaltung_vtag == "Sa") echo "selected=\"selected\""; ?>>Samstag</option>
					<option value="So" <?php if ($lehre_veranstaltung_vtag == "So") echo "selected=\"selected\""; ?>>Sonntag</option>
				</select>
				&nbsp;&nbsp;
				<select name="vwoche">
					<option value="0" <?php if ($lehre_veranstaltung_vwoche == "0") echo "selected=\"selected\""; ?>>jede Woche</option>
					<option value="1" <?php if ($lehre_veranstaltung_vwoche == "1") echo "selected=\"selected\""; ?>>ungerade Woche</option>
					<option value="2" <?php if ($lehre_veranstaltung_vwoche == "2") echo "selected=\"selected\""; ?>> gerade Woche</option>
					<option value="3" <?php if ($lehre_veranstaltung_vwoche == "3") echo "selected=\"selected\""; ?>> Blockveranstaltung</option>
				</select>
			</td>
		</tr>
        <tr valign="top">
			<td>Beginn:</td>
            <td class="zehn">
				<input type="text" name="vbeginn" maxleght="5" value="<?php echo format_zeit($lehre_veranstaltung_vbeginn); ?>"> Beispiel: 9:15, 11:30
			</td>
		</tr>
        <tr valign="top">
			<td>Dauer:</td>
			<td class="zehn">
				<select name="vdauer" size="1">
				<?php
					$vdauer = "45";
					for ($i=1; $i<=15; $i++)
					{
						echo "<option value='$vdauer' ";
						if ($vdauer == $lehre_veranstaltung_vdauer)
							echo "selected='selected'";
						echo ">$vdauer</option>";
						$vdauer = $vdauer + "45";
					}
				?>
				</select> Minuten
			</td>
		</tr>
		<tr valign="top">
			<td>Raum:</td>
			<td class="zehn">
				<input type="text" name="vraum" maxleght="6" value="<?php echo $lehre_veranstaltung_vraum; ?>"> Beispiel: 1/316, 2/N115
			</td>
		</tr>
		<tr valign="top">
			<td>Lehrender:</td>
			<td class="zehn">
				<select name="vperson" size="1">
				<?php
					$result_prof = mysql_query("SELECT id, name, vname, titel from mi_prof ORDER by id asc");
					if (mysql_num_rows($result_prof))
						while($row_prof = mysql_fetch_array($result_prof))
						{
							echo '<option value="'.$row_prof["id"].'" ';
							if ($row_prof["id"] == $lehre_veranstaltung_profid)
								echo 'selected="selected"';
							echo '>'.$row_prof["titel"].' '.$row_prof["vname"].' '.$row_prof["name"].'</option>';
						}
				?>
				</select>
				&nbsp;&nbsp;
				<a href="http://www-user.tu-chemnitz.de/~sweh/MG_II13/admin/mi_prof.php?aktion=add" target="_blanc">Lehrenden hinzuf�gen</a>
		    </td>
		</tr> 
	</table>
	<input type="submit" value="weiter">&nbsp;&nbsp;&nbsp;<input type="submit" name="aktuelle_vorlesung" value="aktualisieren">
</form>