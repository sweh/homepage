<?php
##############################
#       arbeiten.php         #
#        Adminseite          #
#      created by sweh       #
#  last update: 28.01.2004   #
##############################
?>
<script type="text/javascript">
	<!--
	function chkFormular()
	{
	if(document.Formular.thema.value == "")  {
	alert("Bitte Thema eingeben!");
	document.Formular.thema.focus();
	return false;
	}
	}
	-->
</script>

<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" name="Formular" enctype="multipart/form-data" onSubmit="return chkFormular()">
	<?php
		// bearbeiten der Eintr�ge
		if (preg_match("/[0-9]$/", $_REQUEST["id"]))
		{
			$result_lehre_veranstaltung = mysql_query("SELECT typ, thema, pid, status, link, datei, inhalt, anforderungen from mi_lehre_arbeiten WHERE id = '".$_REQUEST["id"]."'");
			if (mysql_num_rows($result_lehre_veranstaltung))
			{
				while($row_veranstaltung = mysql_fetch_array($result_lehre_veranstaltung))
				{
					$lehre_veranstaltung_typ = $row_veranstaltung["typ"];
					$lehre_veranstaltung_thema = $row_veranstaltung["thema"];
					$lehre_veranstaltung_pid = $row_veranstaltung["pid"];
					$lehre_veranstaltung_status = $row_veranstaltung["status"];
					$lehre_veranstaltung_link = $row_veranstaltung["link"];
					$lehre_veranstaltung_datei = $row_veranstaltung["datei"];
					$lehre_veranstaltung_inhalt = $row_veranstaltung["inhalt"];
					$lehre_veranstaltung_anforderungen = $row_veranstaltung["anforderungen"];
				}

				echo '<input type="hidden" name="id" value="'.$_REQUEST["id"].'">';
			}

		}
	?>

	<input type="hidden" name="doit" value="eintragen">
	<table width=80% align="center">
		<tr>
			<td class="grau">
		    	<b>Art der Arbeit:</b>
		    </td>
		</tr>
		<tr>
			<td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">
				<select name="typ" size="1">
					<option value="1" <?php if ($lehre_veranstaltung_typ == 1) echo 'selected="selected"'; ?>>Studienarbeit</option>
					<option value="2" <?php if ($lehre_veranstaltung_typ == 2) echo 'selected="selected"'; ?>>Diplomarbeit</option>
				</select>
		    </td>
		</tr>
		<tr>
			<td class="grau">
		    	<b>Thema:</b>
		    </td>
		</tr>
		<tr>
			<td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">
				<input type="text" name="thema" maxlength="255" value="<?php echo $lehre_veranstaltung_thema; ?>" size="80">
		    </td>
		</tr>
		<tr>
			<td class="grau">
		    	<b>Person:</b>
		    </td>
		</tr>
		<tr>
			<td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">
				<select name="pid" size="1">
				<?php
					$result_prof = mysql_query("SELECT id, name, vname, titel from mi_prof ORDER by id asc");
						if (mysql_num_rows($result_prof))
							while($row_prof = mysql_fetch_array($result_prof))
							{
								echo '<option value="'.$row_prof["id"].'" ';
								if ($row_prof["id"] == $lehre_veranstaltung_pid)
									echo 'selected="selected"';
								echo '>'.$row_prof["titel"].' '.$row_prof["vname"].' '.$row_prof["name"].'</option>';
							}
				?>
				</select>
				&nbsp;&nbsp;
				<a href="mi_prof.php?aktion=add" target="_blanc">Person hinzuf�gen</a>
		    </td>
		</tr>
		<tr>
			<td class = "grau">
		    	<b>Status:</b>
		    </td>
		</tr>
		<tr>
			<td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">
				<select name="status" size="1">
					<option value="0" <?php if ($lehre_veranstaltung_status == 0) echo 'selected="selected"'; ?>>ausgeschrieben</option>
					<option value="1" <?php if ($lehre_veranstaltung_status == 1) echo 'selected="selected"'; ?>>in Bearbeitung</option>
					<option value="2" <?php if ($lehre_veranstaltung_status == 2) echo 'selected="selected"'; ?>>abgeschlossen</option>
				</select>
		    </td>
		</tr>
		<tr>
			<td class = "grau">
		    	<b>Link: (bitte mit "http://" beginnen)</b>
		    </td>
		</tr>
		<tr>
			<td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">
				<input type="text" name="link" maxlength="255" value="<?php echo $lehre_veranstaltung_link; ?>">
		    </td>
		</tr>
		<tr>
			<td class = "grau">
		    	<b>Datei:</b>
		    </td>
		</tr>
		<tr>
			<td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">
			<?php
				if ($lehre_veranstaltung_datei)
				{
			?>
				<p>aktuell hochgeladen: <a href="<?php echo "../lehre/diplom/".$lehre_veranstaltung_datei; ?>" target="_blanc"><?php echo $lehre_veranstaltung_datei ?></a></p>
				<input type="hidden" name="dateiname" value="<?php echo $lehre_veranstaltung_datei ?>">
			<?php
				}
			?>
				<p>Datei zum Hochladen ausw�hlen:</p>
				<input type="file" name="file">
		    </td>
		</tr>
		<tr>
			<td class="grau">
		    	<b>Inhalt:</b>
		    </td>
		</tr>
		<tr>
			<td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">
				<textarea name="inhalt" cols="60" rows="8"><?php echo $lehre_veranstaltung_inhalt; ?></textarea>   
		    </td>
		</tr>
		<tr>
			<td class="grau">
		    	<b>Anforderungen:</b>
		    </td>
		</tr>
		<tr>
			<td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">
				<textarea name="anforderungen" cols="60" rows="8"><?php echo $lehre_veranstaltung_anforderungen; ?></textarea>   
		    </td>
		</tr>
		<tr>
			<td>
		    	<input type="submit" value="weiter">&nbsp;&nbsp;&nbsp;<input type="submit" name="aktuelle_arbeiten" value="aktualisieren">
		    </td>
		</tr>
	</table> 	
</form>
