<?php
##############################
#       vorlesung.php        #
#        Adminseite          #
#      created by sweh       #
#  last update: 28.01.2004   #
##############################
?>
<script type="text/javascript">
	<!--
	function chkFormular()
	{
	if(document.Formular.vname.value == "")  {
	alert("Bitte Namen eingeben!");
	document.Formular.vname.focus();
	return false;
	}
	}
	-->
</script>

<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" name="Formular" onSubmit="return chkFormular()">
	<?php
		// bearbeiten der Eintr�ge
		if (preg_match("/[0-9]$/", $_REQUEST["id"]))
		{
			$result_lehre_veranstaltung = mysql_query("SELECT einheit, vname, vart, vinhalt, vsem, vabschluss, vliteratur, vhinweise from mi_lehre_veranstaltung WHERE id = '".$_REQUEST["id"]."'");
			if (mysql_num_rows($result_lehre_veranstaltung))
			{
				while($row_veranstaltung = mysql_fetch_array($result_lehre_veranstaltung))
				{
					$lehre_veranstaltung_einheit = $row_veranstaltung["einheit"];
					$lehre_veranstaltung_vname = $row_veranstaltung["vname"];
					$lehre_veranstaltung_vart = $row_veranstaltung["vart"];
					$lehre_veranstaltung_vinhalt = $row_veranstaltung["vinhalt"];
					$lehre_veranstaltung_vsem = $row_veranstaltung["vsem"];
					$lehre_veranstaltung_vabschluss = $row_veranstaltung["vabschluss"];
					$lehre_veranstaltung_vliteratur = $row_veranstaltung["vliteratur"];
					$lehre_veranstaltung_vhinweise = $row_veranstaltung["vhinweise"];	
				}
		
				echo '<input type="hidden" name="id" value="'.$_REQUEST["id"].'">';
			}
		
		}
		
		if (!$lehre_veranstaltung_einheit)
		{
			mt_srand(time());
			$lehre_veranstaltung_einheit = mt_rand(1,99999); 
		}
	?>
	<input type="hidden" name="eintragen" value="vorlesung">
	<input type="hidden" name="einheit" value="<?php echo $lehre_veranstaltung_einheit; ?>">
	<input type="hidden" name="vart" value="1">
	<center><table width=80% align="center"> 
		<tr>
			<td align="center"><img src="../lehre/veranstaltungen/img/mi_lehrveranstaltungen.png" align="center"></td>
		</tr>
		<tr>
			<td class="grau">
			    <b>Name der Vorlesung</b>
		    </td>
		</tr>
		<tr>
			<td class="zehn">
				<input type="text" maxlength="255" name="vname" value="<?php echo $lehre_veranstaltung_vname; ?>">
		    </td>
		</tr> 
		<tr>
			<td class="grau">
			    <b>Semestervorschlag</b>
		    </td>
		</tr>
		<tr>
			<td class="zehn">
				<select name="vsem" size="1">
				<?php
				for ($i=1; $i<=9; $i++)
				{
					echo "<option value='$i' ";
					if ($i == $lehre_veranstaltung_vsem)
						echo 'selected="selected"';
					echo ">$i</option>";
				}
				?>
				</select>
		    </td>
		</tr> 
		<tr>
			<td class="grau">
			    <b>Inhalt:</b>
		    </td>
		</tr>
		<tr>
			<td class="zehn">
			    <textarea name="vinhalt" cols="60" rows="8"><?php echo $lehre_veranstaltung_vinhalt; ?></textarea>
		    </td>
		</tr>
		<tr>
			<td class = "grau">
			    <b>�bersicht:</b>
		    </td>
		</tr>
		<tr>
			<td>
		    <center>
	    		<table width=90% bgcolor="#CCE7E7">
		        	<tr valign="top">
						<td>Abschlu�:</td>
		                <td class="zehn"><textarea name="vabschluss" cols="44" rows="5"><?php echo $lehre_veranstaltung_vabschluss; ?></textarea></td>
					</tr>
				</table>
		    </center>
	    	</td>
		</tr>
		<tr>
			<td class = "grau">
			    <b>Literaturempfehlungen:</b>
		    </td>
		</tr>
		<tr>
			<td class="zehn">
				<textarea name="vliteratur" cols="60" rows="8"><?php echo $lehre_veranstaltung_vliteratur; ?></textarea>
		    </td>
		</tr>
		<tr>
			<td class = "grau">
			    <b>Hinweise:</b>
		    </td>
		</tr>
		<tr>
			<td class="zehn">
				<textarea name="vhinweise" cols="60" rows="8"><?php echo $lehre_veranstaltung_vhinweise; ?></textarea>
	    	</td>
		</tr>
		<tr>
			<td>
				<br>
				<input type="submit" value="weiter" >&nbsp;&nbsp;<input type="reset" value="reset" >
		    </td>
		</tr>
	</table></center> 
</form>