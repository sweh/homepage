<?php
##############################
#        uebung.php          #
#        Adminseite          #
#      created by sweh       #
#  last update: 28.01.2004   #
##############################
?>

<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" name="Formular">
	<?php
		// bearbeiten der Eintr�ge
		if (preg_match("/[0-9]$/", $_REQUEST["id"]))
		{
			$result_lehre_veranstaltung = mysql_query("SELECT einheit, vname, vart, vinhalt, vsem, vabschluss, vliteratur, vhinweise from mi_lehre_veranstaltung WHERE id = '".$_REQUEST["id"]."'");
			if (mysql_num_rows($result_lehre_veranstaltung))
			{
				while($row_veranstaltung = mysql_fetch_array($result_lehre_veranstaltung))
				{
					$lehre_veranstaltung_einheit = $row_veranstaltung["einheit"];
					$lehre_veranstaltung_vname = $row_veranstaltung["vname"];
					$lehre_veranstaltung_vart = $row_veranstaltung["vart"];
					$lehre_veranstaltung_vinhalt = $row_veranstaltung["vinhalt"];
					$lehre_veranstaltung_vsem = $row_veranstaltung["vsem"];
					$lehre_veranstaltung_vabschluss = $row_veranstaltung["vabschluss"];
					$lehre_veranstaltung_vliteratur = $row_veranstaltung["vliteratur"];
					$lehre_veranstaltung_vhinweise = $row_veranstaltung["vhinweise"];	
				}
		
				echo '<input type="hidden" name="id" value="'.$_REQUEST["id"].'">';
			}
		
		}
		
		if (!$lehre_veranstaltung_vname)
			$lehre_veranstaltung_vname = $_POST["vname"];
	?>
	<input type="hidden" name="eintragen" value="vorlesung">
	<input type="hidden" name="vart" value="2">
	<input type="hidden" name="einheit" value="<?php echo $_POST["einheit"]; ?>">

	<table width=80% align="center"> 
		<tr>
			<td class="liniehell">      
			    <b>�bung <?php echo $lehre_veranstaltung_vname; ?></b> 
				<input type="hidden" name="vname" value="<?php echo $lehre_veranstaltung_vname; ?>">
		    </td> 
		</tr> 
		<tr>
			<td> 
			    <br> 
	    	</td> 
		</tr> 
		<tr>
			<td class="grau"> 
			    <b>Inhalt:</b> 
	    	</td> 
		</tr> 
		<tr>
			<td class="zehn"> 
				<textarea name="vinhalt" cols="60" rows="8"><?php echo $lehre_veranstaltung_vinhalt; ?></textarea> 
		    </td> 
		</tr> 
		<tr>
			<td class="grau"> 
			    <b>Literaturempfehlung:</b> 
	    	</td> 
		</tr> 
		<tr>
			<td class="zehn">
				<textarea name="vliteratur" cols="60" rows="8"><?php echo $lehre_veranstaltung_vliteratur; ?></textarea>
		    </td>
		</tr>
		<tr>
			<td class="grau"> 
			    <b>Hinweise:</b> 
	    	</td> 
		</tr> 
		<tr>
			<td class="zehn">
				<textarea name="vhinweise" cols="60" rows="8"><?php echo $lehre_veranstaltung_vhinweise; ?></textarea>
		    </td>
		</tr>
		<tr>
			<td class="zehn">
				<input type="submit" value="weiter" >&nbsp;&nbsp;<input type="reset" value="reset" >
	    	</td>
		</tr>
	</table> 
</form>
	
