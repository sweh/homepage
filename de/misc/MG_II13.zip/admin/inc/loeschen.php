<?php
##############################
#       loeschen.php         #
#        Adminseite          #
#      created by sweh       #
#  last update: 28.01.2004   #
##############################

if ($_REQUEST["loeschen"] == "vorlesung")
{
	$result_lehre_veranstaltung = mysql_query("SELECT vname from mi_lehre_veranstaltung WHERE einheit = '".$_REQUEST["einheit"]."' AND vart = 1");
	if (mysql_num_rows($result_lehre_veranstaltung))
		while($row_veranstaltung = mysql_fetch_array($result_lehre_veranstaltung))
			$lehre_veranstaltung_vname = $row_veranstaltung["vname"];
?>
	<table width=80%> 
		<tr>
			<td class="liniehell">     
			    <b>Vorlesung <?php echo $lehre_veranstaltung_vname; ?></b>
	    	</td>
		</tr>
		<tr>
			<td class="zehn">
				<p>Sind Sie sicher, dass Sie die gesamte Vorlesung (einschlie�lich �bung, Praktikum, Termine, etc.) l�schen wollen?</p>
					<form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
						<input type="hidden" name="einheit" value="<?php echo $_REQUEST["einheit"]; ?>">
						<input type="hidden" name="loeschen" value="vorlesung">
	
						<input type="submit" name="tues" value="JA" >&nbsp;&nbsp;&nbsp;			<input type="submit" name="tues" value="NEIN" >
					</form>
			</td>
		</tr>
	</table>
<?php
}
elseif (($_POST["loeschen"] == "uebung") || ($_POST["loeschen"] == "praktikum"))
{
	$result_lehre_veranstaltung = mysql_query("SELECT vname, vart from mi_lehre_veranstaltung WHERE id = '".$_REQUEST["id"]."'");
	if (mysql_num_rows($result_lehre_veranstaltung))
		while($row_veranstaltung = mysql_fetch_array($result_lehre_veranstaltung))
		{
			$lehre_veranstaltung_vname = $row_veranstaltung["vname"];
			if ($row_veranstaltung["vart"] == 2)
				$lehre_veranstaltung_vart = "�bung";
			elseif ($row_veranstaltung["vart"] == 3)
				$lehre_veranstaltung_vart = "Praktikum";
			else
				$lehre_veranstaltung_vart = "Seminar";
		}
?>
		<table width=80%> 
			<tr>
				<td class="liniehell">     
			    	<b><?php echo $lehre_veranstaltung_vart." ".$lehre_veranstaltung_vname; ?></b>
			    </td>
			</tr>
			<tr>
				<td class="zehn">
					<p>Sind Sie sicher, dass Sie <?php echo $lehre_veranstaltung_vart." '".$lehre_veranstaltung_vname."'"; ?> l�schen wollen?</p>
					<form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
						<input type="hidden" name="id" value="<?php echo $_REQUEST["id"]; ?>">
						<input type="hidden" name="loeschen" value="vorlesung">
						<input type="hidden" name="einheit" value="<?php echo $_REQUEST["einheit"]; ?>">
			
						<input type="submit" name="tues" value="JA" >&nbsp;&nbsp;&nbsp;			<input type="submit" name="tues" value="NEIN" >
					</form>
				</td>
			</tr>
		</table>
<?php
}
elseif ($_GET["loeschen"] == "termine")
{
	$result_lehre_veranstaltung = mysql_query("SELECT vnr from mi_lehre_veranstaltung_zeit WHERE id = '".$_REQUEST["id"]."'");
	if (mysql_num_rows($result_lehre_veranstaltung))
		while($row_veranstaltung = mysql_fetch_array($result_lehre_veranstaltung))
			$lehre_veranstaltung_vnr = $row_veranstaltung["vnr"];
?>
		<table width=80%> 
			<tr>
				<td class="liniehell">     
			    	<b>Termin '<?php echo $lehre_veranstaltung_vnr; ?>'</b>
			    </td>
			</tr>
			<tr>
				<td class="zehn">
					<p>Sind Sie sicher, dass Sie Termin '<?php echo $lehre_veranstaltung_vnr; ?>' l�schen wollen?</p>
					<form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
						<input type="hidden" name="id" value="<?php echo $_REQUEST["id"]; ?>">
						<input type="hidden" name="loeschen" value="termine">
						<input type="hidden" name="einheit" value="<?php echo $_REQUEST["einheit"]; ?>">
			
						<input type="submit" name="tues" value="JA" >&nbsp;&nbsp;&nbsp;			<input type="submit" name="tues" value="NEIN" >
					</form>
				</td>
			</tr>
		</table>
<?php
}
elseif ($_GET["loeschen"] == "material")
{
	$result_lehre_veranstaltung = mysql_query("SELECT beschreibung, link from mi_lehre_material WHERE id = '".$_REQUEST["id"]."'");
	if (mysql_num_rows($result_lehre_veranstaltung))
		while($row_veranstaltung = mysql_fetch_array($result_lehre_veranstaltung))
		{
			$lehre_veranstaltung_vnr = $row_veranstaltung["beschreibung"];
			$link = $row_veranstaltung["link"];
		}
?>
		<table width=80%> 
			<tr>
				<td class="liniehell">     
			    	<b>Material '<?php echo $lehre_veranstaltung_vnr; ?>'</b>
			    </td>
			</tr>
			<tr>
				<td class="zehn">
					<p>Sind Sie sicher, dass Sie das material '<?php echo $lehre_veranstaltung_vnr; ?>' l�schen wollen?</p>
					<form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
						<input type="hidden" name="id" value="<?php echo $_REQUEST["id"]; ?>">
						<input type="hidden" name="loeschen" value="material">
						<input type="hidden" name="loeschen_link" value="<?php echo $link; ?>">
						<input type="hidden" name="einheit" value="<?php echo $_REQUEST["einheit"]; ?>">
			
						<input type="submit" name="tues" value="JA" >&nbsp;&nbsp;&nbsp;			<input type="submit" name="tues" value="NEIN" >
					</form>
				</td>
			</tr>
		</table>
<?php
}
elseif ($_GET["loeschen"] == "p_themen")
{
	$result_lehre_veranstaltung = mysql_query("SELECT pthema from mi_lehre_veranstaltung_praktika WHERE id = '".$_REQUEST["id"]."'");
	if (mysql_num_rows($result_lehre_veranstaltung))
		while($row_veranstaltung = mysql_fetch_array($result_lehre_veranstaltung))
		{
			$lehre_veranstaltung_vnr = $row_veranstaltung["pthema"];
		}
?>
		<table width=80%> 
			<tr>
				<td class="liniehell">     
			    	<b>Thema '<?php echo $lehre_veranstaltung_vnr; ?>'</b>
			    </td>
			</tr>
			<tr>
				<td class="zehn">
					<p>Sind Sie sicher, dass Sie das Thema '<?php echo $lehre_veranstaltung_vnr; ?>' l�schen wollen?</p>
					<form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
						<input type="hidden" name="id" value="<?php echo $_REQUEST["id"]; ?>">
						<input type="hidden" name="loeschen" value="p_themen">
						<input type="hidden" name="einheit" value="<?php echo $_REQUEST["einheit"]; ?>">
			
						<input type="submit" name="tues" value="JA" >&nbsp;&nbsp;&nbsp;			<input type="submit" name="tues" value="NEIN" >
					</form>
				</td>
			</tr>
		</table>
<?php
}
?>