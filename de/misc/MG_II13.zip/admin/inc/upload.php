<?php
##############################
#        upload.php          #
#        Adminseite          #
#      created by sweh       #
#  last update: 28.01.2004   #
##############################
?>
<script type="text/javascript">
	<!--
	function chkFormular()
	{
		if(document.Formular.dateiname.value == "")
		{
			if(document.Formular.file.value == "")
			{
				alert("Bitte eine Datei zum Hochladen eingeben!");
				document.Formular.file.focus();
				return false;
			}
		}
	}
	-->
</script>

<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data" name="Formular" onSubmit="return chkFormular()">
	<?php
		// bearbeiten der Eintr�ge
		if (preg_match("/[0-9]$/", $_GET["id"]))
		{
			$result_lehre_material = mysql_query("SELECT art, beschreibung, link, sem from mi_lehre_material WHERE id = '".$_GET["id"]."'");
			if (mysql_num_rows($result_lehre_material))
			{
				while($row_material = mysql_fetch_array($result_lehre_material))
				{
					$lehre_material_art = $row_material["art"];
					$lehre_material_beschreibung = $row_material["beschreibung"];
					$lehre_dateiname = $row_material["link"];
					$lehre_material_sem = $row_material["sem"];
				}
		
				echo '<input type="hidden" name="id" value="'.$_GET["id"].'">';
			}
		
		}
		else
		{
		$result_lehre_material = mysql_query("SELECT vname from mi_lehre_veranstaltung WHERE einheit = '".$_REQUEST["einheit"]."' LIMIT 1");
		if(mysql_num_rows($result_lehre_material))
			while($row=mysql_fetch_array($result_lehre_material))
				$lehre_vname = $row["vname"];
		}
	?>
	<input type="hidden" name="einheit" value="<?php echo $_REQUEST["einheit"]; ?>">
	<input type="hidden" name="vart" value="<?php echo $_REQUEST["vart"]; ?>">
	<input type="hidden" name="eintragen" value="material">
	<table width=80% align="center"> 
		<tr>
			<td class="liniehell">     
	    		<b>Material hochladen f�r <?php echo $lehre_vname; ?></b>
		    </td>
		</tr>
		<tr>
			<td>
	    		<br>
		    </td>	
		</tr> 
		<tr>
			<td class="grau">
			    <b>Art des Materials:</b>
	    	</td>
		</tr>
		<tr>
			<td class="zehn">
				<select name="art" size="1">
					<option value="0" <?php if($lehre_material_art == 0) echo "selected='selected'"; ?>>Vorlesungsscript</option>
					<option value="1" <?php if($lehre_material_art == 1) echo "selected='selected'"; ?>>�bungsmaterial</option>
					<option value="2" <?php if($lehre_material_art == 2) echo "selected='selected'"; ?>>Zusatzmaterial</option>
				</select>
		    </td>
		</tr>
		<tr>
			<td class="grau">
			    <b>Beschreibung:</b>
	    	</td>
		</tr>
		<tr>
			<td class="zehn">
				<input type="text" name="beschreibung" maxlength="255" size="80" value="<?php echo $lehre_material_beschreibung; ?>">   
		    </td>
		</tr>
		<tr>
			<td class="grau">
			    <b>Dateiname:</b>
		    </td>
		</tr>
		<tr>
			<td class="zehn">
				<?php
					if ($lehre_dateiname)
					{
				?>
						<p>aktuell hochgeladen: <a href="<?php echo "../lehre/lehrmaterial/".$lehre_dateiname; ?>" target="_blanc"><?php echo $lehre_dateiname; ?></a></p>
						<input type="hidden" name="dateiname" value="<?php echo $lehre_dateiname; ?>">
				<?php
					 }
				 ?>

				<p>Datei zum Hochladen ausw�hlen:</p>
				<input type="file" name="file">
		    </td>
		</tr>
		<tr>
			<td class="grau">
			    <b>Semester:</b>
	    	</td>
		</tr>
		<tr>
			<td class="zehn">
				<select name="jahr" size="1">
				<?php
					$start_jahr = date("Y", time())-5;
					if (!$lehre_material_sem)
						$lehre_jahr = date("Y", time());
					else
						$lehre_jahr = substr($lehre_material_sem,0,4);
	
					for ($i=1; $i<=15; $i++)
					{
						echo "<option value='$start_jahr' ";
						if ($start_jahr == $lehre_jahr)
							echo "selected='selected'";
						echo ">$start_jahr</option>";
						$start_jahr++;
					}
				?>
				</select>
				&nbsp;&nbsp;&nbsp;
				<select name="sem" size="1">
					<option value="W" <?php if(substr($lehre_material_sem,4,5) == "W") echo "selected='selected'"; ?>>Wintersemester</option>
					<option value="S" <?php if(substr($lehre_material_sem,4,5) == "S") echo "selected='selected'"; ?>>Sommersemester</option>
				</select>
		    </td>
		</tr>
		<tr>
			<td class="zehn">
				<input type="submit" value="weiter" >&nbsp;&nbsp;<input type="reset" value="reset" >
		    </td>
		</tr>
	</table> 
</form>