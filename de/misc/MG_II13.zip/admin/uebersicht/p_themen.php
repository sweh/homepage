<?php
##############################
#       p_themen.php         #
#     �bersichtsseite        #
#      created by sweh       #
#  last update: 28.01.2004   #
##############################
?>
<table width=100%> 
	<tr>
		<td class="liniehell">     
		    <b><?php if ($lehre_veranstaltung_vart == 3) echo "Praktikums"; else echo "Seminar"; ?>themen</b>
	    </td>
	</tr>
	<tr>
		<td>
			<table width="100%" cellspacing="2" cellpadding="1" border="0">
				<tr>
					<th>Optionen</th>
					<th>Thema</th>
					<th>Inhalt</th>
				</tr>
			
			<?php
				$result_lehre_veranstaltung = mysql_query("SELECT id, pkomplex, pthema, pinhalt from mi_lehre_veranstaltung_praktika WHERE einheit = '".$_REQUEST["einheit"]."' ORDER by pkomplex asc");
				if (mysql_num_rows($result_lehre_veranstaltung))
				{
					while($row_termine = mysql_fetch_array($result_lehre_veranstaltung))
					{
			
						if($i==1)
						{
							$bgcolor='white';
							$i=0;
						}
						else
						{
							$bgcolor='grau';
							$i=1;
						}
			
						if ($alt_vart != $row_termine["pkomplex"])
						{
						?>
						<tr>
							<th><a href="<?php echo $_SERVER["PHP_SELF"]; ?>?weiter=p_themen&einheit=<?php echo $_REQUEST["einheit"]; ?>&pkomplex=<?php echo $row_termine["pkomplex"]; ?>"><img src="img/new.gif" border="0" alt="neues Praktikumsthema" title="neues Praktikumsthema"></a></th>
							<th colspan="3"><?php echo $row_termine["pkomplex"]; ?></th>
						</tr>
						<?php
						}
						echo "<tr class='$bgcolor'>";
					
					?>
					<th>
						<a href="<?php echo $_SERVER["PHP_SELF"]; ?>?weiter=p_themen&id=<?php echo $row_termine["id"]; ?>&einheit=<?php echo $_REQUEST["einheit"]; ?>"><img src="img/edit.gif" border="0" alt="Eintrag bearbeiten" title="Eintrag bearbeiten"></a>&nbsp;&nbsp;
						<a href="<?php echo $_SERVER["PHP_SELF"]; ?>?weiter=loeschen&loeschen=p_themen&id=<?php echo $row_termine["id"]; ?>&einheit=<?php echo $_REQUEST["einheit"]; ?>"><img src="img/del.gif" border="0" alt="Eintrag l�schen" title="Eintrag l�schen"></a>
					</th>
					<td><?php echo $row_termine["pthema"]; ?></td>
					<td><?php echo kurzundknapp($row_termine["pinhalt"],50); ?></td>
				</tr>
					<?php
					$alt_vart = $row_termine["pkomplex"];
					}
				}
			?>
			</table>
		</td>
	</tr>
</table>