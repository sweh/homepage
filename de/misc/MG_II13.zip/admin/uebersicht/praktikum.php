<?php
##############################
#      praktukum.php         #
#     �bersichtsseite        #
#      created by sweh       #
#  last update: 28.01.2004   #
##############################
?>
	<?php
		$result_lehre_veranstaltung = mysql_query("SELECT id, vname, vart, vinhalt, vsem, vabschluss, vliteratur, vhinweise from mi_lehre_veranstaltung WHERE einheit = '".$_REQUEST["einheit"]."' AND (vart = 3 OR vart = 4) LIMIT 1");
		if (mysql_num_rows($result_lehre_veranstaltung))
		{
			while($row_veranstaltung = mysql_fetch_array($result_lehre_veranstaltung))
			{
				$lehre_veranstaltung_einheit = $row_veranstaltung["einheit"];
				$lehre_veranstaltung_vname = $row_veranstaltung["vname"];
				$lehre_veranstaltung_vart = $row_veranstaltung["vart"];
				$lehre_veranstaltung_vinhalt = $row_veranstaltung["vinhalt"];
				$lehre_veranstaltung_vsem = $row_veranstaltung["vsem"];
				$lehre_veranstaltung_vabschluss = $row_veranstaltung["vabschluss"];
				$lehre_veranstaltung_vliteratur = $row_veranstaltung["vliteratur"];
				$lehre_veranstaltung_vhinweise = $row_veranstaltung["vhinweise"];	
			}
	?>
<table width=100%> 
	<tr>
		<td class="liniehell">     
		    <b><?php if ($lehre_veranstaltung_vart == 4) echo "Seminar"; else echo "Praktikum"; ?></b>
	    </td>
	</tr>
	<?php if ($lehre_veranstaltung_vinhalt) { ?>
	<tr>
		<td class="grau">
		    <b>Beschreibung:</b>
	    </td>
	</tr>
	<tr>
		<td>
		    <?php echo $lehre_veranstaltung_vinhalt; ?></td>
	</tr>
	<?php } ?>
	<?php if ($lehre_veranstaltung_vliteratur) { ?>
	<tr>
		<td class = "grau">
	    	<b>Literaturempfehlungen:</b>
	    </td>
	</tr>
	<tr>
		<td>
			<?php echo $lehre_veranstaltung_vliteratur; ?>
	    </td>
	</tr>
	<?php } ?>
	<?php if ($lehre_veranstaltung_vhinweise) { ?>
	<tr>
		<td class = "grau">
	    	<b>Hinweise:</b>
	    </td>
	</tr>
	<tr>
		<td>
			<?php echo $lehre_veranstaltung_vhinweise; ?>
	    </td>
	</tr>
	<?php } ?>
</table> 
	<?php
	}
	else
	{
		$p_themen = "false";
	?>
<table width=100%> 
	<tr>
		<td class="liniehell">     
		    <b>Praktikum</b>
	    </td>
	</tr>
</table>
	<?php
	}
	?>
