<?php
##############################
#       arbeiten.php         #
#     �bersichtsseite        #
#      created by sweh       #
#  last update: 28.01.2004   #
##############################
?>
<table width=100%> 
	<tr>
		<td class="liniehell">     
		    <b>�bersicht</b>
	    </td>
	</tr>
	<tr>
		<td>
			<table width="100%" cellspacing="2" cellpadding="1" border="0">
				<tr>
					<th>Optionen</th>
					<th>Typ</th>
					<th>Thema</th>
					<th>Inhalt</th>
				</tr>
				<?php
					$result_lehre_veranstaltung = mysql_query("SELECT id, typ, thema, status, inhalt from mi_lehre_arbeiten ORDER by status asc");
					if (mysql_num_rows($result_lehre_veranstaltung))
					{
						while($row_material = mysql_fetch_array($result_lehre_veranstaltung))
						{
			
							if($i==1)
							{
								$bgcolor='white';
								$i=0;
							}
							else
							{
								$bgcolor='grau';
								$i=1;
							}
				
							if ($alt_vart != $row_material["status"])
							{
								echo "<tr><th colspan=\"4\">";
								if ($row_material["status"] == 0)
									echo "ausgeschrieben";
								elseif ($row_material["status"] == 1)
									echo "in Bearbeitung";
								else
									echo "abgeschlossen";
								echo "</th></tr>";
							}
							echo "<tr class='$bgcolor'>";
				?>
					<th>
						<a href="<?php echo $_SERVER["PHP_SELF"]; ?>?id=<?php echo $row_material["id"]; ?>&show=edit"><img src="img/edit.gif" border="0" alt="Eintrag bearbeiten" title="Eintrag bearbeiten"></a>&nbsp;&nbsp;
						<a href="<?php echo $_SERVER["PHP_SELF"]; ?>?id=<?php echo $row_material["id"]; ?>&show=delete"><img src="img/del.gif" border="0" alt="Eintrag l�schen" title="Eintrag l�schen"></a>
					</th>
					<td><?php if ($row_material["typ"] == "1") echo "Studienarbeit"; else echo "Diplomarbeit"; ?></td>
					<td><?php echo $row_material["thema"]; ?></td>
					<td><?php echo kurzundknapp($row_material["inhalt"], 100); ?></td>
				</tr>
				<?php
					$alt_vart = $row_material["status"];
						}
					}
				?>
			</table>
		</td>
	</tr>
</table>
