<?php
##############################
#       termine.php          #
#     �bersichtsseite        #
#      created by sweh       #
#  last update: 28.01.2004   #
##############################
?>
<table width=100%> 
	<tr>
		<td class="liniehell">     
		    <b>Termine</b>
	    </td>
	</tr>
	<tr>
		<td>
			<table width="100%" cellspacing="2" cellpadding="1" border="0">
				<tr>
					<th>Optionen</th>
					<th>Vorlesungsnummer</th>
					<th>Zeit</th>
					<th>Raum</th>
					<th>Status</th>
				</tr>
			
			<?php
				$result_lehre_veranstaltung = mysql_query("SELECT id, vnr, vart, vtag, vbeginn, vdauer, vwoche, vraum, vaktiv from mi_lehre_veranstaltung_zeit WHERE einheit = '".$_REQUEST["einheit"]."' ORDER by vart asc");
				if (mysql_num_rows($result_lehre_veranstaltung))
				{
					while($row_termine = mysql_fetch_array($result_lehre_veranstaltung))
					{
			
						if($i==1)
						{
							$bgcolor='white';
							$i=0;
						}
						else
						{
							$bgcolor='grau';
							$i=1;
						}
			
						if ($alt_vart != $row_termine["vart"])
						{
							echo "<tr><th colspan=\"5\">";
							if ($row_termine["vart"] == 1)
								echo "Vorlesung";
							elseif ($row_termine["vart"] == 2)
								echo "�bung";
							else
								echo "Praktikum";
							echo "</th></tr>";
						}
						echo "<tr class='$bgcolor'>";
					
					?>
					<th>
						<a href="<?php echo $_SERVER["PHP_SELF"]; ?>?weiter=datum&id=<?php echo $row_termine["id"]; ?>&einheit=<?php echo $_REQUEST["einheit"]; ?>"><img src="img/edit.gif" border="0" alt="Eintrag bearbeiten" title="Eintrag bearbeiten"></a>&nbsp;&nbsp;
						<a href="<?php echo $_SERVER["PHP_SELF"]; ?>?weiter=loeschen&loeschen=termine&id=<?php echo $row_termine["id"]; ?>&einheit=<?php echo $_REQUEST["einheit"]; ?>"><img src="img/del.gif" border="0" alt="Eintrag l�schen" title="Eintrag l�schen"></a>
					</th>
					<td><?php echo $row_termine["vnr"]; ?></td>
					<td><?php echo $row_termine["vtag"]." ".format_zeit($row_termine["vbeginn"])."Uhr"; ?></td>
					<td><?php echo $row_termine["vraum"]; ?></td>
					<td align="center">
						<?php
							if ($row_termine["vaktiv"] == "0")
								echo "<a href=\"".$_SERVER["PHP_SELF"]."?id=".$row_termine["id"]."&einheit=".$_REQUEST["einheit"]."&eintragen=status&akt_status=".$row_termine["vaktiv"]."\"><img src=\"img/inaktiv.gif\" title=\"dieser Termin ist zur Zeit inaktiv\" border=0></a>";
							elseif ($row_termine["vaktiv"] == "1")
								echo "<a href=\"".$_SERVER["PHP_SELF"]."?id=".$row_termine["id"]."&einheit=".$_REQUEST["einheit"]."&eintragen=status&akt_status=".$row_termine["vaktiv"]."\"><img src=\"img/ws.gif\" title=\"dieser Termin wird nur im WS angeboten\" border=0></a>";
							elseif ($row_termine["vaktiv"] == "2")
								echo "<a href=\"".$_SERVER["PHP_SELF"]."?id=".$row_termine["id"]."&einheit=".$_REQUEST["einheit"]."&eintragen=status&akt_status=".$row_termine["vaktiv"]."\"><img src=\"img/ss.gif\" title=\"dieser Termin wird nur im SS angeboten\" border=0></a>";
							else
								echo "<a href=\"".$_SERVER["PHP_SELF"]."?id=".$row_termine["id"]."&einheit=".$_REQUEST["einheit"]."&eintragen=status&akt_status=".$row_termine["vaktiv"]."\"><img src=\"img/wsss.gif\" title=\"dieser Termin wird im SS und WS angeboten\" border=0></a>";
						?>
					</td>
				</tr>
				<?php
					$alt_vart = $row_termine["vart"];
					}
				}
				else
				{
				?>
				<tr><td colspan="5"><div style="font-size:12px; color:darkred;">Sie M�SSEN hier noch mindestens einen Termin eingeben</div></td>
				<?php
				}
				?>
			</table>
		</td>
	</tr>
</table>