<?php
require_once('../config.inc'); seite(__FILE__);
?>
<center>
	<img src="img/mi_titel_keinzutritt.png" border="0" align="center">
	<br>
	<p>Sie haben nicht die erforderlichen Rechte, um diese Seite anzuzeigen!</p>
</center>