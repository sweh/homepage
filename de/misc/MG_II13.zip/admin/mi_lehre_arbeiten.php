<?php
##############################
#   mi_lehre_arbeiten.php    #
#        Adminseite          #
#      created by sweh       #
#  last update: 28.01.2004   #
##############################

require_once('../config.inc'); seite(__FILE__);

if ($_SESSION["login"] == "true")
{
?>
	<table width=100%> 
		<tr>
			<td align="center"><img src="../lehre/diplom/img/mi_diplom.png" align="center"></td>
		</tr>
		<tr>
			<td>
	<?php
	if ($_POST["doit"] == "eintragen")
	{
		if ($_FILES["file"]["name"])
		{
			$temp = explode(".",$_FILES["file"]["name"]);
			$anzahl_teile = count($temp)-1;
		
			mt_srand(time());
			$dateiname = "arbeiten/".mt_rand(1,999999999).".".$temp[$anzahl_teile];
		
			while (file_exists("../lehre/diplom/".$dateiname))
			{
				mt_srand(time());
				$dateiname = "arbeiten/".mt_rand(1,999999999).".".$temp[$anzahl_teile];
			}
		
			move_uploaded_file($_FILES["file"]["tmp_name"],"../lehre/diplom/".$dateiname);
		}
		else
			$dateiname = $_POST["dateiname"];
	
		if ($_POST["id"])
			$result_query = mysql_query("UPDATE mi_lehre_arbeiten SET typ = '".$_POST["typ"]."', thema = '".$_POST["thema"]."', pid = '".$_POST["pid"]."', status = '".$_POST["status"]."', link = '".$_POST["link"]."', datei = '$dateiname', inhalt = '".$_POST["inhalt"]."', anforderungen = '".$_POST["anforderungen"]."' WHERE id = '".$_POST["id"]."'");
		else
			$result_query = mysql_query("INSERT into mi_lehre_arbeiten (typ, thema, pid, status, link, datei, inhalt, anforderungen) VALUES ('".$_POST["typ"]."', '".$_POST["thema"]."', '".$_POST["pid"]."', '".$_POST["status"]."', '".$_POST["link"]."', '$dateiname', '".$_POST["inhalt"]."', '".$_POST["anforderungen"]."')")or die(mysql_error());
		
		if (!$result_query)
			echo "Es ist ein Fehler aufgetreten";
	}
	elseif ($_POST["doit"] == "delete")
	{
		if ($_POST["tues"] == "JA")
		{
			$result_query = mysql_query("DELETE from mi_lehre_arbeiten WHERE id = '".$_POST["id"]."' LIMIT 1");
			@unlink("../lehre/diplom/".$_POST["loeschen_link"]);
	
		if (!$result_query)
			echo "Es ist ein Fehler aufgetreten";
		}
	}
	elseif ($_REQUEST["show"] == "edit")
		include ("inc/arbeiten.php");
	elseif ($_REQUEST["show"] == "delete")
	{
		$result_lehre_veranstaltung = mysql_query("SELECT thema, datei from mi_lehre_arbeiten WHERE id = '".$_REQUEST["id"]."'");
		if (mysql_num_rows($result_lehre_veranstaltung))
			while($row_veranstaltung = mysql_fetch_array($result_lehre_veranstaltung))
			{
				$lehre_veranstaltung_vnr = $row_veranstaltung["thema"];
				$lehre_veranstaltung_datei = $row_veranstaltung["datei"];
			}
	?>
			<table width=80%> 
				<tr>
					<td class="liniehell">     
					    <b>Arbeit '<?php echo $lehre_veranstaltung_vnr; ?>'</b>
				    </td>
				</tr>
				<tr>
					<td>
						<p>Sind Sie sicher, dass Sie die Arbeit '<?php echo $lehre_veranstaltung_vnr; ?>' l�schen wollen?</p>
						<form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
							<input type="hidden" name="id" value="<?php echo $_REQUEST["id"]; ?>">
							<input type="hidden" name="doit" value="delete">
							<input type="hidden" name="loeschen_link" value="<?php echo $datei; ?>">
							<input type="submit" name="tues" value="JA">&nbsp;&nbsp;&nbsp;			<input type="submit" name="tues" value="NEIN">
						</form>
					</td>
				</tr>
			</table>	
	<?php
	}
	if ($_REQUEST["aktuelle_arbeiten"] == "aktualisieren")
	{
		$_REQUEST["id"] = mysql_insert_id();
		include_once("inc/arbeiten.php");
	}
	?>
			<table width="100%">
				<tr>
					<td>
					<?php
						include ("uebersicht/arbeiten.php");
					?>
					<table width=100% align="center">
						<tr>
							<td width="90%" align="right">&nbsp;</td>
							<td align="left">
							<form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
								<input type="hidden" name="show" value="edit">
								<input type="image" src="img/new_s.gif" title="Neue Studien- / Diplomarbeit hinzuf�gen">
							</form>
							</td>
						</tr>
					</table>
					</td>
				</tr>
			</table>
			</td>
		</tr>
	</table>
<?php
}
else
	include_once("keinzutritt.php");
?>