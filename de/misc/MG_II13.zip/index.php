<?php require_once('config.inc'); seite(__FILE__); ?>

<?php
$id=$_GET["id"];
$id=intval($id);
$sem=akt_semester();

echo '
<p><h1><center>Professur</center></h1></p>
<p><h1><center>Medieninformatik</center></h1></p>
<p></p>
<center><img src="bild/logo.jpg"><br><br>
<table width=80% align="center">
<tr><td align="right" valign="top" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt"><b>Adresse:</b></td><td colspan=2 align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">Technische Universit&auml;t Chemnitz<br>
Professur f�r Medieninformatik<br>Stra�e der Nationen 62<br>09107 Chemnitz
</td></tr>';

//Sekretariat ausgeben
$sekret=mysql_query("SELECT name, vname, zimmer, telefon, email, fax, sprechstunde FROM mi_prof WHERE funktion=4 and (ende='' or ende>'$sem')");
if (mysql_num_rows($sekret))
{
 $sek=mysql_fetch_array($sekret);
 echo '
  <tr><td align="right" valign="top" style="padding-left:10pt;padding-right:10pt"><b>Sekretariat:</b></td>
      <td colspan=2 align="left" style="padding-left:10pt;padding-right:10pt">'.$sek["vname"].' '.$sek["name"].'</td></tr>
  <tr><td valign="top" align="right" style="padding-left:10pt;padding-right:10pt">Zimmer:</td>
      <td colspan=2 style="padding-left:10pt;padding-right:10pt" align="left">'.$sek["zimmer"].'</td></tr>
  <tr><td align="right" style="padding-left:10pt;padding-right:10pt">Tel.:</td>
      <td colspan=2 align="left" style="padding-left:10pt;padding-right:10pt">'.$sek["telefon"].'</td></tr>';
 if ($sek["fax"]) echo '
  <tr><td valign="top" align="right" style="padding-left:10pt;padding-right:10pt">Fax:</td>
      <td colspan=2 align="left" style="padding-left:10pt;padding-right:10pt">'.$sek["fax"].'</td></tr>';
 if ($sek["email"]) echo '
  <tr><td valign="top" align="right" style="padding-left:10pt;padding-right:10pt">Email:</td>
      <td colspan=2 align="left" style="padding-left:10pt;padding-right:10pt"><a href="mailto:'.$sek["email"].'">'.$sek["email"].'</a></td></tr>';
 if ($sek["sprechstunde"]) echo '
  <tr><td valign="top" align="right" style="padding-left:10pt;padding-right:10pt">&Ouml;ffnungszeiten:</td>
      <td colspan=2 align="left" style="padding-left:10pt;padding-right:10pt">'.$sek["sprechstunde"].'</td></tr>';
}
 
//Aktuelles ausgeben
$aktuelles=mysql_query("SELECT id, name, beschreibung, pid, anfang, ende, link, bild FROM mi_veranstaltung");
if (mysql_num_rows($aktuelles))
{
 $flag=0;
 while ($akt=mysql_fetch_array($aktuelles))
 {
  if (timestamp_to_date($akt["anfang"])==date("d.m.Y"))
  {
   if ($flag==0) {echo '<tr height=10><td></td></tr>
                        <tr><th colspan=3><b>Aktuelles - Infos</b></th></tr>';
                  $flag=1;}
   echo '<tr><td class="grau" width=12% align="center" valign="top" style="padding-left:10pt;padding-right:10pt;padding-top:2pt;padding-bottom:2pt">'.timestamp_to_date($akt["anfang"]).'</td>
            <td class="grau" width=12% align="center" valign="top" style="padding-left:10pt;padding-right:10pt;padding-top:2pt;padding-bottom:2pt">';
   if (timestamp_to_time($akt["anfang"])!="0:00") 
       echo timestamp_to_time($akt["anfang"]);
   echo '</td><td class="grau" align="left" style="padding-left:10pt;padding-right:10pt;padding-top:2pt;padding-bottom:2pt">';
   if (($akt["beschreibung"]!='' or $akt["pid"]!='' or $akt["bild"]) and $id!=$akt["id"]) 
      echo '<a href="index.php?id='.$akt["id"].'"><b>'.$akt["name"].'</b></a>'; 
   else  
      if ($akt["link"] and $id!=$akt["id"]) echo '<a href="'.$akt["link"].'"><b>'.$akt["name"].'</b></a>'; 
      else echo '<b>'.$akt["name"].'</b>';
   echo '</td></tr>';

//mehr zur Veranstaltung ausgeben 
   if ($id==$akt["id"]) 
   { 
    
    //Beschreibung ausgeben 
    if ($akt["beschreibung"]) echo '<tr><td colspan=2></td><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:2pt">'.$akt["beschreibung"].'</td></tr>'; 

    //Ende ausgeben 
    if ($akt["ende"])   
      echo '<tr><td colspan=2 valign="top" align="right" style="padding-left:10pt;padding-right:10pt;padding-top:2pt">Ende:</td><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:2pt">'.timestamp_to_date($akt["ende"]).' um '.timestamp_to_time($akt["ende"]).' Uhr</td></tr>'; 

    //Mitwirkende ausgeben 
    if ($akt["pid"])  
    { 
     $bet=split("_",$akt["pid"]); 
     for ($i=0;$i<count($bet);$i++)  
      {if ($query) $query.=' OR '; 
       $query.='id='.$bet[$i];} 
     $beteiligte=mysql_query("SELECT name, vname, titel FROM mi_prof WHERE ".$query); 
     if (mysql_num_rows($beteiligte)) 
      while ($person=mysql_fetch_array($beteiligte)) 
      { 
       if ($namen) $namen.=', '; 
       $namen.=$person["titel"].'&nbsp;'.$person["vname"].'&nbsp;'.$person["name"]; 
      } 
     echo '<tr><td colspan=2 valign="top" align="right" style="padding-left:10pt;padding-right:10pt;padding-top:2pt">Mit:</td><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:2pt">'.$namen.'</td></tr>'; 
    } 

    //Bild ausgeben 
    if ($akt["bild"]) echo '<tr><td colspan=3 align="center" style="padding-left:10pt;padding-right:10pt;padding-top:2pt"><img src="img/'.$akt["bild"].'"></td></tr>'; 

    //Link ausgeben 
    if ($akt["link"]) echo '<tr><td colspan=3 align="right" style="padding-left:10pt;padding-right:10pt;padding-top:2pt"><a href="'.$akt["link"].'">mehr &gt;&gt;</a></td></tr>'; 
   } 
  }
 }      
} 

echo '</table></center>';

?>