<?php require_once('../../config.inc');seite(__FILE__); ?>

<?php

$id=$_GET["id"];
$akt=$_GET["akt"];

echo '<br><center>
      <table width=80% align="center">
      <tr><td colspan=3 align="center"><img src="img/mi_veranstaltungen.png" alt="Veranstaltungskalender"></td></tr>
      <tr height=10pt><td></td></tr>';

if ($akt=='')
  //alle aktuellen Veranstaltungen ausgeben
  $veranstaltung=mysql_query("SELECT id, rubrik, name, beschreibung, pid, anfang, ende, link, bild FROM mi_veranstaltung WHERE anfang>='".date_to_timestamp(date("Y-m-d"))."' ORDER BY anfang DESC") or die(mysql_error());
else
  //�ltere Veranstaltungen ausgeben
  $veranstaltung=mysql_query("SELECT id, rubrik, name, beschreibung, pid, anfang, ende, link, bild FROM mi_veranstaltung WHERE anfang<'".date_to_timestamp(date("Y-m-d"))."' ORDER BY anfang DESC");

//Veranstaltungen als Liste ausgeben
if (mysql_num_rows($veranstaltung))
{
 echo '<tr><th width=12%>am</th><th width=12%>um</th><th>Veranstaltung</th></tr>';
 while ($array=mysql_fetch_array($veranstaltung))
 {
  echo '<tr class="grau">'; 
  echo '<td valign="top" align="center" style="padding-left:5pt;padding-right:5pt;padding-top:10pt;padding-bottom:10pt">'.timestamp_to_date($array["anfang"]).'</td>';
  echo '<td valign="top" align="center" style="padding-left:5pt;padding-right:5pt;padding-top:10pt;padding-bottom:10pt">';
  if (timestamp_to_time($array["anfang"])!="0:00") 
     echo timestamp_to_time($array["anfang"]);
  echo '</td>';
  echo '<td valign="top" align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">';
   if (($array["beschreibung"]!='' or $array["pid"]!='' or $array["bild"] or $array["ende"]>$array["anfang"]) and $id!=$array["id"])
      {echo '<a href="kalender.php?id='.$array["id"];
       if ($akt!='') echo '&akt=1';
       echo '"><b>'.$array["name"].'</b></a>';}
       
   else 
     {if ($array["link"] and $id!=$array["id"]) echo '<a href="'.$array["link"].'" target="_blank"><b>'.$array["name"].'</b></a>';
      else echo '<b>'.$array["name"].'</b>';}
    
  switch ($array["rubrik"])
   {
    case 1: echo '&nbsp;&nbsp;<i>[Kolloquium]</i>';break;
    case 2: echo '&nbsp;&nbsp;<i>[Pr&auml;sentation]</i>';break;
    case 3: echo '&nbsp;&nbsp;<i>[Seminar]</i>';break;
    case 4: echo '&nbsp;&nbsp;<i>[Feier]</i>';break;
   }
 if ($_SESSION["login"] == "true"){echo '<a href="../../admin/mi_veranstaltung.php?aktion=add&nr='.$array["id"].'"><img src="../../admin/img/edit_s.gif" border="0" alt="Eintrag bearbeiten" title="Eitrag bearbeiten" align="right"></a><a href="../../admin/mi_veranstaltung.php?aktion=del&nr='.$array["id"].'"><img src="../../admin/img/del_s.gif" border="0" alt="Eintrag l�schen" title="Eintrag l�schen" align="right"></a>';}
  echo '</td></tr>';

//mehr zur Veranstaltung ausgeben
  if ($id==$array["id"])
  {
   
   //Beschreibung ausgeben
   if ($array["beschreibung"]) echo '<tr><td colspan=2></td><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt">'.$array["beschreibung"].'</td></tr>';

   //Ende ausgeben
   if ($array["ende"])
   {
    if (timestamp_to_date($array["anfang"])<timestamp_to_date($array["ende"]) or timestamp_to_time($array["ende"])!="0:00")
     {
      echo '<tr><td colspan=2 width=10% valign="top" align="right" style="padding-left:10pt;padding-right:0pt;padding-top:5pt">Ende:</td><td valign="top" align="left" style="padding-left:10pt;padding-right:10pt;padding-top:5pt">';
      if (timestamp_to_date($array["anfang"])!=timestamp_to_date($array["ende"]))
          echo 'am '.timestamp_to_date($array["ende"]).' '; 
      if (timestamp_to_time($array["ende"])!="0:00")
          echo 'um '.timestamp_to_time($array["ende"]);
      echo '</td></tr>';
     }
   } 

   //Mitwirkende ausgeben
   if ($array["pid"]) 
   {
    $bet=split("_",$array["pid"]);
    for ($i=0;$i<count($bet);$i++) 
     {if ($query) $query.=' OR ';
      $query.='id='.$bet[$i];}
    $beteiligte=mysql_query("SELECT name, vname, titel FROM mi_prof WHERE ".$query);
    if (mysql_num_rows($beteiligte))
     while ($person=mysql_fetch_array($beteiligte))
     {
      if ($namen) $namen.=', ';
      $namen.=$person["titel"].'&nbsp;'.$person["vname"].'&nbsp;'.$person["name"];
     }
    echo '<tr><td colspan=2 valign="top" align="right" style="padding-left:10pt;padding-right:0pt;padding-top:5pt">Mit:</td><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:5pt">'.$namen.'</td></tr>';
   }

   //Bild ausgeben
   if ($array["bild"]) echo '<tr><td colspan=3 align="center" style="padding-left:10pt;padding-right:10pt;padding-top:5pt"><img src="img/'.$array["bild"].'"></td></tr>';

   //Link ausgeben
   if ($array["link"]) echo '<tr><td colspan=3 align="right" style="padding-left:10pt;padding-right:10pt;padding-top:5pt"><a href="'.$array["link"].'">mehr zu dieser Veranstaltung &gt;&gt;</a></td></tr>';
   echo '<tr height=10><td colspan=3></td></tr>';
  }
 }    
}
else 
 if (akt=='') echo 'Es stehen f&uuml;r die kommende Zeit keine weiteren Veranstaltungen an. Schauen Sie doch einfach sp&auml;ter nochmal vorbei.';
 else 'Es sind keine vergangenen Veranstaltungen gespeichert.';

//Link zu vergangenen/aktuellen Veranstaltungen
$anzahl=mysql_query("SELECT id FROM mi_veranstaltung");
if ($akt=='' and (mysql_num_rows($anzahl)>mysql_num_rows($veranstaltung))) 
  echo '<tr><td colspan=3 align="right" style="padding-left:10pt;padding-right:10pt;padding-top:10pt"><a href="kalender.php?akt=1">vergangene Veranstaltungen &gt;&gt;</a></td></tr>';
else
  if ($akt!='' and (mysql_num_rows($anzahl)>mysql_num_rows($veranstaltung)))
    echo '<tr><td colspan=3 align="right" style="padding-left:10pt;padding-right:10pt;padding-top:10pt"><a href="kalender.php">aktuelle Veranstaltungen &gt;&gt;</a></td></tr>';


 
echo '</table></center>';

if ($_SESSION["login"] == "true"){echo '<p align="right">
<a href="../../admin/mi_veranstaltung.php?aktion=add"><img src="../../admin/img/new_s.gif" border="0" alt="Eintrag hinzuf�gen" title="Eintrag hinzuf�gen"></a></p>';}
?>