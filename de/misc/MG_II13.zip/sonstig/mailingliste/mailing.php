<?php require_once('../../config.inc'); seite(__FILE__); ?> 

<p>
<center>
<img src="img/mi_mail.png" alt="Mailinglist" title="Mailinglist">
<p>
<table width=80% align="center">
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Zur Verbesserung der Kommunikation innerhalb des Studienganges zwischen den einzelnen Studenten bzw. zwischen den Lehrkr�ften und den Studenten wurden Mailinglisten eingerichtet. Dazu einige wichtige Informationen: 
</td></tr>
<tr><td align="left" class="grau"><b>&nbsp;Sinn und Zweck</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Der Vorteil einer Mailingliste liegt darin, dass man mit einer E-Mail einen weiten Empf�ngerkreis erreichen kann. Jeder, der sich irgendwann angemeldet hat, erh�lt alle Nachrichten, die auch alle anderen Listenmitglieder erreichen. Die Mailinglisten garantieren also, dass wichtige Informationen alle Studenten erreichen, f�r die sie bestimmt sind. Dabei muss nicth jede eMail an jeden Einzeln weggeschickt werden. �ber einen Verteiler wie die Mailingliste kann jedes Listenmitglied unproblematisch alle anderen Mitglieder erreichen. Der Absender muss nur eine einzige E-Mail an die Listenadresse verschicken, �ber die dann die Mail verteilt wird. 
</td></tr>
<tr><td align="left" class="grau"><b>&nbsp;Benutzung</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Sinn der Mailingliste ist es, dass wichtige Nachrichten ohne gro�en Aufwand alle Studenten erreichen. Je nach Konfiguration k�nnen Listenmitglieder oder aber auch listenfremde Personen Mails an die Listenadresse schicken. Um eine Nachricht an eine Liste zu schicken, muss deren Name bekannt sein (z.B. "medientheorie"). Aus diesem Namen leitet sich die Adresse ab, an die gemailt wird ("medientheorie@tu-chemnitz.de"). N�here Informationen zur Benutzung erhalten Sie auf den entsprechenden Mailinglist-Seiten. 
Weitere Informationen zur Benutzung des Mail-Verteilers erhalten Sie auf unter 
<a href = "http://mailman.tu-chemnitz.de">mailman.tu-chemnitz.de. </a>
</td></tr>
<tr><td align="left" class="grau"><b>&nbsp;Anmeldung</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Eine Anmeldung ist derzeit nur �ber die zentrale Mailinglisten-Verwaltung Mailman m�glich. Bitte nutzen Sie hierf�r die bereitgstellten
<a href = "http://mailman.tu-chemnitz.de"> Formulare</a>. �ber die erfolgreiche Anmeldung informiert eine Best�tigungsmail der Liste. 
</td></tr>
<tr><td align="left" class="grau"><b>&nbsp;Nutzungsbedingungen</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
�ber die Liste verteilte Informationen sollten einen Bezug zu Forschung und Lehre der Professur Medieninformatik haben. Des Weiteren gilt die 
<a href="http://www.tu-chemnitz.de/urz/ordnungen/">Benutzungsordnung des Universit�tsrechenzentrums</a> der TU Chemnitz.
</td></tr> 
</table>