<?php require_once('../../config.inc'); seite(__FILE__); ?> 

<?php 

echo '<br><center>
      <table width=80% align="center">
      <tr><td><img src="img/mi_links.png"></td></tr>';

//�bergebene Rubrik-ID lesen
$id=$_GET["id"];

//Rubriken ausgeben
$rubrik=mysql_query("SELECT id, name, beschreibung FROM mi_links_rubrik");
if (mysql_num_rows($rubrik))
{
 while ($rubarray=mysql_fetch_array($rubrik))
 {
  echo "<tr><td height=10></td></tr>";
  echo "<tr><td class=\"grau\" align=\"left\"><b>&nbsp;".$rubarray["name"]."</b></td></tr>";
  echo "<tr><td align=\"left\" style=\"padding-left:10pt;padding-right:10pt;padding-top:5pt\">".$rubarray["beschreibung"]."</td></tr>";

//wenn Rubrik-ID �bergeben wurde
  if ($id==$rubarray["id"])
  {
   $links=mysql_query("SELECT id, name, link, rubrik_id FROM mi_links WHERE rubrik_id='$id'");
   if (mysql_num_rows($links))
    while ($array=mysql_fetch_array($links))
    {
     echo "<tr><td align=\"left\" style=\"padding-left:10pt;padding-right:10pt;padding-top:5pt\">"; 
     if ($_SESSION["login"] == "true"){echo '
<a href="../../admin/mi_links.php?aktion=add&nr='.$array["id"].'"><img src="../../admin/img/edit_s.gif" border="0" alt="Eintrag bearbeiten" title="Eitrag bearbeiten"></a><a href="../../admin/mi_links.php?aktion=del&nr='.$array["id"].'"><img src="../../admin/img/del_s.gif" border="0" alt="Eintrag l�schen" title="Eintrag l�schen"></a>  ';} 
echo "<a href=\"".$array["link"]."\" target=\"_blank\">".$array["name"]."</a></td></tr>";
    }
  }

//wenn keine Rubrik-ID �bergeben wurde
  else echo "<tr><td align=\"left\" style=\"padding-left:10pt;padding-right:10pt;padding-top:5pt\"><a href=\"links.php?id=".$rubarray["id"]."\">anzeigen &gt;&gt;</td></tr>";

 }
}

echo "</table></center>";
if ($_SESSION["login"] == "true"){echo '<p align="right">
<a href="../../admin/mi_links.php?aktion=add"><img src="../../admin/img/new_s.gif" border="0" alt="Eintrag hinzuf�gen" title="Eintrag hinzuf�gen"></a></p>';}
?>
