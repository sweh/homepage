<?
require_once('../config.inc'); seite(__FILE__);

if ($_SESSION["login"] == "true"){

echo '<center><img src="mi_titelbild.png" border="0" align="center"></center>';

$aktion=$_GET["aktion"];

if($aktion=='neu'){
	echo '<form action="index.php?aktion=neu2" method="POST" enctype=multipart/form-data>
	<center>
	<table align="center" border="0" width="80%">
	<tr align="left"><td class="grau"><b>Name:</b></td></tr>
	<tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;"><input type="text" maxlength="20" name="name"></td></tr>
	<tr align="left"><td class="grau"><b>Bild:</b> (PNG - 500px breit)</td></tr>
	<tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;"><input type="file" size="30" name="bild"></td></tr>
	</table>
	</center>
	<input type="submit" value="Bild laden"></form>
	';
}

if($aktion=='neu2'){

$img='vorlagen/';

   $bild=$_FILES["bild"]["tmp_name"];
	$name=$_POST["name"];
//echo $_FILES["bild"][type];
	if($_FILES["bild"][type]!="image/png" and $_FILES["bild"][type]!="image/x-png"){echo '<p><font color="red"><b>Bild muss im PNG-Format vorliegen</b></font></p>';}
	else{
	$abfrage="insert into mi_titel set titel_name='$name'";
	$erg = mysql_query($abfrage);
	$id=mysql_insert_id();
	$abfrage="update mi_titel set ruf_name='$id' where id='$id'";
	$erg = mysql_query($abfrage);

	if(is_uploaded_file($bild)){
		upload($bild,$_FILES["bild"][type],$id,$img,"mi_");}
	}
	$aktion="";
}

if($aktion!='neu' and $aktion='neu2'){

	$typ=$_POST["typ"];
	$text=$_POST["text"];

	echo '<p><a href="?aktion=neu">neues Bild hinzuf�gen</a></p>

	<center>
	<table width=80% align="center">
	<form method="POST" action="index.php">
	<tr align="left"><td class="grau"><b>Text:</b></td></tr>
	<tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;"><input type="text" name="text" size="30" value="'.$text.'"></td></tr>
	<tr align="left"><td class="grau"><b>Bild:</b></td></tr>
	<tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">';

	$abfrage= "Select titel_name, ruf_name from mi_titel";
	$erg = mysql_query($abfrage);
	while(list($titel_name, $ruf_name) = mysql_fetch_row($erg)){
	echo '<input type="radio" name="typ" value="'.$ruf_name.'"'; if($typ==$ruf_name){echo ' checked';} echo '> '.$titel_name.'<br>';
	}

	echo '
	<br>
	<input type="submit" value="Erzeugen">
	</td></tr>
	</form>
	';

	if($typ!=''){
	$titelbildname="mi_temp.png";
	// $img="/vorlagen/";
	$img="../prof/img/";

	text_pic($text,$typ,$img,$titelbildname);

	echo '<tr align="left"><td class="grau"><b>Resultat:</b></td></tr>
	<tr align="left"><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;">
		Falls nur ein altes/falsches Bild erscheint "Reload" beim Browser dr�cken<br>
		<img src="'.$img.$titelbildname.'" border="0">
	</td></tr>';
	}

	echo'</table></center>';
}

}

else{echo "Sie haben keine Rechte hier!";}

?>