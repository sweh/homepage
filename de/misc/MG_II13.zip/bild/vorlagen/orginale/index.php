<?php
require_once('../../../config.inc'); seite(__FILE__);
?>
<center>
	<img src="../../../admin/img/mi_titel_keinzutritt.png" border="0" align="center">
</center>