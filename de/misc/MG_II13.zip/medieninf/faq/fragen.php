<?php require_once('../../config.inc'); seite(__FILE__); ?>    

<p>
<center> 
<img src="img/mi_faq.png" alt="Fragen"> 
<p>
<table width=80% align="center"> 
<tr><td class="grau" align="left" style="padding-left:5pt;padding-right:5pt"> 
<b>Welche T�tigkeitsfelder kann ich nach erfolgreichem Abschlu� des Studiums besetzen?</b>
</td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Die beruflichen Einsatzm�glichkeiten der Absolventen der Medieninformatik liegen in den Bereichen: 
<p><menu>
<li>Software-Entwicklung mit Bezug zu Medienprodukten: lokale oder vernetzte Multimedia-Anwendungen, </li>
<li>Verlage, Produktion von CD-ROMs, </li>
<li>Audio- und Videostudios, Rundfunk- und Fernsehbetriebe, digitale Filmproduktion, </li>
<li>Bildungsabteilungen in Unternehmen und �ffentlichen Institutionen, </li>
<li>Entwicklung didaktischer Medien: CBT, Hypermedia, Tele-Lernen, </li>
<li>Unternehmen im Bereich von B�ro- und Telekommunikation, </li>
<li>PR- und Kommunikationsabteilungen in Unternehmen, </li>
<li>Werbe- und Medienagenturen u.a. Point of Sale/Point of Information, netzbasierte Applikationen,</li> 
<li>Produktionsh�user f�r Computergrafiken und -animationen und virtuelle Realit�t, </li>
<li>Vertrieb von digitaler Audio- und Videotechnik sowie Multimedia-Komponenten bzw. -Systemen. </li>
</menu>
<p>
Weitere Inforamtionen erh�lst Du im Bereich 
<a href="../perspekt/allg.php">Berufsperspektiven.</a>
</td></tr>
<tr><td class="grau" align="left" style="padding-left:5pt;padding-right:5pt"><b>Was wird bei der Medieninformatik gelehrt?</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Der Studiengang ist von vornherein und bewusst interdisziplin�r ausgerichtet. Neben einer standfesten Ausbildung zum Diplom-Informatiker wirst Du im Studienverlauf daher auch st�ndig Ber�hrungspunkte zu anderen akademischen Disziplinen feststellen. Eine detaillierte Auflistung der zu belegenden F�cher findest Du in der Studienordnung. 
<p>
Weite Informationen findest Du auch im Bereich 
<a href="../beschreibung/gliederung.php">Beschreibung</a> des Studienganges
</td></tr>
<tr><td class="grau" align="left" style="padding-left:5pt;padding-right:5pt"><b>Welche praktischen Anteile beinhaltet dieses Studium?</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Eine Universit�t stellt eine wissenschaftliche Einrichtung dar. Somit vermittelt ein Gro�teil der Lehrveranstaltungen bevorzugt theoretisches und solides Grundlagenwissen. Praktische Anteile sind bei der Vertiefungsrichtung Medieninformatik bei den Praktikas zu den Vorlesungen Mediengestaltung bzw. Multimedia Applikationen zu finden. Die Teilnahme am sogenannten Internet/Multimedia Seminar des PM-Instituts w�hrend des Grundstudiums vermittelt ebenfalls praxisnahe F�higkeiten. Da die Medieninformatik nur eine Vertiefungsrichtung des Studienganges Angewandte Informatik ist, sind nat�rlich die Lehrveranstaltungen auf diesem Gebiet nicht zu vergessen. Hier z�hlen das Softwarepraktikum im Grundstudium, das 15-w�chige Betriebspraktikum bzw. das Systementwurfspraktikum im Hauptstudium zu der praxisnahen Lehre. 
</td></tr>
<tr><td class="grau" align="left" style="padding-left:5pt;padding-right:5pt"><b>Medieninformatik = Internet Programmierung und Web Design?</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Jein, mit starker Tendez zum Nein! Die Medieninformatik hat ihren Schwerpunkt im Bereich der Informatik. Eine grundlegende und solide Ausbildung zum Diplom-Informatiker steht im Mittelpunkt des Studienverlaufs.
Verwechsle Medieninformatik niemals mit verwandten Studieng�ngen wie etwa Mediengestaltung oder Medienkommunikation. Sicherlich wird Dir WebDesign im Studienverlauf begegnen und entsprechend Deinem eigenen Interesse kannst Du Dich in diesem Bereich st�rker engagieren. 
</td></tr>
<tr><td class="grau" align="left" style="padding-left:5pt;padding-right:5pt"><b>Helfen mir praktische Voraussetzungen bzw. sind diese notwendig f�rs Studium?</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Zun�chst einmal ist es nicht von Nachteil, wenn Du bereits Erfahrungen auf den Gebieten Elektrotechnik/Digitaltechnik, Algorithmen und Programmierung, Medientechnik und Mediengestaltung gesammelt hast. Ein gewisser Bezug zur Mathematik sollte Dir ebenfalls nicht fern liegen. Aber grunds�ztliche Voraussetzungen, um das Studium beginnen zu k�nnen werden nicht gestellt. Der Studiengang ist (noch) zulassungsfrei. Ob ein Studium der Informatik Deinen Neigungen und F�higkeiten �berhaupt entgegenkommt versucht dieser freiwillige Selbsttest des Fachschaftsrates zu beantworten. 
</td></tr>
<tr><td class="grau" align="left" style="padding-left:5pt;padding-right:5pt"><b>Was bedeutet die Abk�rzung 'SWS'?</b></td></tr> 
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Diese Abk�rzung steht f�r 'Semesterwochenstunden', wobei eine SWS den Zeitumfang von 45 Minuten hat. Eine Vorlesung oder �bung hat im allgemeinen den Umfang von 90 Minuten, was folglich 2 SWS entspricht. 
Einige �bungen finden nur im 2-Wochen-Rythmus statt, ihr zeitlicher Umfang wird daher mit 1 SWS angegeben. 
</td></tr>
<tr><td class="grau" align="left" style="padding-left:5pt;padding-right:5pt"><b>Gibt es einen Unterschied zwischen Schein und Leistungsnachweis?</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Ein ganz klares Ja! Scheine erfolgen in Erbringung einer Leistung (der Lehrende entscheidet �ber Art und Umfang dieser) und k�nnen benotet oder unbenotet vergeben werden. Die evtl. Note selbst hat in Bezug auf die Vordiploms- bzw. Diplomnote keinen Einfluss, sollte jedoch als Standortbestimmung f�r den Studenten angesehen werden.
Leistungsnachweise erfolgen mit Bestehen einer Pr�fung. D.h. es muss mindestens die Leistung "4" erbracht werden, um die Pr�fung als "Bestanden" abzuschliessen. Zu beachten hierbei ist, das nichtbestandenene Pr�fungen nur jeweils 1 mal widerholt werden d�rfen. Die Pr�fungsordnung legt dar�berhinaus fest, welche Anzahl an Leistungsnachweisen in die Vordiplom- bzw. Diplomnote eingebracht werden muss.
</td></tr>
<tr><td class="grau" align="left" style="padding-left:5pt;padding-right:5pt"><b>Weitere Fragen</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Mehr Fragen verlangen nach noch mehr Antworten. Diesem Thema hat sich speziell f�r Studienanf�nger die 
<a href="http://www.stura.tu-chemnitz.de/fibel/" target="_blank">Fibel</a> gewidmet.
<br>
Desweiteren kannst Du eine offene Frage, welche von allgemeinem Interesse sein k�nnte, an den Webmaster mailen, evtl. wird diese dann schon bald hier beantwortet werden. 
</td></tr> 
</table> 
</center>