<?php require_once('../../config.inc'); seite(__FILE__); ?>    

<?php
if ($_GET["show"])
{
  if (file_exists($_GET["show"].".php"))
    include_once($_GET["show"].".php");
  else
    echo "Sie haben eine falsche URL eingegeben!";
}
else
{
?>

<p>
<center> 
<img src="img/mi_faq.png" alt="faq"> 
<p>
<table width=80% align="center"> 
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt"> 
Als Studienanf�nger hat man viele Fragen auf dem Herzen, deren Kl�rung es bedarf. Zu kompliziert und undurchsichtig erscheint die Welt der Uni mit all ihren Ordnungen, Begriffen und Abk�rzungen. 
<p>
Und selbst wenn Ihr dann den Weg der universit�ren Ausbildung gew�hlt und anf�ngliche Probleme gemeistert habt, so werden Euch als Student m�glicherweise andere neue Fragen besch�ftigen. 
<p>
Die Rubrik 'FAQ' widmet sich diesen h�ufig gestellten Fragen bez�glich der Medieninformatik und versucht Euch eine Antwort darauf zu geben.
<p><a href="<?php echo $_SERVER["PHP_SELF"]; ?>?show=fragen">zu den Fragen und Antworten >></a>
</td></tr>
<tr><td class="grau" align="left"><b>&nbsp;Hinweise</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Eine individuelle und tiefgr�ndige Beratung kann hiermit nat�rlich nicht geboten werden. Somit wird der Weg zur Fachstudienberatung dennoch empfohlen um Probleme im Detail l�sen zu k�nnen. 
</td></tr> 
</table> 
</center>

<?php
}
?>