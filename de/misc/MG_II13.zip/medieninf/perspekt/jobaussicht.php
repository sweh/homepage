<?php require_once('../../config.inc'); seite(__FILE__); ?>     

<p>
<center> 
<img src="img/mi_job.png" alt="Jobaussichten"> 
<table width=80% align="center"> 
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt"> 
Die Jobaussichten in den einzelnen Medienbereichen sind �u�erst verschieden. Die Multimediabranche boomt, sp�testens seit Mitte der Neunziger. Von 1996 bis 1999 hat sich die Zahl der Besch�ftigten dort verdoppelt. In anderen Bereichen steigt ebenso die Nachfrage, vor allem nach Akademikern... 
<p>
Weitere Infos unter <a href="http://www.medienstudienfuehrer.de" target="_blank">www.medienstudienf&uuml;hrer.de</a>
</td></tr>
<tr><td class="grau" align="left"><b>&nbsp;Mediendesign</b></td></tr>
<tr><td  align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Die Gestaltung von Medien wird - bei einer st�ndig wachsenden Zahl von Angeboten - immer wichtiger. Firmen und Organisationen m�ssen sich von anderen Angeboten abheben und mit einem einheitlichen �u�eren Erscheinungsbild, Corporate Design, Wiedererkennungswert schaffen...
<p>
<a href="<?php echo $_SERVER["PHP_SELF"]; ?>?show=mediendesign">mehr >></a>
</td></tr>
<tr><td class="grau" align="left"><b>&nbsp;Medientechnik</b></td></tr>
<tr><td  align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Das technische Umfeld der Medien entwickelt sich seit Jahren rasant. Die Digitalisierung hat l�ngst nicht nur Tontr�ger ver�ndert, sondern setzt sich auch in den �bertragungstechniken durch... 
<p>
<a href="<?php echo $_SERVER["PHP_SELF"]; ?>?show=medientechnik">mehr >></a>
</td></tr>
<tr><td class="grau" align="left"><b>&nbsp;Multimedia</b></td></tr>
<tr><td  align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Von allen Seiten werden die Karrierechancen im Bereich Multimedia/Medieninformatik als hervorragend bewertet. Da dieser Bereich allerdings noch recht jung ist, sind "feste" Berufsbilder und Ausbildungsg�nge erst in der Entstehung...
<p>
<a href="<?php echo $_SERVER["PHP_SELF"]; ?>?show=multimedia">mehr >></a>
</td></tr> 
</table> 
</center>