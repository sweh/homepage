<?php require_once('../../config.inc'); seite(__FILE__); ?>      

<p>
<center> 
<img src="img/mi_mdesign.png" alt="Mediendesign"> 
<p>
<table width=80% align="center"> 
<tr><td class="grau" align="left"><b>&nbsp;Charakteristik</b></td></tr>
<tr><td  align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Die Gestaltung von Medien wird - bei einer st�ndig wachsenden Zahl von Angeboten - immer wichtiger. Firmen und Organisationen m�ssen sich von anderen Angeboten abheben und mit einem einheitlichen �u�eren Erscheinungsbild, Corporate Design, Wiedererkennungswert schaffen. Auch die neuen Medien bieten st�ndig neuen Spielraum f�r grafische M�glichkeiten. An einem professionellen Internet-Angebot arbeiten in der Praxis Grafiker und Programmierer h�ufig eng zusammen. Aber auch Printmedien werden mit Desktop-Publishing-Systemen an Rechnern f�r den Druck vorbereitet. So ist es kaum verwunderlich, dass Computerkenntnisse, vor allem die Anwendung verschiedener Software, ein wesentlicher Bestandteil dieser Ausbildung sind. 
<p>
M�gliche Schwerpunkte w�hrend des Studiums im Bereich "Mediendesign" k�nnen sein: "Visuelle Kommunikation", "Typografie" (die Gestaltung von geschriebener Sprache), "Multimedia" (zum Beispiel Interface-Design f�r Internet-Pr�sentationen und Software) oder auch die "Fotografie". 
</td></tr>
<tr><td class="grau" align="left"><b>&nbsp;Aufgaben und T�tigkeiten</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Diplom-Designer/innen f�r Grafik- und Kommunikations- bzw. Mediendesign sind vor allem in der visuellen Gestaltung und Planung von Werbung und �ffentlichkeitsarbeit t�tig. Sie entwerfen - meist computerunterst�tzt - grafische Kommunikationsmittel wie zum Beispiel Anzeigen, Verpackungen, Plakate, Firmenlogos, Bildschirmoberfl�chen, Werbespots oder das Design von Datenbanken, Multivisionen, Internet- und Intranetseiten, elektronischen Kiosksystemen oder Screens. 
<p>
Um ihre Kunden kompetent beraten zu k�nnen, ber�cksichtigen sie bei ihren �berlegungen ver�nderte Gewohnheiten und modische Tendenzen, sowie gegebenenfalls technische M�glichkeiten. 
<p>
Grafik- und Kommunikations- bzw. Mediendesigner/innen sind haupts�chlich im Bereich Werbung und �ffentlichkeitsarbeit t�tig. Hier arbeiten sie zum Beispiel in Werbeagenturen, in Werbeabteilungen der Industrie oder in Grafik-Design-B�ros. Ihr Arbeitsplatz ist vorwiegend im B�ro oder im Atelier, sie beraten Kunden jedoch auch vor Ort. 
<p>
Diesen Artikel und detailierte Informationen bietet die Datenbank f�r Ausbildungs- und T�tigkeitsbeschreibungen der Bundesanstalt f�r Arbeit.
</td></tr>
<tr><td class="grau" align="left"><b>&nbsp;Download</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Die oben aufgef�hrten Informationen sind auch zum Offline-Lesen als PDF Dokument verf�gbar.
<br><a href="doc/berufsmoeglichkeiten.pdf">
Berufsperspektiven als PDF</a> (189 kByte) 
</td></tr> 
</table> 
</center> 