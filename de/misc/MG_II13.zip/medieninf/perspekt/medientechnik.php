<?php require_once('../../config.inc'); seite(__FILE__); ?>      

<p>
<center> 
<img src="img/mi_mtechnik.png" alt="medientechnik"> 
<p>
<table width=80% align="center"> 
<tr><td class="grau" align="left"><b>&nbsp;Charakteristik</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Das technische Umfeld der Medien entwickelt sich seit Jahren rasant. Die Digitalisierung hat l�ngst nicht nur Tontr�ger ver�ndert, sondern setzt sich auch in den �bertragungstechniken durch. 
<p>
Bisher ist aber kaum absehbar, welche verschiedenen Techniken und Systeme sich durchsetzen werden. Bekommen wir die Medienangebote per Satellit, Glasfaserkabel oder terrestrisch ins Haus? Und wann wird das Handy zum Highspeed-Data-Zugang? Wie werden Fernseher und Computer zusammenwachsen? Aber auch herk�mmliche Medien und deren Herstellungstechniken entwickeln sich weiter, zum Beispiel Drucktechnik.
</td></tr>
<tr><td class="grau" align="left"><b>&nbsp;Aufgaben und T�tigkeiten</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Als Generalisten der Medienbranche m�ssen Ingenieure und Ingenieurinnen f�r Medientechnik technische, kaufm�nnische und teilweise auch k�nstlerische F�higkeiten in sich vereinen. Konzeption, Planung, Gestaltung und Installation, teilweise auch Marketing und Vertrieb von Medienprodukten ist ihr Metier. Oft sind sie auch in der Organisation oder Projektleitung bei der Herstellung von Filmen, Videos, CD-ROMs, interaktiven und multimedialen Dienstleistungen sowie H�rfunkbeitr�gen t�tig. 
<p>
Ingenieure und Ingenieurinnen f�r Medientechnik finden Besch�ftigungsm�glichkeiten zum Beispiel bei PR- und Werbeagenturen, in Film-, Funk- und Videostudios, bei Soft- und Hardwarefirmen oder im Fachhandel. 
</td></tr>
<tr><td class="grau" align="left"><b>&nbsp;Download</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Die oben aufgef�hrten Informationen sind auch zum Offline-Lesen als PDF Dokument verf�gbar.
<br><a href="doc/berufsmoeglichkeiten.pdf">
Berufsperspektiven als PDF >>></a> (189 kByte) 
</td></tr> 
</table> 
</center> 
