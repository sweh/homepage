<?php require_once('../../config.inc'); seite(__FILE__); ?>      

<p>
<center> 
<img src="img/mi_mmedia.png" alt="multimedia"> 
<p>
<table width=80% align="center"> 
<tr><td class="grau" align="left"><b>&nbsp;Charakteristik</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Von allen Seiten werden die Karrierechancen im Bereich Multimedia/Medieninformatik als hervorragend bewertet. Da dieser Bereich allerdings noch recht jung ist, sind "feste" Berufsbilder und Ausbildungsg�nge erst in der Entstehung. Allgemein geht es in diesen Bereichen um neue Kommunikationswege durch neuartige technische Entwicklungen (verbesserte Computerleistung, Verschmelzung bisher getrennter Medien, wie etwa TV und Computer, etc.) Neue Multimedia-Technologien werden in naher Zukunft eine immer bedeutendere Rolle in Wirtschaft, Industrie, Verwaltung und Bildung spielen. Das bedeutet, da� es ein Bedarf an fachlich geschultem Personal geben wird, welches in der Lage ist, sich mit diesen neue Medien in kompetenter Weise auseinanderzusetzen. 
</td></tr>
<tr><td class="grau" align="left"><b>&nbsp;Ausbildung und T�tigkeiten </b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Medieninformatiker/innen gestalten und integrieren unterschiedliche Medien wie Grafik, Bild, Text, Ton, Video, Computeranimation. Sie konzipieren und entwickeln Medieninformationssysteme, insbesondere Multimediaprogramme, aber auch CBT-Programme (Computer Based Training) und andere medienspezifische Anwendungen und Produkte. Sie entwerfen Multimediakonzepte und AV-Medienprodukte und realisieren sie, arbeiten in Planung und Entwicklung von Multimedia-Hard- und Software und anderen Softwareprodukten und entwickeln nutzerfreundliche Bedienoberfl�chen. Sie programmieren und gestalten interaktive und multimediale Informations- und Schulungssysteme und implementieren, installieren, verwalten, warten und pflegen Medieninformationssysteme aller Art. Sie besch�ftigen sich am Bildschirm mit Kommunikationsdesign, Grafikdesign, Animationsdesign und k�mmern sich um das Informations- und Kommunikationsmanagement bei den Anwendern von Produkten der Medieninformatik. Sie wirken mit im Projektmanagement f�r Medienprojekte oder fungieren selbst als Projektleiter/innen und leisten Support f�r Marketing- und Vertrieb, Werbung und Public Relations. 
<p>
Medieninformatiker/innen sind vorwiegend in der Softwareentwicklung f�r Multimediaanwendungen und Internet-Programme, einschlie�lich Lernsoftware, sowie in Multimedia-, Marketing-, Werbe- und PR-Agenturen, Softwareh�usern (Softwareentwicklung), bei Verlagen, in den elektronischen Medien (Rundfunk, Fernsehen) t�tig, aber auch in DV-, PR- und Marketing-Abteilungen von Unternehmen sowie in der Softwareberatung und -schulung im Multimedia- und Internetbereich. Dort arbeiten sie haupts�chlich in mit moderner Informations- und Kommunikationstechnik ausgestatteten B�ror�umen mit Bildschirmarbeitspl�tzen. 
<p>
Diesen Artikel und detailierte Informationen bietet die Datenbank f�r Ausbildungs- und T�tigkeitsbeschreibungen der Bundesanstalt f�r Arbeit.
</td></tr>
<tr><td class="grau" align="left"><b>&nbsp;Download</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Die oben aufgef�hrten Informationen sind auch zum Offline-Lesen als PDF Dokument verf�gbar.
<br><a href="doc/berufsmoeglichkeiten.pdf">
Berufsperspektiven als PDF >>></a> (189 kByte) 
</td></tr> 

</table> 
</center> 
