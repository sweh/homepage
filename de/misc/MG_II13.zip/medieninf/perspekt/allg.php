<?php require_once('../../config.inc'); seite(__FILE__); ?>    
<?php
if ($_GET["show"])
{
  if (file_exists($_GET["show"].".php"))
    include_once($_GET["show"].".php");
  else
    echo "Sie haben eine falsche URL eingegeben!";
}
else
{
?>
<p>
<center> 
<img src="img/mi_perspektiven.png" alt="Berufsperspektiven"> 
<table width=80% align="center"> 
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt"> 
Seit den achtziger Jahren gelten "die Medien" als Wachstumsbranche und als T�tigkeitsfeld mit Zukunft. Insbesondere die sprunghafte Entwicklung der Computertechnologie und die verschiedenen neuen M�glichkeiten der Telekommunikation, die Zunahme vor allem privater Fernseh- und Radiokan�le sowie das Vordringen der audio-visuellen Medien und der Computer bis hinein in den privaten Alltag haben nicht nur Technikbegeisterung, sondern auch kommerzielle und kulturpolitische Erwartungen hervorgerufen...  
<p>
Weitere Infos unter <a href="http://www.studienwahl.de/display/map/jump.asp?KAPID=99" target="_blank">www.studienwahl.de</a><p>

Die Berufschancen auf dem Gebiet der Medieninformatik sind vielseitig. T�glich entstehen neue Firmen in dieser Branche mit einem ungeheueren Bedarf an Fachleuten. 
</td></tr>
<tr><td class="grau" align="left"><b>&nbsp;Besch�ftigungsm�glichkeiten</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">Absolventen aus dem Bereich Medien k�nnen in Produktionsstudios von H�rfunk- oder Fernsehsendern arbeiten, als Projektleiter, Techniker, Konzeptioner oder Producer in einer Multimedia-Agentur, bei Werbeagenturen, Verlagen, anderen Unternehmen der Medienbranche. <p>
<a href="<?php echo $_SERVER["PHP_SELF"]; ?>?show=beschaeftigung">mehr >></a>
</td></tr>
<tr><td class="grau" align="left"><b>&nbsp;Jobaussichten</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">Die Jobaussichten in den einzelnen Medienbereichen sind �u�erst verschieden. Die Multimediabranche boomt, sp�testens seit Mitte der Neunziger... 
<p>
<a href="<?php echo $_SERVER["PHP_SELF"]; ?>?show=jobaussicht">mehr >></a>
</td></tr> 
</table> 
</center>
<?php
}
?>