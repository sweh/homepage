<?php require_once('../../config.inc'); seite(__FILE__); ?>    

<p>
<center> 
<img src="img/mi_moeglichkeiten.png" alt="Besch�ftigungsm�glichkeiten"> 
<table width=80% align="center"> 
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt"> 
Absolventen aus dem Bereich Medien k�nnen in Produktionsstudios von H�rfunk- oder Fernsehsendern arbeiten, als Projektleiter, Techniker, Konzeptioner oder Producer in einer Multimedia-Agentur, bei Werbeagenturen, Verlagen, anderen Unternehmen der Medienbranche. Mit Studienschwerpunkt Medienplanung, -beratung, -wissenschaft ergeben sich T�tigkeitsfelder in der Programm- oder Personalplanung der AV-Medien oder Media-Planung bei gro�en Verlagen und Werbeagenturen, in der Planung und Durchf�hrung von Kommunikations- und Medienaktivit�ten von H�rfunk- bzw. TV-Sendern oder in der Studien- und Projektleitung bei Meinungsforschungsinstituten. 
<p>
Dieser Artikel ist auf den Webseiten der Studien- & Berufswahl online zu finden. 
<p>
Andere m�gliche Arbeitgeber sind Softwareh�user, Telekommunikationsunternehmen und Verlage, aber auch Schulungs-, EDV-, �ffentlichkeits-und Vertriebsabteilungen der meisten Unternehmen. 
<p>
Viele neue Berufe sind in den letzten Jahren hinzugekommen. Die Gr�nde: Das Internet setzt sich immer mehr als Alltagsmedium durch und verlangt andere Arbeitsleistungen als bisher. Au�erdem sind die neuen Techniken immer st�rker in die traditionellen Medienbereich vorgedrungen. Der <a href="http://www.mediencampusbayern.de/" target="_blank">Mediencampus Bayern</a> hat insgesamt 77 Berufsbilder gefunden: von Aufnahmeleitern und Filmcuttern, zu Multimedia-Autoren und Programmieren, bis hin zu Trailerproduzenten und Werbevorlagenherstellern
<p>
Dieser Artikel ist auf den Webseiten des Medienstudienf�hrers zu finden.
</td></tr>
<tr><td class="grau" align="left"><b>&nbsp;Abzusehende Prozesse</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Ausgebildete Medieninformatiker kommen in vielen Bereichen zum Einsatz. Sie werden u.a. insbesondere in folgenden Einsatzgebieten bzw. T�tigkeitsumfeldern ben�tigt und gefordert. 
<p>
<menu>
<li>Lehren und Lernen in allen Bildungsstufen </li>
<li>Computersimulation </li>
<li>Internetshopping </li>
<li>Bankgesch�fte </li>
<li>Massenauflagen von kulturellen und wissenschaftlichen Publikationen </li>
<li>Computertechnologien in herk�mmlichen Publikationsformen, wie Druck und Fernsehen </li>
<li>Verbreitung und Diskussion wissenschaftlicher Arbeiten sowie technischer Entwicklungen</li> 
<li>Stellung der Menschen in der Informationsgesellschaft </li>
</menu>
</td></tr>
<tr><td class="grau" align="left"><b>&nbsp;Download</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Die oben aufgef�hrten Informationen sind auch zum Offline-Lesen als PDF Dokument verf�gbar.
<br><a href="doc/berufsmoeglichkeiten.pdf">
Berufsperspektiven als PDF</a> (189 kByte) 
</td></tr> 

</table> 
</center>