<?php require_once('../../config.inc'); seite(__FILE__); ?>  

<p><center> 
<img src="img/mi_mi.png" alt="Beschreibung">
<p> 
<table width=80% align="center"> 
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt"> 
Als eine angewandte Informatik befasst sich die Medieninformatik mit allen Aspekten der Generierung, Kodierung, Verarbeitung, Distribution und Pr�sentation digitaler Medien und der Gestaltung von multimedialen und multimodalen Informationssystemen. Neben der Entwicklung operativer Systeme geh�rt auch die wissenschaftliche Modellbildung bzgl. solcher Systeme zum Gegenstandsbereich der Medieninformatik. 
<p>
Beispiele solcher Systeme sind 
<p>
<menu>
<li>
Kooperative Kommunikationssysteme und ihre Unterst�tzung durch digitale Medien </li>
<li>
Multimediale Anwendungen im Bereich des e-Learning bzw. des elektronischen Publizierens und die f�r sie erforderliche Infrastruktur (Klassen von Informationssystemen, die den verschiedenen Stufen der digitalen Medienproduktionskette zugeordnet werden k�nnen) 
</li><li>
Adaptive und personalisierte Mediensysteme, die neue Mediennutzungsformen unterst�tzen und optimieren 
</li><li>
Mediensysteme, die �ber unterschiedliche Interaktions- und Kommunikationsmodi gesteuert und genutzt werden k�nnen, insbesondere mit Hinblick auf mobile Anwendungen 
</li>
</menu>
<p>
Die Medieninformatik ist eine angewandte Informatik und verwendet daher das Methodenrepertoire der Informatik. Die Besonderheiten ihres Bezugsbereichs Medien bedingen, dass die Medieninformatik auch geistes- und sozialwissenschaftliche sowie k�nstlerisch-�sthetische Aspekte ber�hrt. Sie ist daher ein genuin interdisziplin�res Arbeitsfeld im Schnittbereich von Informatik, Medientechnik, Medienwissenschaft, Informationswissenschaft, Philologie(n), Psychologie, P�dagogik, Kunst und Betriebswirtschaftslehre. 
<p>
Ungeachtet der derzeitigen Konsolidierung in der Medienwirtschaft ist mittel- und langfristig mit einem hohen Ausbildungsbedarf in diesem Bereich zu rechnen. 
<tr><td align="left" class="grau"><b>&nbsp;Download</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt"> 
Die oben aufgef�hrten Informationen sind auch zum Offline-Lesen als PDF-Dokument verf�gbar.
<a href="doc/studium.pdf">
Informationen zum Studium als PDF</a> (68 kByte)
</justify>
</td></tr> 
</table> 
</center>
