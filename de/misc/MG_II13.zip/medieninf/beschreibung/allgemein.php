<?php require_once('../../config.inc'); seite(__FILE__); ?>   
<?php
if ($_GET["show"])
  include_once($_GET["show"].".php");
else
{
?>
<p><center> 
<img src="img/mi_infos.png" alt="Beschreibung"> 
<p>
<table width=80% align="center"> 
<tr><td align="left" class="grau"><b>&nbsp;Was ist Medieninformatik?</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Als eine angewandte Informatik befasst sich die Medieninformatik mit allen Aspekten der Generierung, Kodierung, Verarbeitung, Distribution und Pr�sentation digitaler Medien und der Gestaltung von multimedialen und multimodalen Informationssystemen.
<br><br>
<a href="<?php echo $_SERVER["PHP_SELF"]; ?>?show=beschreibung">mehr >></a>
</td></tr>

<tr><td align="left" class="grau"><b>&nbsp;Gliederung des Studiums </b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
Die Vertiefungsrichtung ist von vornherein interdisziplin�r ausgerichtet. Der wesentliche Gegenstand des Studiums sind Informatik-Grundlagen unterschiedlicher Medien.
<br><br>
<a href="<?php echo $_SERVER["PHP_SELF"]; ?>?show=gliederung">mehr >></a>
</td></tr>

<tr><td align="left" class="grau"><b>&nbsp;Ausstattung der Professur</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">
6 Arbeitspl�tze f�r Authoring und Videoschnitt / Audiobearbeitung...
<br><br>
<a href="<?php echo $_SERVER["PHP_SELF"]; ?>?show=ausstattung">mehr >></a>
</td></tr> 
</table>
</center> 
<?php
}
?>