<?php require_once('../../config.inc'); seite(__FILE__); ?>   

<p>
<center> 
<img src="img/mi_ausstattung.png" alt="ausstattung"> 
<p>
<table width=80% align="center"> 
<tr><td align="left">
<b>6 Arbeitspl�tze f�r Authoring und Videoschnitt / Audiobearbeitung:</b>
<p>
<menu>
<li>PC unter Windows 2000 Prof.</li> 
<li>Athlon 1000MHz / 1200MHz </li>
<li>512MB RAM </li>
<li>40GB Systemplatte</li> 
<li>160GB RAID-Array f�r Mediendaten (2*80) </li>
<li>64MB Nvidia-GTS2 Grafikbeschleuniger</li> 
<li>DVD-ROM und Dekoderkarte SVHS- / Composite-Ausgang, DOLBY AC3</li> 
<li>CD-Recorder </li>
<li>hochwertiges Soundsystem mit Subwoofer </li>
<li>optische Mouse, Tastatur </li>
<li>100MBit � LAN, lokaler Switch im Raum 1/B103 </li>
<li>Schnittkarte f�r IEEE1394, SVHS und Composite, Pinneacle DV500PLUS </li>
<li>Mikrofon </li>
<li>21� Monitor mit Flat-Tube</li> 
<li>72cm TV-Ger�t</li> 
<li>Software: W2K, Office2000 Prof., Corel, Macromedia Director 8.5, Flash5, Authorware in akt. Release, Adobe Premiere 5.1C / 6.0, Photoshop 5 LE </li>
<li>Frontpage2000 </li>
<li>div. Tools</li> 
<li>extra gro�er Arbeitstisch</li> 
</menu>
<p>
<b>2 Flachbettscanner HP 6200C</b>
<p>
<b>1 Fotodrucker HP Photosmart 1150C</b>
<p>
<b>1 Kamera IEEE1394, 3-Chip, Sony DCR2000</b>
<p>
<b>1 dig. Fotoapparat Sony 505V, 3MPixel</b>
<p>
<b>1 Medienserver</b>
<p>
<menu>
<li>800MHz</li> 
<li>512MB RAM</li> 
<li>40GB Systemplatte</li> 
<li>2*100MBit LAN, Router zum Campusnetz </li>
<li>650GB RAID-5 Subsystem f�r Datenbest�nde </li>
<li>arbeitet als Router f�r TU-Backbone-Anbindung </li>
<li>1 FAST-Ethernet-Switch 16-Port</li>
<p>
</td></tr> 
</table> 
</center>
