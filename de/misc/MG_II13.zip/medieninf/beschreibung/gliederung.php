<?php require_once('../../config.inc'); seite(__FILE__); ?>   

<p> 
<center> 
<img src="img/mi_gliederung.png" alt="Gliederung des Studiums"> 
<p>
<table width=80% align="center"> 
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt"> 
Die Fakult�t f�r Informatik der TU Chemnitz bietet ab Wintersemester 1999/2000 f�r den Studiengang <a href="http://www.tu-chemnitz.de/studium/studiengaenge/diplom/angewandte_informatik.php">Angewandte Informatik</a> die neue Vertiefungsrichtung "Medieninformatik" an. Sie tut es in der Erkenntnis, dass das zunehmende Vordringen der Informatik in alle gesellschaftlichen Bereiche eine Gestaltung von Informationen in applikationsspezifischen Medien erfordert. 
<p>
Die Vertiefungsrichtung ist von vornherein interdisziplin�r ausgerichtet durch 
<p>
<menu>
<li>
Informatik-Grundlagen und Systemgestaltung (
<a href="http://www.tu-chemnitz.de/informatik/">Fakult�t f�r Informatik</a>)</li>
<li>Printmedien (<a href="http://www.tu-chemnitz.de/mbv/">Fakult�t f�r Maschinenbau und Verfahrenstechnik</a>) </li>
<li>Soziale Kompetenz (<a href="http://www.tu-chemnitz.de/phil/">Philosophische Fakult�t</a>)</li>
</menu> 
</td></tr>
<tr><td class="grau" align="left"><b>&nbsp;Gegenstand des Studiums</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt"> 
Der wesentliche Gegenstand des Studiums sind Informatik-Grundlagen unterschiedlicher Medien, wie 
<menu> 
<li>Bilder - Printmedien </li>
<li>Grafiken - CD</li> 
<li>Bildsequenzen</li> 
</menu> 
</td></tr>
<tr><td class="grau" align="left"><b>&nbsp;Grundstudium</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt"> 
Neben der Mathematik und den Grundlagen der Informatik werden im Grundstudium folgende Lehrveranstaltungen angeboten. 
<p><menu> 
<li>Mediengestaltung</li> 
<li>Mathematische Grundlagen der Computergeometrie</li> 
<li>Medientheorie</li> 
<li>Grundlagen der Medientechnik</li> 
<li>Medienrecht</li> 
</menu>
</td></tr>
<tr><td class="grau" align="left"><b>&nbsp;Hauptstudium</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt"> 
Im Hauptstudium wird die Ausbildung in den Informatikdisziplinen fortgesetzt, und in der Vertiefungsrichtung Medieninformatik werden u.a. folgende Lehrveranstaltungen angeboten. 
<p><menu> 
<li>Bildverarbeitung </li>
<li>Computergrafik</li> 
<li>Geometrische Modellierung</li> 
<li>Kooperationssysteme</li> 
<li>Lernsysteme</li> 
<li>Mediendatenbanken</li> 
<li>Mediensystem</li> 
</menu> 
</td></tr>
<tr><td class="grau" align="left"><b>&nbsp;Hinweise</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt"> 
Weiterf�hrende Informationen gibt die zentrale Studienberatung der TU-Chemnitz bzw. die Fachstudienberatung der Fakult�t f�r Informatik. 
</td></tr>
<tr><td class="grau" align="left"><b>&nbsp;Download</b></td></tr>
<tr><td align="left" style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt"> 
Die oben aufgef�hrten Informationen sind auch zum Offline-Lesen als PDF-Dokument verf�gbar.
<br><a href="doc/studium.pdf">
Informationen zum Studium als PDF</a> (68 kByte)
</td></tr> 
</table> 
</center>
