<?php require_once('../config.inc'); seite(__FILE__); ?> 

<?php 

echo '
<br>
<center><img src="img/mi_prof.png" align="center"></center>
<table width=100%>
<tr height=10><td></td></tr>
<tr>';
if ($_SESSION["login"] == "true"){echo '<th><a href="../admin/mi_prof.php"><img src="../admin/img/edit_s.gif" border="0" alt="Eintr�ge bearbeiten" title="Eintr�ge bearbeiten"></a></th>';}
echo '
<th width=30%>Name</th>
<th width=45%>Email</th>
<th width=15%>Tel.</th>
<th width=10%>Zi.</th>
<//tr>';

//Zeit in Semester umwandeln
$sem=call_user_func("akt_semester");

//Lehrstuhlinhaber und Vertretung ausgeben
$professor=mysql_query("SELECT id, name, vname, titel, zimmer, telefon, email, funktion, ende FROM mi_prof WHERE (funktion=1 OR funktion=5) AND (ende='' OR ende>='$sem') AND anfang<='$sem'");
if (mysql_num_rows($professor))
{
 echo "<tr height=28pt><td colspan=4><b>Lehrstuhlinhaber:</b></td></tr>";
 while ($array=mysql_fetch_array($professor))
 {
   echo "<tr height=25pt bgcolor=\"#CCE7E7\">";
      if ($_SESSION["login"] == "true"){echo '<td>
      <a href="../admin/mi_prof.php?aktion=add&nr='.$array["id"].'"><img src="../admin/img/edit_s.gif" border="0" alt="Eintrag bearbeiten" title="Eintrag bearbeiten"></a><a href="../admin/mi_prof.php?aktion=del&nr='.$array["id"].'"><img src="../admin/img/del_s.gif" border="0" alt="Eintrag l�schen" title="Eintrag l�schen"></a></td>
      ';}
   echo "<td><a href=\"prof.php?id=".$array["id"]."\">";
   if (!empty($array["titel"])) echo $array["titel"]."&nbsp;";
   echo $array["vname"]."&nbsp;".$array["name"]."</a>&nbsp;";
   if ($array["funktion"]==5) echo "( i.V.)</td>";
   echo "<td><a href=\"mailto:".$array["email"]."\">".$array["email"]."</a></td>";
   echo "<td align=\"center\">".$array["telefon"]."</td>";
   echo "<td align=\"center\">".$array["zimmer"]."</td>";
   echo "</tr>";
 }
}

//Sekret�rin ausgeben
$sekret=mysql_query("SELECT id, name, vname, titel, zimmer, telefon, email, funktion, ende FROM mi_prof WHERE funktion=4 AND (ende='' OR ende='$sem')");
if (mysql_num_rows($sekret))
 {
  echo "<tr height=28pt><td colspan=4><b>Sekret&auml;r/in:</b></td></tr>";
  while ($array=mysql_fetch_array($sekret))
  {
   echo "<tr height=25pt bgcolor=\"#CCE7E7\">";
      if ($_SESSION["login"] == "true"){echo '<td>
      <a href="../admin/mi_prof.php?aktion=add&nr='.$array["id"].'"><img src="../admin/img/edit_s.gif" border="0"></a><a href="../admin/mi_prof.php?aktion=del&nr='.$array["id"].'"><img src="../admin/img/del_s.gif" border="0"></a></td>
      ';}

   echo "<td>";
   if (!empty($array["titel"])) echo $array["titel"]."&nbsp;";
   echo $array["vname"]."&nbsp;".$array["name"]."</td>";
   echo "<td><a href=\"mailto:".$array["email"]."\">".$array["email"]."</a></td>";
   echo "<td align=\"center\">".$array["telefon"]."</td>";
   echo "<td align=\"center\">".$array["zimmer"]."</td>";
   echo "</tr>";
  }
 }

//Wissenschaftliche Mitarbeiter und Hilfswissenschaftler ausgeben
$WiMit=mysql_query("SELECT id, name, vname, titel, zimmer, telefon, email, funktion FROM mi_prof WHERE funktion=2 OR funktion=3");
if (mysql_num_rows($WiMit))
 {
   echo "<tr height=28pt><td colspan=4><b>Wissenschaftliche 
Mitarbeiter/Hilfsmitarbeiter:</b></td></tr>";
  while ($array=mysql_fetch_array($WiMit))
  {
   echo "<tr height=25pt bgcolor=\"#CCE7E7\">";
      if ($_SESSION["login"] == "true"){echo '<td>
      <a href="../admin/mi_prof.php?aktion=add&nr='.$array["id"].'"><img src="../admin/img/edit_s.gif" border="0"></a><a href="../admin/mi_prof.php?aktion=del&nr='.$array["id"].'"><img src="../admin/img/del_s.gif" border="0"></a></td>
      ';}
   echo "<td>";
   if (!empty($array["titel"])) echo $array["titel"]."&nbsp;";
   echo $array["vname"]."&nbsp;".$array["name"]."</td>";
   echo "<td><a href=\"mailto:".$array["email"]."\">".$array["email"]."</a></td>";
   echo "<td align=\"center\">".$array["telefon"]."</td>";
   echo "<td align=\"center\">".$array["zimmer"]."</td>";
   echo "</tr>";
  }
 }

//Studenten und sonstige ausgeben
$stud_sonst=mysql_query("SELECT id, name, vname, titel, zimmer, telefon, email, funktion FROM mi_prof WHERE funktion=0 OR funktion=6");
if (mysql_num_rows($stud_sonst))
 {
  echo "<tr height=28pt><td colspan=4><b>Studenten/Sonstige:</b></td></tr>";
  while ($array=mysql_fetch_array($stud_sonst))
  {
   echo "<tr height=25pt bgcolor=\"#CCE7E7\">";
      if ($_SESSION["login"] == "true"){echo '<td>
      <a href="../admin/mi_prof.php?aktion=add&nr='.$array["id"].'"><img src="../admin/img/edit_s.gif" border="0"></a><a href="../admin/mi_prof.php?aktion=del&nr='.$array["id"].'"><img src="../admin/img/del_s.gif" border="0"></a></td>
      ';}

   echo "<td>";
   if (!empty($array["titel"])) echo $array["titel"]."&nbsp;";
   echo $array["vname"]."&nbsp;".$array["name"];
   if ($array["funktion"]==6) echo "&nbsp;(Student)";
   echo "</td>";
   echo "<td><a href=\"mailto:".$array["email"]."\">".$array["email"]."</a></td>";
   echo "<td align=\"center\">".$array["telefon"]."</td>";
   echo "<td align=\"center\">".$array["zimmer"]."</td>";
   echo "</tr>";
  }
 }

echo "</table>";

if ($_SESSION["login"] == "true"){echo '<p align="right"><a href="../admin/mi_prof.php?aktion=add" alt="neuen Eintrag hinzuf�gen" title="neuen Eintrag hinzuf�gen"><img src="../admin/img/new_s.gif" border="0"></a></p>';}
?>
