<?php require_once('../config.inc'); seite(__FILE__); ?>

<?php

if ($_GET["show"])
{
    $feld=array($_GET["id"],$_GET["id1"],$_GET["id2"],$_GET["seite"]);
    foreach ($feld as $elem)
       if ($elem and $uebergeben) $uebergeben.='&'.$elem;
    if ($uebergeben) $uebergeben='?'.$uebergeben;
      include_once($_GET["show"].".php".$uebergeben);
}
else
{

echo "<br><center><table width=80% align=\"center\">";

//Zeit in Semester umwandeln
$sem=akt_semester();

$id=$_GET["id"];
$id=intval($id);

// wenn auf Lehrstuhlinhaber in Menuleiste geklickt (id wird nicht �bergeben)
if ($id=='') 
{
   $result=mysql_query("SELECT id FROM mi_prof WHERE funktion=5 AND (ende='' OR ende>='$sem') AND anfang<='$sem'");
   $zeile=mysql_num_rows($result);
   if ($zeile>0) $id=mysql_result($result,$zeile-1,"id");
   else 
   {
    $result=mysql_query("SELECT id FROM mi_prof WHERE funktion=1 AND (ende='' OR ende>='$sem') AND anfang<='$sem'");
    $zeile=mysql_num_rows($result);
    if ($zeile>0) $id=mysql_result($result,$zeile-1,"id");
    else $id="";
   }
}

$id=intval($id);

//Daten des Professor ausgeben 
if (is_int($id) and $id!='')
{
  $professor=mysql_query("SELECT * FROM mi_prof WHERE id=$id");
  if (mysql_num_rows($professor));
  {

//Datensatz des Lehrstuhlinhabers laden
    $array=mysql_fetch_array($professor);

//Namen als �berschrift/Bild ausgeben
    $titelimg= 'img/mi_prof_titel_'.$array["id"].'.png';
    if(is_readable($titelimg)){
      echo '<tr><td align="center" colspan=2><img src="'.$titelimg.'" border="0" align="center" title="'.$array["titel"].'&nbsp;'.$array["vname"].'&nbsp;'.$array["name"].'" alt="'.$array["titel"].'&nbsp;'.$array["vname"].'&nbsp;'.$array["name"].'"></td></tr>';}
    else {
      echo "<tr><th colspan=2 align=\"center\"><h1><br>".$array["titel"]."&nbsp;".$array["vname"]."&nbsp;".$array["name"]."</h1></th></tr>";}

//Photo des Lehrstuhlinhabers ausgeben
    if ($array["photo"])
     echo "<tr><td align=\"center\" colspan=2><img src=\"img/".$array["photo"]."\"></td></tr>";
    else echo "<tr><td colspan=2>&nbsp;</td></tr>";
 
//Link zum Lehrstuhlinhaber ausgeben, wenn Vertretung
    if ($array["funktion"]==5)
    {
     echo "<tr><td colspan=2 style=\"padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt\" align=\"left\">...in Vertretung";   
     $prof=mysql_query("SELECT id, name, vname, titel FROM mi_prof WHERE funktion=1 AND (ende='' OR ende>='$sem')");
     if (mysql_num_rows($prof))
     {
       $prof1=mysql_fetch_array($prof);
       echo " f&uuml;r Lehrstuhlinhaber <a href=\"prof.php?id=".$prof1["id"]."\">".$prof1["titel"]."&nbsp;".$prof1["vname"]."&nbsp;".$prof1["name"]."</a>";
     }
     echo "</td></tr>";
    }

//Link zur Vertretung, falls vorhanden
    if ($array["funktion"]==1)
    {
     $prof=mysql_query("SELECT id, name, vname, titel FROM mi_prof WHERE funktion=5 AND (ende='' OR ende>='$sem')");
     if (mysql_num_rows($prof))
     {
       $prof1=mysql_fetch_array($prof);
       echo "<tr><td colspan=2 style=\"padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt\" align=\"left\">...vertreten durch <a href=\"prof.php?id=".$prof1["id"]."\">".$prof1["titel"]."&nbsp;".$prof1["vname"]."&nbsp;".$prof1["name"]."</a><td></tr>";
     }
    }

//Kontakt (Anschrift, Tel., etc.) zum Lehrstuhlinhaber
    if ($array["ende"]=="" or $array["ende"]>=$sem)
    {
     echo "<tr><td class=\"grau\" colspan=2 align=\"left\"><b>&nbsp;Kontakt</b></td></tr>";
     echo "<tr><td align=\"center\" colspan=2 style=\"padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt\">
           <table bgcolor=\"#CCE7E7\" width=90% cellpadding=5><tr><td valign=\"top\" align=\"left\">Anschrift:</td>";
     echo "<td align=\"left\">".$array["titel"]."&nbsp;".$array["vname"]."&nbsp;".$array["name"]."<br>Technische Universit&auml;t Chemnitz<br>Fakult&auml;t f�r Informatik<br>Professur Medieninformatik<br>";
     if ($array["zimmer"]!="") echo "Zimmer ".$array["zimmer"]."<br>";
     echo "Stra�e der Nationen 62<br>09107 Chemnitz<br>Germany</td></tr>";
     if ($array["email"]) echo "<tr><td valign=\"top\" align=\"left\">Email:</td><td align=\"left\"><a href=\"mailto:".$array["email"]."\">".$array["email"]."</a></td></tr>";
     if ($array["telefon"]) echo "<tr><td valign=\"top\" align=\"left\">Telefon:</td><td align=\"left\">".$array["telefon"]."</td></tr>";
     if ($array["fax"]) echo "<tr><td valign=\"top\" align=\"left\">Fax:</td><td align=\"left\">".$array["fax"]."</td></tr>";
     if ($array["sprechstunde"]) echo "<tr><td valign=\"top\" align=\"left\">Sprechstunde:</td><td align=\"left\">".$array["sprechstunde"]."</td></tr>";
     echo "</table></td></tr>";
    }

//Lebenslauf des Lehrstuhlinhabers
    if ($array["lebenslauf"]!="")
    {
     echo "<tr><td class=\"grau\" colspan=2 align=\"left\"><b>&nbsp;Lebenslauf</b></td></tr>";
     $array["lebenslauf"]=str_replace("\n","<br>",$array["lebenslauf"]);
     echo "<tr><td colspan=2 style=\"padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt\" align=\"left\">".$array["lebenslauf"]."</td></tr>";
    }

//Ver�ffentlichungen des Lehrstuhlinhabers
    if ($array["publik_nr"]!="")
    {
     echo "<tr><td class=\"grau\" colspan=2 align=\"left\"><b>&nbsp;Ver&ouml;ffentlichungen</b></td></tr>";
     $pubnr=split("_",$array["publik_nr"]);
     for ($i=0;$i<count($pubnr);$i++)
     {
       if ($query) $query.=" OR ";
       $query.="id=".$pubnr[$i];
     }
     $publik=mysql_query("SELECT id, datum, name FROM mi_prof_publik WHERE ".$query." ORDER BY datum DESC LIMIT 0,5");
     if (mysql_num_rows($publik))
     {
      while ($pubarray=mysql_fetch_array($publik))
      echo "<tr><td width=23% valign=\"top\" style=\"padding-left:10pt;padding-right:0pt;padding-top:5pt\" align=\"left\">".date_conf($pubarray["datum"])."</td><td style=\"padding-left:0pt;padding-right:10pt;padding-top:5pt\" valign=\"top\" align=\"left\"><a href=\"prof.php?show=publik&id1=".$array["id"]."&id2=".$pubarray["id"]."\">".$pubarray["name"]."</a></td></tr>";
     }
     if (count($pubnr)>5) echo "<tr><td colspan=2 align=\"right\" style=\"padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt\"><a href=\"prof.php?show=publik&id1=".$array["id"]."\">mehr &gt;&gt;</a></td></tr>";
    }
  } 
}
// z.Z. kein Lehrstuhlinhaber
else
{
  echo "<tr bgcolor=\"#CCE7E7\"><td style=\"padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt\" align=\"left\">Zur Zeit gibt es keinen Lehrstuhlinhaber an der Professur Medieninformatik</td></tr>";
}

echo "<tr><td colspan=2></td></tr>
      <tr><td class=\"grau\" colspan=2 align=\"left\">&nbsp;<b>ehemalige Lehrstuhlinhaber&nbsp;&nbsp;<a href=\"prof.php?show=ehemalige\">&gt;&gt;</a></b></td></tr>";

echo "</table></center>";
}
?>
