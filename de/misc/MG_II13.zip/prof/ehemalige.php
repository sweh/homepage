<?php

echo "<br><center><table width=80% align=\"center\">";

$id=$_GET["id"];
$id=intval($id);

//Zeit in Semester umwandeln
$sem=akt_semester();

if ($id!='' and is_int($id))
{
 $professor=mysql_query("SELECT * FROM mi_prof WHERE id=$id");
 if (mysql_num_rows($professor));
  {

//Datensatz des Lehrstuhlinhabers laden
   $array=mysql_fetch_array($professor);

//Namen als �berschrift/Bild ausgeben
   $titelimg= 'img/mi_prof_titel_'.$array["id"].'.png';
   if(is_readable($titelimg)){
     echo '<tr><td align="center" colspan=2><img src="'.$titelimg.'" border="0" align="center" title="'.$array["titel"].'&nbsp;'.$array["vname"].'&nbsp;'.$array["name"].'" alt="'.$array["titel"].'&nbsp;'.$array["vname"].'&nbsp;'.$array["name"].'"></td></tr>';}
   else {
     echo "<tr><th colspan=2 align=\"center\"><h1><br>".$array["titel"]."&nbsp;".$array["vname"]."&nbsp;".$array["name"]."</h1></th></tr>";}
   echo "<tr height=10><td></td></tr>";

//Photo des Lehrstuhlinhabers ausgeben
   if ($array["photo"])
    echo "<tr><td align=\"center\" colspan=2><img src=\"img/".$array["photo"]."\"></td></tr>";
   else echo "<tr><td colspan=2>&nbsp;</td></tr>";
 
//Lebenslauf des Lehrstuhlinhabers
    if ($array["lebenslauf"]!="")
    {
     echo "<tr><td class=\"grau\" colspan=2 align=\"left\"><b>&nbsp;Lebenslauf</b></td></tr>";
     $array["lebenslauf"]=str_replace("\n","<br>",$array["lebenslauf"]);
     echo "<tr><td colspan=2 style=\"padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt\" align=\"left\">".$array["lebenslauf"]."</td></tr>";
    }

//Ver�ffentlichungen des Lehrstuhlinhabers
    if ($array["publik_nr"]!="")
    {
     echo "<tr><td class=\"grau\" colspan=2 align=\"left\"><b>&nbsp;Ver&ouml;ffentlichungen</b></td></tr>";
     $pubnr=split("_",$array["publik_nr"]);
     for ($i=0;$i<count($pubnr);$i++)
     {
       if ($query) $query.=" OR ";
       $query.="id=".$pubnr[$i];
     }
     $publik=mysql_query("SELECT id, datum, name FROM mi_prof_publik WHERE ".$query." ORDER BY datum DESC LIMIT 0,5");
     if (mysql_num_rows($publik))
     {
      while ($pubarray=mysql_fetch_array($publik))
      echo "<tr><td width=23% valign=\"top\" align=\"left\" style=\"padding-left:10pt;padding-right:0pt;padding-top:5pt\">".date_conf($pubarray["datum"])."</td><td style=\"padding-left:0pt;padding-right:10pt;padding-top:5pt\" valign=\"top\" align=\"left\"><a href=\"prof.php?show=publik&id1=".$array["id"]."&id2=".$pubarray["id"]."\">".$pubarray["name"]."</a></td></tr>";
     }
     if (count($pubnr)>5) echo "<tr><td colspan=2 align=\"right\" style=\"padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt\"><a href=\"prof.php?show=publik&id1=".$array["id"]."\">mehr &gt;&gt;</a></td></tr></table>";
    }
  } 
} 


//alle ehemaligen Lehrstuhlinhaber ausgeben
$prof=mysql_query("SELECT id, name, vname, titel, funktion, anfang, ende FROM mi_prof WHERE (funktion=1 OR funktion=5) AND (ende<'$sem' AND ende!='')");
if (mysql_num_rows($prof))
{
 echo '<table width=80% align="center">';
 if ($id) echo "<tr><td colspan=2 height=10></td></tr><tr><th colspan=2 align=\"left\"><b>&nbsp;ehemalige Lehrstuhlinhaber</b></th></tr>";
 else echo "<tr><td colspan=2 align=\"center\"><img src=\"img/mi_prof_old.png\"></td></tr><tr><td colspan=2 height=10></td></tr>";
 while ($allarray=mysql_fetch_array($prof))
 {
  $anfang=chunk_split($allarray["anfang"],5);
  switch ($anfang[4])
   {case "s": $anfang1="SS ".$anfang[0].$anfang[1].$anfang[2].$anfang[3];break;
    case "w": $anfang1="WS ".$anfang[0].$anfang[1].$anfang[2].$anfang[3];break;}
  $ende=chunk_split($allarray["ende"],5);
  switch ($ende[4])
   {case "s": $ende1="SS ".$ende[0].$ende[1].$ende[2].$ende[3];break;
    case "w": $ende1="WS ".$ende[0].$ende[1].$ende[2].$ende[3];break;}
 
  echo "<tr><td width=35% valign=\"top\" style=\"padding-left:10pt;padding-right:10pt;padding-top:5pt\" align=\"left\">".$anfang1." - ".$ende1."</td><td style=\"padding-left:0pt;padding-right:10pt;padding-top:5pt\" valign=\"top\" align=\"left\" width=65%>";
  if ($allarray["id"]!=$id) echo "<a href=\"prof.php?show=ehemalige&id=".$allarray["id"]."\">".$allarray["titel"]."&nbsp;".$allarray["vname"]."&nbsp;".$allarray["name"]."</a>";
  else echo $allarray["titel"]."&nbsp;".$allarray["vname"]."&nbsp;".$allarray["name"];
  if ($allarray["funktion"]==5) echo "&nbsp;(Vertretung)";
  echo "</td></tr>";
 } 
}

//Link zur�ck zum aktuellen Lehrstuhlinhaber
echo '<tr><td colspan=2 style="padding-left:10pt;padding-right:10pt;padding-top:15pt" align="left"><a href="prof.php">&lt;&lt; Zur&uuml;ck zum derzeitigen Lehrstuhlinhaber</a></td></tr>';

echo "</table></center>";

?>
