<?php
$profid=$_GET["id1"];
$profid=intval($profid);
$pubid=$_GET["id2"];
$pubid=intval($pubid);

$seite=$_GET["seite"]; 
$seite=intval($seite); 
if ($seite==0) $seite=1; 
$offset=($seite-1)*10; 

//aktuelles Semester bestimmen
$sem=akt_semester();

echo "<br><center><table cellspacing=0 width=80% align=\"center\">";

//ausgew�hlte Publikation ausgeben
if ($pubid!="" and is_int($pubid))
{
 $publikation=mysql_query("SELECT id, datum, name, beschreibung, anhang, link FROM mi_prof_publik WHERE  id=$pubid");
 if (mysql_num_rows($publikation))
 {
  $pubarray=mysql_fetch_array($publikation);
  echo '<tr><td colspan=3 align="left">';
  $titelimg="../forschung/img/mi_publik_titel_".$pubarray["id"].".png";
  if (is_readable($titelimg)) 
      echo '<img src="'.$titelimg.'" border="0" align="center" title="'.$pubarray["name"].'" alt="'.$pubarray["name"].'">';
  else echo '<h1 align="center">'.$pubarray["name"].'</h1>';
  echo '</td></tr><tr height=10><td colspan=3></td></tr>';

  //Datum ausgeben
  if ($pubarray["datum"])
   echo "<tr><td class=\"grau\" colspan=3 align=\"left\"><b>&nbsp;Datum der Ver&ouml;ffentlichung:</br></td></tr>
        <tr><td style=\"padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt\" colspan=3 align=\"left\">".date_conf($pubarray["datum"])."</td></tr>";

  //alle an der Publikation Beteiligten aus Datenbank suchen
  if ($profid!="" and is_int($profid))
  {
   $prof=mysql_query("SELECT id, name, vname, titel, ende, publik_nr FROM mi_prof WHERE publik_nr LIKE '%".$pubid."' OR publik_nr LIKE '%_".$pubid."_%' OR publik_nr LIKE '".$pubid."_%'");
   if (mysql_num_rows($prof))
    while ($array=mysql_fetch_array($prof))
    {
     if ($beteiligte) $beteiligte.=", ";
     $beteiligte.=$array["titel"]."&nbsp;".$array["vname"]."&nbsp;".$array["name"];
    }
  }

  //Beteiligte ausgeben
  if ($beteiligte)
   echo "<tr><td class=\"grau\" colspan=3 align=\"left\"><b>&nbsp;Beteiligte:</br></td></tr>
        <tr><td style=\"padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt\" colspan=3 align=\"left\">".$beteiligte."</td></tr>";

  //Beschreibung ausgeben
  if ($pubarray["beschreibung"])
   echo "<tr><td class=\"grau\" colspan=3 align=\"left\"><b>&nbsp;Beschreibung:</br></td></tr>
        <tr><td style=\"padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt\" colspan=3 align=\"left\">".$pubarray["beschreibung"]."</td></tr>";

  //Download-Link ausgeben 
  if ($pubarray["anhang"] and is_readable("../forschung/doc/".$pubarray["anhang"]))  
    echo "<tr><td style=\"padding-left:10pt;padding-right:10pt;padding-bottom:10pt\" colspan=3 align=\"left\">Weitere Infos als <a href=\"../forschung/doc/".$pubarray["anhang"]."\">Download</a> (".datei_typ($pubarray["anhang"]).", ca. ".(round(filesize("../forschung/doc/".$pubarray["anhang"])/1000))."kB)</td></tr>";  

  //externen Link zur Publikation ausgeben 
  if ($pubarray["link"])  
    echo "<tr><td style=\"padding-left:10pt;padding-right:10pt;padding-bottom:10pt\" colspan=3 align=\"left\">Hier ein externer <a href=\"".$pubarray["link"]."\" target=\"_blank\">Link</a> zur Publikation</td></tr>";  
 }
}

//alle Publikationen ausgeben
if ($profid!="" and is_int($profid))
{
 $prof=mysql_query("SELECT id, name, vname, titel, ende, publik_nr FROM mi_prof WHERE id=$profid");
 if (mysql_num_rows($prof))
 {
     $profarray=mysql_fetch_array($prof);
     $name=$profarray["titel"].' '.$profarray["vname"].' '.$profarray["name"];
     $publik_nr=$profarray["publik_nr"];
     $ende=$profarray["ende"];

     if ($pubid=='') echo '<tr><td colspan=3 align="center"><img src="img/mi_prof_titel_'.$profid.'.png"></td></tr>';
     echo "<tr><td colspan=3><br><br></td></tr>
           <tr><th colspan=3 align=\"left\"><b>&nbsp;Ver&ouml;ffentlichungen von ".$name."</b></th></tr>";

     if ($publik_nr!="")
     {
      $pubnr=split("_",$publik_nr);
      for ($i=0;$i<count($pubnr);$i++)
      {
        if ($query) $query.=" OR ";
        $query.="id=".$pubnr[$i];
      }

      //Anzahl Publikationen ermitteln f�r Seiten-Navigation 
      $pubs=mysql_query("SELECT id FROM mi_prof_publik WHERE ".$query); 
      $anzahl=mysql_num_rows($pubs); 
      $seitenanzahl=ceil($anzahl/10); 

      $publik=mysql_query("SELECT id, datum, name FROM mi_prof_publik WHERE ".$query." ORDER BY datum DESC LIMIT $offset,10");
      if (mysql_num_rows($publik))
      {
       while ($pubarray=mysql_fetch_array($publik))
       {
        echo "<tr><td width=23% valign=\"top\" style=\"padding-left:10pt;padding-right:0pt;padding-top:5pt\" align=\"left\">".date_conf($pubarray["datum"])."</td>
             <td colspan=2 style=\"padding-left:0pt;padding-right:10pt;padding-top:5pt\" valign=\"top\" align=\"left\">";
        if ($pubarray["id"]!=$pubid) echo "<a href=\"prof.php?show=publik&id1=".$profid."&id2=".$pubarray["id"]."&seite=".$seite."\">".$pubarray["name"]."</a></td></tr>";
        else echo $pubarray["name"]."</td></tr>";
       }

       //Seiten-Navigation 
       if ($seitenanzahl>1) 
       { 
        echo "<tr height=20><td colspan=3></td></tr><tr><td class=\"grau\" align=\"left\" style=\"padding-left:10pt\">"; 
        if ($seite>1) echo "<a href=\"prof.php?show=publik&seite=".($seite-1)."&id1=".$profid."\">&lt;&lt; aktuellere</a>";
        echo "</td><td align=\"center\" class=\"grau\">"; 
        for ($i=1;$i<=$seitenanzahl;$i++) 
          if ($seite==$i) echo "[".$i."]&nbsp;"; 
          else echo "<a href=\"prof.php?show=publik&seite=".$i."&id1=".$profid."\">[".$i."]</a>&nbsp;"; 
        echo "</td><td width=20% class=\"grau\" align=\"right\" style=\"padding-right:10pt\" valign=\"top\">"; 
        if ($seite<$seitenanzahl) echo "<a href=\"prof.php?show=publik&seite=".($seite+1)."&id1=".$profid."\"> &auml;ltere &gt;&gt;</a>"; 
        echo "</td></tr>"; 
       } 
      }
     }
    }

//Link zur�ck zum dazugeh�rigen Professor ausgeben
    echo "<tr><td colspan=3 align=\"left\" style=\"padding-left:10pt;padding-right:10pt\" valign=\"top\"><br><br>";
    if ($ende=='' or $ende>=$sem) echo "<a href=\"prof.php?id=";
    else echo "<a href=\"prof.php?show=ehemalige&id=";
    echo $profid."\">&lt;&lt; zur�ck zu ".$name."</td></tr>";
}

echo "</table></center>";
?>
