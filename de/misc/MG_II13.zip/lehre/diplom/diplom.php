<?php require_once('../../config.inc'); seite(__FILE__); 
if ($_GET['show']) include($_GET['show'].'.php');
else{
?> 
<center>
<img src = "img/mi_diplom.png" alt="Diplom- und Studienarbeiten">
</center>
<br><br>
<table width=80% align="center">
<tr><td colspan="3" style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">
Die Themen f�r Studien- und Diplomarbeit sind theorieorientiert und auch anwendungsbezogen. Die einzelnen Themen werden mit interessierten Studentinnen und Studenten im Hinblick auf ihre Interessen und Vorkenntnisse ausgew�hlt und abgestimmt.
<br><br>
Interessierte Student(inn)en k�nnen sich unverbindlich melden, wenn sie Interesse haben, an der Professur f�r Medieninformatik eine Studien- oder Diplomarbeit anzufertigen. 
<br><br>
</td></tr>
<tr><th colspan="3">Studienarbeit</th></tr>
<tr><td class="grau" align="center">
    <a href="diplom.php?show=studienarbeit&s=0">ausgeschrieben</a></td>
    <td class="grau" align="center">
    <a href="diplom.php?show=studienarbeit&s=1">laufend</a></td>
    <td class="grau" align="center">
    <a href="diplom.php?show=studienarbeit&s=2">abgeschlossen</a></td>
<tr><td colspan="3" style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">
Im Hauptstudium ist in der Medieninformatik das Schreiben einer Studienarbeit vorgesehen. Die Studienarbeit kann bereits als Vorbereitung auf die Diplomarbeit dienen, hat aber bei weitem nicht den Umfang.
</td></tr>

<tr><th colspan="3">Diplomarbeit</td></tr>
<tr><td class="grau" align="center">
    <a href="diplom.php?show=diplomarbeit&s=0">ausgeschrieben</a></td>
    <td class="grau" align="center">
    <a href="diplom.php?show=diplomarbeit&s=1">laufend</a></td>    
    <td class="grau" align="center">
    <a href="diplom.php?show=diplomarbeit&s=2">abgeschlossen</a></td>
<tr><td colspan="3">

<tr><td colspan="3" style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">
Am Ende des Studium steht die Diplomarbeit. Hierbei ist es Sinn und Zweck, nachzuweisen, dass man nicht nur gelerntes Wissen anwenden, sondern auch wissenschaftlich arbeiten kann. 
</td></tr>
<?php
if ($_SESSION["login"] == "true")
{
?>
<tr>
	<td align="right" colspan="3">
					<form method="post" action="../../admin/mi_lehre_arbeiten.php">
						<input type="hidden" name="show" value="edit">
						<input type="image" src="../../admin/img/new_s.gif" title="Neue Studien- / Diplomarbeit hinzuf�gen">
					</form>
	</td>
</tr>
<?php
}
?>
</table> 
<?php } ?>   
