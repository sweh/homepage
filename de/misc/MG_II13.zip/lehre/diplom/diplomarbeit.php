<?php require_once('../../config.inc'); seite(__FILE__); ?>  
<center>
<img src="img/mi_diplomarbeiten.png" alt="Diplomarbeitsthemen">
</center>
<br><br>
<table width=80% align="center">
<?php
$status = $_GET["s"];

$string = "SELECT id, thema, pid, status, link, inhalt, anforderungen,datei 
           FROM mi_lehre_arbeiten 
           WHERE typ=2 AND status=".$status;
$datensatz = mysql_query($string);
$anzahl = mysql_num_rows($datensatz);
if ($anzahl == 0)
	{
	switch($status)
		{
		case 0: echo "<b>Zur Zeit werden keine Diplomarbeitsthemen angeboten.</b>";
			break;
		case 1: echo "<b>Zur Zeit befinden sich keine Diplomarbeitsthemen in Bearbeitung.</b>";
			break;
		case 2: echo "<b>Es gibt noch keine Abgeschlossenen Diplomarbeiten.</b>";
			break;
		}
	}
else {
while(list($id,$thema,$pid,$status,$link,$inhalt,$anforderungen,$datei) = mysql_fetch_row($datensatz))
	{
       	?>
        <tr><td class="liniehell"><?php 
                  if ($_SESSION["login"] == "true") 
                      echo "<a href=\"../../admin/mi_lehre_arbeiten.php?show=edit&id=$id\">
<img src=\"../../admin/img/edit_s.gif\" alt=\"Studienarbeit bearbeiten\" title=\"Studienarbeit l�schen\" border=\"0\"></a>&nbsp;&nbsp;<a href=\"../../admin/mi_lehre_arbeiten.php?show=delete&id=$id\"><img src=\"../../admin/img/del_s.gif\" alt=\"Studienarbeit l�schen\" title=\"Studienarbeit l�schen\" border=\"0\"></a>";

										echo $thema; 
                                        echo '   [';
                                        switch($status)
						{
						case 0: /*ausgeschrieben*/
							echo ' <i>ausgeschrieben</i> ]';
							break;
						case 1: /*in bearbeitung*/
							echo ' <i>in Bearbeitung</i> ]';
							break;
						case 2: /*fertig*/
							echo ' <i>abgeschlossen</i> ]';
							break; 
						}
	                                 
        ?></td></tr>		
 	<tr><td><br></td></tr>
 	<tr><td class="grau"><b>Ansprechpartner:</b></td></tr>
 	<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">
        <?php
      	$p_string = "SELECT name, vname, titel FROM mi_prof WHERE id =".$pid;
  	$p_datensatz = mysql_query($p_string);
     	list($name,$vname,$titel) = mysql_fetch_row($p_datensatz);
      	echo $titel." ".$vname." ".$name;				
 	?>
     	</td>
 	</tr>	
 	<tr><td class="grau"><b>Inhalt:</b></td></tr>
 	<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">
       	<?php echo $inhalt;
     	if($link)
		{
		?>
                <p align="right">
	  	<a href="<?php echo $link; ?>">zur Diplomarbeit >></a></p>
		<?php
		}	
     	?>
     	</td>
       	</tr>
	<?php if ($datei){ ?>
	<tr><td class="grau"><b>Download</b></td></tr>
	<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">	Die Diplomarbeit steht zum 
	<a href="<?php echo $datei ?>">Download</a> zur Verf�gung.
	<?php
	}
	if ($status != 2){
	?>
 	<tr><td class="grau"><b>Anforderungen:</b></td></tr>
 	<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">
 	<?php echo $anforderungen; ?>
     	</td>
 	</tr>	
 	<?php
}}}
	?>
</table>
<br>
<a href="diplom.php"><< zur�ck zur �bersicht</a>
<br><br>
