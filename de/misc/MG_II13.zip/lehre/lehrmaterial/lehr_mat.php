<?php require_once('../../config.inc'); seite(__FILE__);    

if($_GET['show']) include($_GET['show'].'.php');
else{

     $vString = "SELECT * FROM mi_lehre_veranstaltung";  
     $vzString = "SELECT * FROM mi_lehre_veranstaltung_zeit";  
     $vErgebnis = mysql_query($vString);  
     $vzErgebnis = mysql_query($vzString);  
?>  
<p><center> 
<img src="img/mi_skripte.png" alt="skripte"> </center><br><br>
<table width=80% align="center"> 
  <tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt"> 
       <?php /* Hier ist Platz f�r Text */ ?>   
            
   </td></tr>
   <tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">       
          <table width=90%> 
            <tr><th>Medieninformatik - Grundstudium</th></tr> 
          </table> 
          <table width=90%> 
            <tr class="grau"><td><b>Fach</td> 
                 <td width="35"><b>1.</b></td> 
                 <td width="35"><b>2.</b></td>  
                 <td width="35"><b>3.</b></td> 
                 <td width="35"><b>4.</b></td> 
            </tr> 
            <?php include("mat_grund.php"); ?> 
          </table>        
  </td></tr> 
  <tr><td><br></td></tr> 
  <tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">  
          <table width=90%> 
            <tr><th>Medieninformatik - Hauptstudium</th></tr> 
          </table> 
          <table width=90%> 
             <tr class="grau"><td><b>Fach</td> 
                 <td width="35"><b>5.</b></td> 
                 <td width="35"><b>6.</b></td> 
                 <td width="35"><b>7.</b></td> 
                 <td width="35"><b>8.</b></td> 
                 <td width="35"><b>9.</b></td> 
            </tr> 
            <?php include("mat_haupt.php"); ?> 
         </table> 
  </td></tr> 
</table>         
</td></tr> 
</table> 
<?php } ?>
