<?php require_once('../../config.inc'); seite(__FILE__); ?>    

<?php 
/*vnr ist die Veranstaltungsnummer*/ 
$einheit = $_GET["einheit"]; 

/*Vorlesung suchen*/ 
$vString = "SELECT id, vname FROM mi_lehre_veranstaltung WHERE einheit =".$einheit.' AND vart = 1'; 
$vdatensatz = mysql_query($vString); 
list($id,$name) = mysql_fetch_row($vdatensatz); 

$vzString = "SELECT * FROM mi_lehre_veranstaltung_zeit"; 
$vzErgebnis = mysql_query($vzString); 

/*nprofist die ID des Profs */ 
$pstring = "SELECT vperson, vart from mi_lehre_veranstaltung_zeit WHERE einheit ='".$einheit."'"; 
$pdatensatz = mysql_query($pstring);  
while(list($prof,$vart) = mysql_fetch_row($pdatensatz))
    { 
     if ($vart == 1) /*Vorlesung*/
      {$nprof=$prof;}
    } 
$bild = 'mi_skripte_'.$id;
?> 
<br><center> 
<img src="img/<?php echo $bild; ?>.png" alt="Skripte <?php echo $vname; ?>">
<br><br> </center>
<table width=80% align="center"> 

<tr><td class="liniehell">      
    <b><?php echo $vname; ?></b> 
    </td> 
</tr> 
<tr><td> 
    <br> 
    </td> 
</tr> 
<tr><td class="grau"> 
    <b>Leitender:</b> 
    </td> 
</tr> 
<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:20pt"> 
    <?php 
      $string = "SELECT titel,vname,name from mi_prof WHERE id=".$nprof; 
      $datensatz = mysql_query($string); 
      while(list($titel,$vname,$name) = mysql_fetch_row($datensatz)) 
      echo $titel, " ",$vname," ",$name; 
    ?> 
    </td> 
</tr>

<?php
/*Gibt es einen Datensatz?*/ 
 $string = "SELECT sem FROM mi_lehre_material WHERE einheit=".$einheit." AND art=0";
 $datensatz = mysql_query($string);
 while(list($sem) = mysql_fetch_row($datensatz))
   {
?>
 
<tr><td class="grau">
    <b>Materialien - Vorlesungsskript</b>
    </td>
</tr>
<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:20pt">
    <table width="100%">
      <tr bgcolor="#CCE7E7">
      <td width=70%>Thema</td>
      <td width=15%>download</td>
      <td width=15%>Stand</td></tr>

    <?php
     $string = "SELECT beschreibung,link,zeit,sem FROM mi_lehre_material WHERE einheit='".$einheit."' AND art=0";
     $datensatz = mysql_query($string);
     while(list($beschreibung,$link,$zeit,$sem) = mysql_fetch_row($datensatz))
          {        
           echo "<tr><td>".$beschreibung."</td>";
           $Pos = strpos($link,".");
           $Len = strlen($link);
           $Mat = substr($link, $Pos+1, $Len - $Pos);
           echo "<td><a href=".$link.">".$Mat."</a></td>";
           $zeit = date("d.m.Y",$zeit);
           echo "<td>".$zeit."</td></tr>";           
          }         
    ?>
    </table>
    </td>
</tr>
<?php } ?>

<?php
/*Gibt es einen Datensatz?*/ 
 $string = "SELECT sem FROM mi_lehre_material WHERE einheit=".$einheit." AND art=1";
 $datensatz = mysql_query($string);
 while(list($sem) = mysql_fetch_row($datensatz))
   {
?>

<tr><td class="grau">
    <b>Materialien - �bungsunterlagen</b>
    </td>
</tr>
<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:20pt">
  <table width="100%">
      <tr bgcolor="#CCE7E7">
      <td width=70%>Thema</td>
      <td width=15%>download</td>
      <td width=15%>Stand</td></tr>
     <?php
     $string = "SELECT beschreibung,link,zeit,sem FROM mi_lehre_material WHERE einheit='".$einheit."' AND art=1";
     $datensatz = mysql_query($string);
     while(list($beschreibung,$link,$zeit,$sem) = mysql_fetch_row($datensatz))
          {        
           echo "<tr><td>".$beschreibung."</td>";
           $Pos = strpos($link,".");
           $Len = strlen($link);
           $Mat = substr($link, $Pos+1, $Len - $Pos);
           echo "<td><a href=".$link.">".$Mat."</a></td>";
	   $zeit = date("d.m.Y", $zeit);
           echo "<td>".$zeit."</td></tr>";           
          }         
    ?>
    </table>
    </td>
</tr> 
<?php } ?> 


<?php
/*Gibt es einen Datensatz?*/ 
 $string = "SELECT sem FROM mi_lehre_material WHERE einheit=".$einheit." AND art=2";
 $datensatz = mysql_query($string);
 while(list($sem) = mysql_fetch_row($datensatz))
   {
?>
  
<tr><td class="grau">
    <b>Sonstige Materialien</b>
    </td>
</tr>
<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:20pt">
  <table width="100%">
      <tr bgcolor="#CCE7E7">
      <td width=70%>Thema</td>
      <td width=15%>download</td>
      <td width=15%>Stand</td></tr>

    <?php
     $string = "SELECT beschreibung,link,zeit,sem FROM mi_lehre_material WHERE einheit=".$einheit." AND art=2";
     $datensatz = mysql_query($string);
     while(list($beschreibung,$link,$zeit,$sem) = mysql_fetch_row($datensatz))
          {        
           echo "<tr><td>".$beschreibung."</td>";
           $Pos = strpos($link,".");
           $Len = strlen($link);
           $Mat = substr($link, $Pos+1, $Len - $Pos);
           echo "<td><a href=".$link.">".$Mat."</a></td>";
           $zeit = date("d.m.Y", $zeit);
           echo "<td>".$zeit."</td></tr>";           
          }         
    ?>
    </table>
    </td>
</tr>    
<?php } ?> 
</table> 
<br>
<a href="lehr_mat.php"><< zur�ck zur �bersicht</a>
<br><br>
