<?php  
     $anzahl = mysql_num_rows($vErgebnis);  

     for($n = 0; $n < $anzahl;$n++)  
        {  
         $vsemester = mysql_result($vErgebnis, $n, "vsem");  
         if($vsemester > 4) 
         { 
         $kontart = mysql_result($vErgebnis, $n, "vart");  
         IF ($kontart == 1)  /*es habdelt sich um eine Vorlesung*/  
           {  
            $name = mysql_result($vErgebnis,$n,"vname");  
            $einheit = mysql_result($vErgebnis, $n, "einheit");  
           
            /* anzahl der veranstaltungs sws auf 0 stetzen*/  
            $anzahl_v = 0;   
            $anzahl_u = 0;   
            $anzahl_p = 0; 

            $vorlesung = 0; 
            $uebung = 0; 
            $praktika = 0; 
  
            $string = "SELECT vart,vnr,vdauer,vwoche,einheit from mi_lehre_veranstaltung_zeit WHERE einheit = ".$einheit;  
            $datensatz = mysql_query($string);  
            while(list($vart,$vnr,$vdauer,$vwoche,$veinheit) = mysql_fetch_row($datensatz))  
                 {  
                  $art = $vart;   
                  $nr = $vnr;    
                  $dauer = $vdauer;   
                  $woche = $vwoche;  
                  $nummer = $veinheit;
              
                  if ($art == 1)   /* Vorlesung*/  
                     {   
                     if (($vorlesung == 0) or ($vorlesung == $nr)) 
                     /*der erste eintrag oder die gleiche veranstaltung*/ 
                        { 
                         $vorlesung = $nr; 
                         $sws = $dauer / 45;  
                         if ($woche != 0)  /*nicht jede woche*/  
                            {$sws = $sws / 2;}  
                         $anzahl_v = $anzahl_v + $sws;  
                         $einheit = $nummer;  
                        }
                     }  
               
                  elseif ($art == 2)  /*�bung*/  
                    {   
                    if (($uebung == 0) or ($uebung == $nr)) 
                    /*der erste eintrag oder die gleiche veranstaltung*/ 
                       { 
                        $uebung = $nr; 
                        $sws = $dauer / 45;  
                        if ($woche != 0)  /*nicht jede woche*/  
                           {$sws = $sws / 2;}  
                        $anzahl_u = $anzahl_u + $sws;  
                       }
                    }  

                  elseif ($art == 3) /*Praktika*/  
                    {   
                     if (($praktika == 0) or ($praktika == $nr)) 
                     /*der erste eintrag oder die gleiche veranstaltung*/ 
                        { 
                         $praktika = $nr; 
                         $sws = $dauer / 45;  
                         if ($woche != 0)  /*nicht jede woche*/  
                            {$sws = $sws / 2;}  
                         $anzahl_p = $anzahl_p + $sws; 
                        } 
                   }   
                 } 
              $abfrage = "SELECT count(*) from mi_lehre_material WHERE einheit='".$einheit."'";
              $mat_datensatz = mysql_query($abfrage);
              list($result) = mysql_fetch_row($mat_datensatz);
              if($result > 0)
                {   
                  ?>  
                  <tr><td><a href="lehr_mat.php?show=material&einheit=<?php echo $einheit ?>"><?php echo $name; ?></a></td> 
                  <?php  
              for($i = 5; $i < 10; $i++)  
                 {  
                  if($vsemester == $i)  
                    {  
                     echo "<td>",$anzahl_v,"/",$anzahl_u,"/",$anzahl_p,"</td>";  
                    }  
                  else  
                    {  
                     echo "<td></td>";  
                    }   
                 }
                }  
               ?>  
              </tr>      
          <?php  
          } 
         }  
        }  
        ?>           
