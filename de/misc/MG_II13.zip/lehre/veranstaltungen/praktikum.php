<?php require_once('../../config.inc'); seite(__FILE__); ?>   

<body bgcolor="#FFFFFF"> 
<?php
/*id ist die id aus mi_lehre_veranstaltung*/
$id = $_GET["id"];
$link_nr = $_GET["nr"];
$link_id = $id.'&vorlesung='.$link_nr;

/*daten ermitteln*/
$string = "SELECT einheit,vart,vname,vinhalt,vabschluss,vliteratur,vhinweise FROM mi_lehre_veranstaltung WHERE id=".$id;
$datensatz = mysql_query($string);
list($einheit,$vart, $vname, $inhalt,$abschluss,$literatur,$hinweise) = mysql_fetch_row($datensatz); 

$string = "SELECT id FROM mi_lehre_veranstaltung WHERE einheit=".$einheit." ORDER BY vart";
$daten = mysql_query($string);
list($bild_id) = mysql_fetch_row($daten);

/*Person ermittels*/
$string = "SELECT vperson FROM mi_lehre_veranstaltung_zeit WHERE einheit=".$einheit." AND vart = ".$vart;
$daten_prof = mysql_query($string);	
$anzahl = mysql_num_rows($daten_prof);

if($anzahl != 0) list($person) = mysql_fetch_row($daten_prof);   
else $person = 'noch nicht bekannt'; 

$bild = 'mi_lehre_'.$bild_id;
?>
<br><center> 
<img src="img/<?php echo $bild; ?>.png" alt="Praktikum/Seminar <?php echo $vname; ?>"> 
</center><br><br>
<table width=80% align="center"> 
<tr><td class="liniehell">     
    <b><?php 
	if ($vart == 3) echo 'Praktikum '. $vname;
	else echo 'Seminar '.$vname; 
       ?></b>
    </td>
</tr>
<tr><td>
    <br>
    </td>
</tr> 

<tr><td class="grau">
    <b>Betreuer:</b>
    </td>
</tr>
<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt"> 
    <?php
          if ($person != 'noch nicht bekannt') 
     		{ 
         	$string = "SELECT titel,vname,name FROM mi_prof WHERE id=".$person;   
         	$datensatz = mysql_query($string);  
         	list($titel,$vname,$name) = mysql_fetch_row($datensatz);  
         	echo $titel." ".$vname." ".$name; 
         	} 
    	  else echo $person;  
    ?>
    </td>
</tr> 
<tr><td class="grau">
    <b>Inhalt:</b>
    </td>
</tr>
<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt"> 
    <?php
      echo $inhalt; 
    php?>   
    </td>
</tr>
<?php
$string = "SELECT id,pkomplex,pthema 
           FROM mi_lehre_veranstaltung_praktika 
           WHERE einheit=".$einheit."
           ORDER BY pkomplex";
$datensatz = mysql_query($string);
$vergl_komplex = vergleich;
if (mysql_num_rows($datensatz)){
?>
<tr><td class="grau">
    <b>
<?php if ($vart == 3) echo 'Praktikumsthemen:';
      else echo 'Seminarthemen:';	
?>
   </b>
    </td>
</tr>
<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt"> 
    <?php
	echo '<menu>';
      while(list($pid,$komplex,$thema) = mysql_fetch_row($datensatz))
           {        
            if($vergl_komplex != $komplex)
              { 
               ?>
               <b>
               <?php echo $komplex; ?>
               </b><p><i><li>
               <a href="p_thema.php?id=<?php echo $pid; ?>&nr=<?php echo $link_id; ?>">
               <?php echo $thema; ?></a>
               </li></i><p>
               <?php
               $vergl_komplex = $komplex;
              } 
           elseif($vergl_komplex == $komplex)
              { 
               ?><i><li>
               <a href="p_thema.php?id=<?php echo $pid; ?>&nr=<?php echo $link_id; ?>">
               <?php echo $thema; ?></a>
               </li></i><p>
               <?php
              } 
           }
    ?>   
    </menu>
    </td>
</tr>
<?php } if($literatur){ ?>
<tr><td class="grau">
    <b>Literaturempfehlung:</b>
    </td>
</tr>
<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt"> 
    <?php
      echo $literatur; 
    php?>   
    </td>
</tr>
<?php
}
if ($hinweise){
?>
<tr><td class="grau">
    <b>Hinweise:</b>
    </td>
</tr>
<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt"> 
    <?php
      echo $hinweise; 
    ?>   
    </td>
</tr>
<?php } ?>
</table> 
<br>
<?php if ($link_nr){?>
<a href="veranst_allg.php?show=vorlesung&vnr=<?php echo $link_nr; ?>"><< zur�ck zur Vorlesung</a>
<?php } else {?>
<a href="veranst_allg.php"><< zur�ck zur �bersicht</a><?php } ?>
<br><br>
