<?php require_once('../../config.inc'); seite(__FILE__); ?>    

<?php 
/*id ist die id aus mi_lehre_veranstaltung_praktika*/ 
$id = $_GET["id"]; 
$link_id = $_GET["nr"];
$vorlesung_id = $_GET["vorlesung"];

/*Daten ermitteln*/
$string = "SELECT einheit,pkomplex,pthema,pinhalt,pliteratur,phinweise,pperson 
	   FROM mi_lehre_veranstaltung_praktika 
           WHERE id=".$id;
$datensatz = mysql_query($string);
list($einheit,$komplex,$thema,$inhalt,$literatur,$hinweise,$person) = mysql_fetch_row($datensatz);

/*Person ermitteln*/
$string = "SELECT name,vname,titel FROM mi_prof WHERE id=".$person;
$datensatz = mysql_query($string);
list($name,$vname,$titel) = mysql_fetch_row($datensatz);

$string= "SELECT id, vname from mi_lehre_veranstaltung WHERE einheit=".$einheit." ORDER BY vart";
$datensatz = mysql_query($string);
list($bild_id, $bezeichnung) = mysql_fetch_row($datensatz);

$bild = 'mi_lehre_'.$bild_id;
?>
<br><center> 
<img src="img/<?php echo $bild; ?>.png" alt="Vorlesung <?php echo $bezeichnung; ?>">
</center><br><br> 
<table width=80% align="center"> 
<tr><td class="liniehell"> 
    <b> <?php echo $komplex; ?> </b> 
    </td> 
</tr> 
<tr><td><br></td></tr> 

<tr><td class="grau"> 
    <b>Thema:</b> 
    </td> 
</tr> 
<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">  
    <b><?php echo $thema; ?></b> 
    </td> 
</tr> 
<tr><td class="grau"> 
    <b>Betreuer:</b> 
    </td> 
</tr> 
<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">  
    <?php 
         echo $titel." ".$vname." ".$name;  
    ?> 
    </td> 
</tr>
<?php if($inhalt) { ?> 
<tr><td class="grau"> 
    <b>Inhalt:</b> 
    </td> 
</tr> 
<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">  
    <?php 
      echo $inhalt;  
    ?>    
     </td> 
</tr> 
<?php } if($literatur){ ?>
<tr><td class="grau"> 
    <b>Literaturempfehlung:</b> 
    </td> 
</tr> 
<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">  
    <?php 
      echo $literatur;  
    ?>    
    </td> 
</tr> 
<?php
}
if ($hinweise){
?>
<tr><td class="grau"> 
    <b>Hinweise:</b> 
    </td> 
</tr> 
<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">  
    <?php 
      echo $hinweise;  
    php?>    
    </td> 
</tr> 
<?php } ?>
</table> 
<br>
<a href="praktikum.php?id=<?php echo $link_id.'&nr='.$vorlesung_id; ?>"><< zur�ck zum Praktikum</a>
<br><br>
