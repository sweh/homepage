<?php
$datensatz_abfrage = mysql_query($string_abfrage);
while(list($vsemester, $kontart, $name, $einheit) = mysql_fetch_row($datensatz_abfrage))
	{		
	 /* anzahl der veranstaltungs sws auf 0 stetzen*/
         $anzahl_v = 0;
         $anzahl_u = 0;
         $anzahl_p = 0;

         $vorlesung = 0;
         $uebung = 0;
         $praktika = 0;

         $string = "SELECT vnr, vart, vdauer,vwoche 
		    FROM mi_lehre_veranstaltung_zeit 
		    WHERE einheit = ".$einheit." 
		    ORDER BY vart, vnr";
         $datensatz = mysql_query($string);
               
	 while(list($vnr,$vart,$vdauer,$vwoche) = mysql_fetch_row($datensatz))
              {	
	       Switch($vart)
		{
		case 1:	/*Vorlesung*/
			if (($vorlesung == 0) OR ($vorlesung == $vnr))
				{
				$rueckgabe = sws_berechnen($vart,$vnr,$vdauer,$vwoche,$vorlesung);
				$anzahl_v = $anzahl_v + $rueckgabe;
				$vorlesungsnummer = $vnr;
				$vorlesung = $vnr;
				}
			break;

		case 2: /*�bung*/	
			if (($uebung == 0) OR ($uebung == $vnr))
				{
				$rueckgabe = sws_berechnen($vart,$vnr,$vdauer,$vwoche,$uebung);
				$anzahl_u = $rueckgabe;
				$uebung = $vnr;
				}
			break;
	
		case 3:	/*Praktikum*/
			if (($praktika == 0) OR ($praktika == $vnr))
				{
				$rueckgabe = sws_berechnen($vart,$vnr,$vdauer,$vwoche,$praktika);
				$anzahl_p = $anzahl_p + $rueckgabe;	
				$praktika = $vnr;	
				}	
			break;
		}		
	      }
?>
                    <tr><td><?php if ($_SESSION["login"] == "true") echo "<a href=\"../../admin/lehrveranstaltung.php?einheit=$einheit\"><img src=\"../../admin/img/edit_s.gif\" alt=\"Vorlesung bearbeiten\" alt=\"Vorlesung bearbeiten\" border=\"0\"></a>&nbsp;<a href=\"../../admin/lehrveranstaltung.php?einheit=$einheit&weiter=loeschen&loeschen=vorlesung\"><img src=\"../../admin/img/del_s.gif\" alt=\"Vorlesung l�schen\" title=\"Vorlesung l�schen\" border=\"0\"></a>&nbsp;"; ?>
<?php
if (($anzahl_v != 0) OR ($anzahl_u != 0) OR ($anzahl_p != 0))
{
?>
<a href="veranst_allg.php?show=vorlesung&vnr=<?php echo $vorlesungsnummer ?>"><?php echo $name; ?></a></td>
                    <?php
                    for($i = $beginn; $i < $ende; $i++)
                       {
                       if($vsemester == $i)
                         {
                          echo "<td>",$anzahl_v,"/",$anzahl_u,"/",$anzahl_p,"</td>";
                         }
                       else
                         {
                          echo "<td></td>";
                         }
                       }
}
else {
      if ($_SESSION["login"] == "true") echo $name.'</td><td></td><td></td><td></td><td></td>'; 
     }
                    ?>
                    </tr>

<?php
      } /*Ende While*/
        ?>
