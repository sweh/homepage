<?php
function format_tag($tag,$woche)
         {
          switch($tag)
		{
		case 'Mo': $tag = 'Montag';
 			   break;
		case 'Di': $tag = 'Dienstag';
			   break;	
		case 'Mi': $tag = 'Mittwoch';
			   break;
		case 'Do': $tag = 'Donnerstag';
			   break;
		case 'Fr': $tag = 'Freitag';
			   break;
		}
	 switch($woche)
		{
                 case 0: /*jede woche*/
		         return "jeden ".$tag;
                         break;
                 case 1: /*jede ungerade woche*/
                         return "in jeder ungeraden Woche, ".$tag."s";
                         break;
                 case 2: /*jede gerade woche*/
			 return "in jeder geraden Woche, ".$tag."s";
                         break;  
		}
	 }


function sws_berechnen($art, $nr, $dauer, $woche, $wert) 
    { 
         $sws = $dauer / 45;  
         if ($woche != 0)  /*nicht jede woche*/  
            {$sws = $sws / 2;}  
         $ausgabe = $sws;   
         return $ausgabe; 
    } 
?>  


