<?php require_once('../../config.inc'); seite(__FILE__); 

if ($_GET['show'])
    include($_GET['show'].'.php');
else
{
include('funktion.php'); 

     $vString = "SELECT id,einheit,vname,vart,vsem FROM mi_lehre_veranstaltung ORDER BY einheit"; 
     $vzString = "SELECT id,einheit,vnr,vart FROM mi_lehre_veranstaltung_zeit ORDER BY einheit"; 
     $vErgebnis = mysql_query($vString); 
     $vzErgebnis = mysql_query($vzString); 
?> 
<p><center> 
<img src="img/mi_lehrveranstaltungen.png" alt="Lehrveranstaltungen"> 
</center>
<table width=80% align="center"> 
  <tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt"> 
          <br><br> 
          Die Vertiefungsrichtung der Medieninformatik ist von vornherein interdisziplin�r  
          ausgerichtet durch 
          <br><br> 
          <menu> 
          <li> 
          Informatik-Grundlagen und Systemgestaltung ( 
          <a href="http://www.tu-chemnitz.de/informatik/">Fakult�t f�r Informatik</a>)</li> 
          <li>Printmedien (<a href="http://www.tu-chemnitz.de/mbv/">Fakult�t f�r Maschinenbau und  
          Verfahrenstechnik</a>) </li> 
          <li>Soziale Kompetenz (<a href="http://www.tu-chemnitz.de/phil/">Philosophische 
          Fakult�t</a>)</li> 
          </menu> 
          <br><br> 
          Weitere Informationen zur allgemeinen Gliederung des Studiums findest Du unter 
          <a href="../../medieninf/beschreibung/gliederung.php">Gliederung</a>. 
          <br><br>
	  </td></tr>
	  <tr><td>
          <table width=90%> 
            <tr><th>Medieninformatik - Grundstudium</th></tr> 
          </table> 
          <table width=90%> 
            <tr class="grau"><td><b>Fach</td> 
                 <td width="30"><b>1.</b></td> 
                 <td width="30"><b>2.</b></td> 
                 <td width="30"><b>3.</b></td> 
                 <td widht="30"><b>4.</b></td> 
            </tr> 
<?php
$string_abfrage = "SELECT vsem,vart,vname,einheit 
                   FROM mi_lehre_veranstaltung 
                   WHERE vart = 1 AND vsem < 5 
                   ORDER BY vname"; 
$beginn = 1;
$ende = 5;
include("grund.php"); ?>

          </table>       
  </td></tr> 
  <tr><td><br></td></tr>
  <tr><td>
          <table width=90%> 
            <tr><th>Medieninformatik - Hauptstudium</th></tr> 
          </table>
          <table width=90%> 
             <tr class="grau"><td><b>Fach</td> 
                 <td width="30"><b>5.</b></td> 
                 <td width="30"><b>6.</b></td> 
                 <td width="30"><b>7.</b></td> 
                 <td width="30"><b>8.</b></td> 
                 <td width="30"><b>9.</b></td> 
            </tr> 
<?php 
$string_abfrage = "SELECT vsem,vart,vname,einheit 
                   FROM mi_lehre_veranstaltung 
                   WHERE vart = 1 AND vsem > 4 
                   ORDER BY vname";  
$beginn = 5;
$ende = 10;
include("grund.php"); ?>
         </table>
  </td></tr>
	<tr><td align="right"><table width=100%><tr><td align="right"><?php if ($_SESSION["login"] == "true") echo "<a href='../../admin/lehrveranstaltung.php'><img src='../../admin/img/new_s.gif' alt='neue Vorlesung anlegen' border=0></a>"; ?></td><td width="50">&nbsp;</td></tr></table></td></tr>
<tr><td><table width=90%>
<tr><td class="grau"><b>Weiterhin wird angeboten:</b></td></tr>
<?php
/*Einzelne Praktikas ohne Lehrveranstaltung*/
$string = "SELECT id, einheit,vname from mi_lehre_veranstaltung WHERE vart=3";
$datensatz = mysql_query($string);
while(list($nummer,$einheit,$vname) = mysql_fetch_row($datensatz))
     {
      $suche="SELECT id from mi_lehre_veranstaltung WHERE einheit=".$einheit." AND vart=1";
      $suchdaten=mysql_query($suche);
      list($id)=mysql_fetch_row($suchdaten);
      if($id == 0)  /*Es gibt keine Vorlesung zu dieser Einheit*/
        {
                  echo '<tr><td>';
                  if ($_SESSION["login"] == "true") 
                      echo "<a href=\"../../admin/lehrveranstaltung.php?einheit=$einheit\">
<img src=\"../../admin/img/edit_s.gif\" alt=\"Vorlesung bearbeiten\" border=\"0\"></a>&nbsp;&nbsp;<a href=\"../../admin/lehrveranstaltung.php?einheit=$einheit&weiter=loeschen&loeschen=vorlesung\"><img src=\"../../admin/img/del_s.gif\" alt=\"Vorlesung l�schen\" title=\"Vorlesung l�schen\" border=\"0\"></a>";
                  echo '<a href="veranst_allg.php?show=praktikum&id='.$nummer.'">'.$vname.'</a></td></tr>';
        }
     }

/*Seminare*/
$string = "SELECT id, vname, einheit from mi_lehre_veranstaltung WHERE vart = 4";
$datensatz = mysql_query($string);
while(list($id, $vname, $einheit) = mysql_fetch_row($datensatz))
	{
	echo '<tr><td>';
if ($_SESSION["login"] == "true") 
                      echo "<a href=\"../../admin/lehrveranstaltung.php?einheit=$einheit\">
<img src=\"../../admin/img/edit_s.gif\" alt=\"Vorlesung bearbeiten\" border=\"0\"></a>&nbsp;&nbsp;<a href=\"../../admin/lehrveranstaltung.php?einheit=$einheit&weiter=loeschen&loeschen=vorlesung\"><img src=\"../../admin/img/del_s.gif\" alt=\"Vorlesung l�schen\" title=\"Vorlesung l�schen\" border=\"0\"></a>";

	echo '<a href="veranst_allg.php?show=praktikum&id='.$id.'">'.$vname.'</a></td></tr>';
	}

?>
</td></tr></table>
<tr><td><br></td></tr>
	<tr><td align="right"><table width=100%><tr><td align="right"><?php if ($_SESSION["login"] == "true") echo "<a href='../../admin/lehrveranstaltung.php?weiter=praktikum'><img src='../../admin/img/new_s.gif' alt='neues Praktikum/Seminar anlegen' title='neues Praktikum/Seminar anlegen' border=0></a>"; ?></td><td width="50">&nbsp;</td></tr></table></td></tr>
</table>        
</td></tr> 
</table> 
<?php }?>
