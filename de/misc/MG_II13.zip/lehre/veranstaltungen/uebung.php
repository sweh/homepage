<?php require_once('../../config.inc'); seite(__FILE__); ?>    

<?php 
/*id ist die id aus mi_lehre_veranstaltung*/ 
$id = $_GET["id"]; 
$link_nr = $_GET["nr"];

/*einheit ermitteln*/ 
$string = "SELECT einheit,vname,vinhalt,vabschluss,vliteratur,vhinweise FROM mi_lehre_veranstaltung WHERE id=".$id; 
$datensatz = mysql_query($string); 
while(list($veinheit,$name, $vinhalt,$vabschluss,$vliteratur,$vhinweise) = mysql_fetch_row($datensatz))  
     { 
      $einheit = $veinheit; 
      $vname = $name; 
      $inhalt = $vinhalt; 
      $abschluss = $vabschluss; 
      $literatur = $vliteratur; 
      $hinweise = $vhinweise;  
     }  

$string = "SELECT id FROM mi_lehre_veranstaltung WHERE einheit=".$einheit." AND vart = 1";
$daten = mysql_query($string);
list($bild_id) = mysql_fetch_row($daten);

/*veranstaltungsnummer ermitteln*/ 
$string = "SELECT vperson FROM mi_lehre_veranstaltung_zeit WHERE einheit=".$einheit." AND vart = 2"; 
$datensatz = mysql_query($string); 
$anzahl = mysql_num_rows($datensatz);
if($anzahl != 0) list($person) = mysql_fetch_row($datensatz);  
else $person = 'noch nicht bekannt';

$bild = 'mi_lehre_'.$bild_id;
?> 

<br><br><center> 
<img src="img/<?php echo $bild; ?>.png" alt="�bung <?php echo $vname; ?>">
</center>
<br><br> 
<table width=80% align="center"> 
<tr><td class="liniehell">      
    <b>�bung <?php echo $vname; ?></b> 
    </td> 
</tr> 
<tr><td><br></td> 
</tr> 

<tr><td class="grau"> 
    <b>Betreuer:</b> 
    </td> 
</tr> 
<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">  
    <?php 
    if ($person != 'noch nicht bekannt')
	 {
         $string = "SELECT titel,vname,name FROM mi_prof WHERE id=".$person;  
         $datensatz = mysql_query($string); 
         while(list($titel,$vname,$name) = mysql_fetch_row($datensatz)) 
              { 
               echo $titel." ".$vname." ".$name; 
              }
         }
    else echo $person; 
    ?>  
    </td> 
</tr> 
<tr><td class="grau"> 
    <b>Inhalt:</b> 
    </td> 
</tr> 
<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">  
    <?php 
      echo $inhalt;  
    ?>     
    </td> 
</tr> 
<?php if($literatur){ ?>
<tr><td class="grau"> 
    <b>Literaturempfehlung:</b> 
    </td> 
</tr> 
<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">  
    <?php 
      echo $literatur;  
    ?>    
    </td> 
</tr> 
<?php } 
if($hinweise)
	{
	?>
	<tr><td class="grau"> 
    	<b>Hinweise:</b> 
    	</td> 
	</tr> 
	<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">  
    	<?php echo $hinweise; ?>    
    	</td></tr> 
	<?php 
	} ?>
</table> 
<br>
<a href="veranst_allg.php?show=vorlesung&vnr=<?php echo $link_nr; ?>"><< zur�ck zur Vorlesung</a>
<br><br>
