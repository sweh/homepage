<?php
require_once('../../config.inc'); seite(__FILE__); 
include("funktion.php");

/*vnr ist die Veranstaltungsnummer*/
$vnr = $_GET["vnr"];
$link_nr = $vnr;

/* Zugeh�rigkeitsnummer*/
$sString = "SELECT einheit FROM mi_lehre_veranstaltung_zeit WHERE vnr='".$vnr."'";
$sdaten = mysql_query($sString);
while(list($veinheit) = mysql_fetch_row($sdaten)) {$einheit = $veinheit; }

/*Vorlesung suchen*/
$vString = "SELECT id, vart, vname, vinhalt, vabschluss, vliteratur, vhinweise FROM mi_lehre_veranstaltung WHERE einheit =".$einheit;
$vdatensatz = mysql_query($vString);
while(list($vid,$vart,$name, $vinhalt,$vabschluss,$vliteratur,$vhinweise) = mysql_fetch_row($vdatensatz))
      {
       if ($vart == 1) 
          {
           $id = $vid;		
           $inhalt = $vinhalt;
           $vname = $name;
           $abschluss = $vabschluss;
           $literatur = $vliteratur;
           $hinweise = $vhinweise;
          }
      }

$vzString = "SELECT id,einheit,vnr,vart,vtag,vbeginn,vdauer,vwoche,vperson,vraum,vaktiv FROM mi_lehre_veranstaltung_zeit";
$vzErgebnis = mysql_query($vzString);

/*nprofist die ID des Profs */
$pstring = "SELECT vperson from mi_lehre_veranstaltung_zeit WHERE vnr ='".$vnr."'";
$pdatensatz = mysql_query($pstring); 
while(list($prof) = mysql_fetch_row($pdatensatz)){$nprof=$prof;}

/*SWS berechnen*/
$anzahl_v = 0;
$anzahl_u = 0;
$anzahl_p = 0;

$vorlesung = 0;
$uebung = 0;
$praktika = 0;

$string = "SELECT vart, vdauer, vwoche, vnr FROM mi_lehre_veranstaltung_zeit WHERE einheit=".$einheit;
$datensatz = mysql_query($string);
while(list($vart, $vdauer, $vwoche, $vnr) = mysql_fetch_row($datensatz))
     {
      $art = $vart; 
      $nr = $vnr; 
      $dauer = $vdauer; 
      $woche = $vwoche; 

      if ($art == 1)   /* Vorlesung*/
         {
          if (($vorlesung == 0) or ($vorlesung == $nr))
          /*der erste eintrag oder die gleiche veranstaltung*/
             {
              $vorlesung = $nr;
              $sws = $dauer / 45;
              if ($woche != 0)  /*nicht jede woche*/
                 {$sws = $sws / 2;}
              $anzahl_v = $anzahl_v + $sws;
              $vorlesungsnummer = $nr;
             }
         }

      elseif ($art == 2)  /*�bung*/
        {
         if (($uebung == 0) or ($uebung == $nr))
         /*der erste eintrag oder die gleiche veranstaltung*/
            {
             $uebung = $nr;
             $sws = $dauer / 45;
             if ($woche != 0)  /*nicht jede woche*/
                {$sws = $sws / 2;}
             $anzahl_u = $anzahl_u + $sws;
            }
        }

      elseif ($art == 3) /*Praktika*/
       {
       if (($praktika == 0) or ($praktika == $nr))
       /*der erste eintrag oder die gleiche veranstaltung*/
          {
           $praktika = $nr;
           $sws = $dauer / 45;
           if ($woche != 0)  /*nicht jede woche*/
              {$sws = $sws / 2;}
           $anzahl_p = $anzahl_p + $sws;
          }
       }
     }


$bild = 'mi_lehre_'.$id;
?>
<br><center> 
<img src="img/<?php echo $bild; ?>.png" alt="Vorlesung <?php echo $vname; ?>"> 
</center>
<br>
<table width=80% align="center"> 

<tr><td class="liniehell">     
    <b>Vorlesung <?php echo $vname; ?></b>
    </td>
</tr>
<tr><td>
    <br>
    </td>
</tr> 

<tr><td class="grau">
    <b>Lehrender:</b>
    </td>
</tr>
<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">
    <?php
      $string = "SELECT titel,vname,name from mi_prof WHERE id=".$nprof;
      $datensatz = mysql_query($string);
      while(list($titel,$vname,$name) = mysql_fetch_row($datensatz))
      echo $titel, " ",$vname," ",$name;
    ?>
    </td>
</tr> 
<tr><td class="grau">
    <b>Termin:</b>
    </td>
</tr>
<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">
    <?php
    $string = "SELECT vaktiv FROM mi_lehre_veranstaltung_zeit WHERE einheit=".$einheit." AND vart=1";
    $datensatz = mysql_query($string);
    list($vaktiv) = mysql_fetch_row($datensatz);
    $sem = akt_semester();
    $sem = substr($sem,4,1);
    switch ($vaktiv) 
       {
        case 0: echo "diese Lehrveranstaltung wird zur Zeit nicht angeboten"; /*inaktiv*/
                break;

        case 1: /*Wintersemester*/
                if ($sem != 'w'){echo "diese Lehrveranstaltung wird im Wintersemester angeboten";}
		else {
                      $a_string= "SELECT vtag, vbeginn, vdauer, vwoche, vraum 
				  FROM mi_lehre_veranstaltung_zeit 
 				  WHERE einheit=".$einheit." AND vart=1";

                      $a_datensatz = mysql_query($a_string);
                      echo "Diese Lehrveranstaltung findet statt:<br>";
		      echo "<table><tr><td width='80'></td><td></td></tr>";
                      while(list($vtag, $vbeginn, $vdauer, $vwoche, $vraum) = mysql_fetch_row($a_datensatz))
                           { 	
                            echo "<tr><td></td>";
                            echo "<td>";
			    echo format_tag($vtag,$vwoche);
                            echo " ".format_zeit($vbeginn);
			    echo " Uhr im Raum";
                            echo " ".$vraum."</td></tr>";
                           }	
                      echo "</table>";	
echo '<br>Weitere Termine k�nnen dem 
<a href="../stundenplaner/plan.php">Stundenplaner</a> entnommen werden.';
                     }
                break;

        case 2: /*Sommersemester*/
                if ($sem != 's'){echo "diese Lehrveranstaltung wird im Sommersemester angeboten";}
		else {
 	              echo "Diese Lehrveranstaltung findet statt:<br>"; 
                      $a_string="SELECT vtag, vbeginn, vdauer, vwoche, vraum FROM mi_lehre_veranstaltung_zeit WHERE einheit=".$einheit." AND vart=1"; 
                      $a_datensatz = mysql_query($a_string); 
                      echo "<table><tr><td width='80'></td><td></td></tr>"; 
                      while(list($vtag, $vbeginn, $vdauer, $vwoche, $vraum) = mysql_fetch_row($a_datensatz)) 
                           { 
                            echo "<tr><td></td>"; 
                            echo "<td>"; 
                            echo format_tag($vtag,$vwoche); 
                            echo " ".format_zeit($vbeginn); 
                            echo " Uhr im Raum"; 
                            echo " ".$vraum."</td></tr>"; 
                           }  
                      echo "</table>"; 
echo '<br>Weitere Termine k�nnen dem 
<a href="../stundenplaner/plan.php">Stundenplaner</a> entnommen werden.';       
                     } 
                break; 


        case 3: /*Beide semester*/ 
                echo "Diese Lehrveranstaltung findet statt:<br>"; 
                      $a_string="SELECT vtag, vbeginn, vdauer, vwoche, vraum FROM mi_lehre_veranstaltung_zeit WHERE einheit=".$einheit." AND vart=1"; 
                      $a_datensatz = mysql_query($a_string); 
                      echo "<table><tr><td width='80'></td><td></td></tr>"; 
                      while(list($vtag, $vbeginn, $vdauer, $vwoche, $vraum) = mysql_fetch_row($a_datensatz)) 
                           { 
                            echo "<tr><td></td>"; 
                            echo "<td>"; 
                            echo format_tag($vtag,$vwoche); 
                            echo " ".format_zeit($vbeginn); 
                            echo " Uhr im Raum"; 
                            echo " ".$vraum."</td></tr>"; 
                           }
                      echo "</table>";                           
                    echo '<br>Weitere Termine k�nnen dem 
                    <a href="../stundenplaner/plan.php">Stundenplaner</a> entnommen werden.'; 
                      
                break;  } 
?>
    </td>
</tr>

<tr><td class="grau">
    <b>Inhalt:</b>
    </td>
</tr>
<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">
    <?php
      echo $inhalt; 
    /*ist zus�tzlich ein Praktika verhanden?*/
    $string = "SELECT id  FROM mi_lehre_veranstaltung WHERE einheit=".$einheit." AND vart=3";
    $datensatz = mysql_query($string);
    while(list($id) = mysql_fetch_row($datensatz))  
         {
          ?> 
          <p align="right">
          <a href="praktikum.php?id=<?php echo $id; ?>&nr=<?php echo $link_nr; ?>">zum Praktikum >></a></p> 
          <?php
         } 

   /*ist zus�tzlich eine �bung vorhalnden?*/
   $string = "SELECT id FROM mi_lehre_veranstaltung WHERE einheit='".$einheit."' AND vart=2";
   $datensatz = mysql_query($string);
   while(list($id) = mysql_fetch_row($datensatz))
        {         
         ?>
         <p align="right">
         <a href="uebung.php?id=<?php echo $id; ?>&nr=<?php echo $link_nr; ?>">zur �bung >></a></p>
         <?php
        }
 ?>
    </td>
</tr>
<tr><td class = "grau">
    <b>�bersicht:</b>
    </td>
</tr>
<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">
    <table width=90% bgcolor="#CCE7E7" align="center">
           <tr><td width="100">Vorlesung:</td><td><?php echo $anzahl_v ?></td></tr>
           <tr><td>�bung:    </td><td><?php echo $anzahl_u ?></tr>
           <tr><td>Praktikum:</td><td><?php echo $anzahl_p ?></tr>
           <tr valign="top"><td>Abschlu�:</td>
                            <td><?php
                                   echo $abschluss;
                                 ?>
    </table>
    </td>
</tr>
<?php if($literatur){ ?>
<tr><td class = "grau">
    <b>Literaturempfehlungen:</b>
    </td>
</tr>
<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">
    <?php
      echo $literatur;
    php?>
    </td>
</tr>
<?php } 

$string = "SELECT id FROM mi_lehre_material WHERE einheit=".$einheit;
$datensatz = mysql_query($string);
$ergebnis = mysql_fetch_row($datensatz);
if(($hinweise) OR ($ergebnis)){
?>
<tr><td class = "grau">
    <b>Hinweise:</b>
    </td>
</tr>
<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">
    <?php 
    if ($ergebnis)
 echo 'Zu dieser Lehrveranstaltung sind <a href="../lehrmaterial/material.php?einheit='.$einheit.'">
                Skripte </a> online verf�gbar.<br><br>';
      echo $hinweise;
    ?>
    </td>
</tr>
<?php } ?>
</table> 
<br>
<a href="veranst_allg.php"><< zur�ck zur �bersicht</a>
<br><br>
