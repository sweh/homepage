<?php
require_once('../../config.inc'); seite(__FILE__);
include("funktion.php");
?>
<center>
<br>
<img src="img/mi_stundenplaner.png" alt="Stundenplaner">
</center>
<br><br>
<table width=100% align="center">
<tr align="center" bgcolor="#319A9C"><td><b>Zeit</b></td>
    <td><b>Montag</b></td>
    <td><b>Dienstag</b></td>
    <td><b>Mittwoch</b></td>
    <td><b>Donnerstag</b></td>
    <td><b>Freitag</b></td></tr>
<?php
$anzahl = count($_GET);
foreach ($_GET as $key => $value)
        {
        if ($key == sem)$Semester = $value;
        else {
             $string = 'SELECT vart,vtag,vbeginn,vdauer,vwoche,vperson,vraum,einheit
                        FROM mi_lehre_veranstaltung_zeit
                        WHERE vnr="'.$value.'"';
             $datensatz = mysql_query($string);
             while(list($art,$tag,$beginn,$dauer,$vwoche,$person,$raum,$gruppe) = mysql_fetch_row($datensatz))
                  {
                  $einheit = zeit_to_einheit($beginn);
                  $person = id_to_person($person);
                  $tag = get_tag($tag);

                  /*auf fehler pr�fen*/
                  while($dauer > 0)
                       {
                       $fehler = kontroll_ueberschneidung($stundenplan,$einheit,$tag,$vwoche,$key);
                       if ($fehler) echo $fehler.'<br><br>';

                       /*keine �berschneidungen, also eintragen*/
                       else $stundenplan[$einheit][$tag][$vwoche] = $key."+".$person."+".$raum."+".$art;

                       $einheit = $einheit + 1;
                       $dauer = $dauer - 90;
                       }
                  }
             }
        }
echo '<a href="plan.php?sem='.$Semester.'"><<< zur�ck zur Auswahl</a><br><br>';

/*array ausgeben*/
for ($i = 1; $i < 8; $i++)
        {
        $zeit_aus = einheit_to_time($i);
        echo '<tr align="center"><td rowspan="2" bgcolor="#319A9C"><b>'.$zeit_aus.'</b></td>';
        $speicher = ' ';
        for ($j = 1; $j < 6; $j++)
                        {
                        if ($stundenplan[$i][$j][0])
                           {
                           echo '<td rowspan="2" bgcolor="#CCE7E7">';
                           echo format_ausgabe($stundenplan[$i][$j][0],'ausgabe');
                           echo '</td>';
                           }
                        else
                           {
                           if ($stundenplan[$i][$j][1])
                              {
                               echo '<td bgcolor="#CCE7E7">';
                               echo format_ausgabe($stundenplan[$i][$j][1],'ausgabe');
                               echo '</td>';
                               if($stundenplan[$i][$j][2])
                                 $speicher = $speicher.'<td bgcolor="CCE7E7">'
                                 .format_ausgabe($stundenplan[$i][$j][2],'ausgabe').'</td>';
                               else $speicher = $speicher.'<td class="grau">&nbsp;</td>';
                              }
                           elseif ($stundenplan[$i][$j][2])
                                  {
                                   echo '<td class="grau">&nbsp;</td>';
                                   $speicher = $speicher.'<td bgcolor="#CCE7E7">'
                                               .format_ausgabe($stundenplan[$i][$j][2],'ausgabe').'</td>';
                                  }
                           else echo '<td rowspan="2" class="grau">&nbsp;</td>';
                           }
                        }
                        echo '</tr><tr align="center">'.$speicher.'</tr>';

}
?>
</table>
