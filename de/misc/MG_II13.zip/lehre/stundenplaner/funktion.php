<?php
function zeit_to_einheit($zeit)
	{
	if (strlen($zeit) == 3)	$zeit = substr($zeit,0,1);
	else $zeit = substr($zeit,0,2);
	switch($zeit)
		{
		case 7: 
		case 8: $einheit = 1;
			break;
		case 9:
		case 10: $einheit = 2;
			 break;
		case 11:
		case 12: $einheit = 3;
			 break;
		case 13:
		case 14: $einheit = 4;
			 break;
		case 15:
		case 16: $einheit = 5;
			 break;
		case 17:
		case 18: $einheit = 6;
			 break;
		case 19:
		case 20: $einheit = 7;
			 break;
		case 21: $einheit = 8;
			 break;
		default: $einheit = "hinweis"; 
		}
	return $einheit;
	}

function id_to_person($id)
	{
	$string = "SELECT name FROM mi_prof WHERE id=".$id;
	$datensatz = mysql_query($string);
	list($pname) = mysql_fetch_row($datensatz);
	return $pname;
	}

function format_ausgabe_fehler($string)
	{
	$teil = strtok($string, '&');
	$ausgabe = strtok(str_replace('_',' ',$teil),'+');
	while($teil)
		{	
		$art = $teil;
		$teil = strtok('+');
		}	

	return art_veranstaltung($art).' '.strtok($ausgabe,'/'); 	
	}

function ueberschneidung($planer,$teinheit,$tag,$woche,$typ)
        {
	switch($woche)
		{
		case 0: /*die Veranstaltung findet jede Woche statt*/
			if($planer[$teinheit][$tag][0]) 
                            {
                             $vorhanden = $planer[$teinheit][$tag][0];
                             $woche = 0;
                            }
			elseif($planer[$teinheit][$tag][1]) 
                            { 
                             $vorhanden = $planer[$teinheit][$tag][1];
                             $woche = 1;
                            }
			elseif($planer[$teinheit][$tag][2]) 
	                    { 
                             $vorhanden = $planer[$teinheit][$tag][2];
			     $woche = 2;
                            }
                        break;

		case 1: /*die Veranstaltung findet in jeder ungeraden Woche statt*/
			if($planer[$teinheit][$tag][0]) 
                           {
                            $vorhanden = $planer[$teinheit][$tag][0];
                            $woche = 0;
                           } 
                        elseif($planer[$teinheit][$tag][1]) 
                           {
                            $vorhanden = $planer[$teinehit][$tag][1]; 
                            $woche = 1;
                           }
                        break;

		case 2: /*die Veranstaltung findet in jeder geraden Woche statt*/
			if($planer[$teinheit][$tag][0]) 
                           {
                            $vorhanden = $planer[$teinheit][$tag][0];
                            $woche = 0;
                           }
			elseif($planer[$teinheit][$tag][2]) 
                           {
                            $vorhanden = $planer[$teinheit][$tag][2];
                            $woche = 2;
                           }
                        break;
               }

        switch ($typ)
                {
                case 'string':  return $vorhanden;
                                break;
 
                case 'woche' : return $woche;
                               break; 
               }
        }


function kontroll_ueberschneidung($planer,$teinheit,$tag,$woche,$name)
	{
        $vorhanden = ueberschneidung($planer,$teinheit,$tag,$woche,'string');

        if($vorhanden)
	   {
	    $vorhanden = format_ausgabe_fehler($vorhanden);
	    $fehler = "Die Veranstaltungen:<br><li>".$vorhanden."</li>
		      <li>".form_name($name)."</li><br> �berschneiden sich in der Einheit: "
		      .nr_to_tag($tag,$woche)." ".einheit_to_time($teinheit).".<br>
                      Bitte w�hle in der �bersicht neu aus.";
	   }
	return $fehler;                      
	}	


function art_veranstaltung($vart)
	{
	switch($vart)
		{
		case 1: $art = 'Vorlesung';
			break;
		case 2:	$art = '�bung';
			break;
		case 3: $art = 'Praktikum';
			break;
		}
	return $art;
	}

function nr_to_tag($tag,$woche)
	{
	switch($tag)
		{
		case 1: $string = 'Montag';
			break;
		case 2: $string = 'Dienstag';
			break;
		case 3: $string = 'Mittwoch';
			break;
		case 4: $string = 'Donnerstag';
			break;
		case 5: $string = 'Freitag';
			break;
		}
         switch($woche)
                {
                case 0: return $string;
                        break;
                case 1: return $string.'/1';
                        break;
                case 2: return $string.'/2';
                        break;
                }
	}


function format_tag($tag,$woche) 
         { 
          switch($tag) 
        { 
        case 'Mo': $tag = 'Montag'; 
               break; 
        case 'Di': $tag = 'Dienstag'; 
               break;     
        case 'Mi': $tag = 'Mittwoch'; 
               break; 
        case 'Do': $tag = 'Donnerstag'; 
               break; 
        case 'Fr': $tag = 'Freitag'; 
               break; 
        case 'Sa': $tag = 'Samstag';
              break;
        case 'So': $tag = 'Sonntag';
              break;
        } 
     switch($woche) 
        { 
                 case 0: /*jede woche*/ 
                 return $tag; 
                         break; 
                 case 1: /*jede ungerade woche*/ 
                         return $tag."/1"; 
                         break; 
                 case 2: /*jede gerade woche*/ 
             return $tag."/2"; 
                         break;   
        } 
     } 


function form_name($name)
	{
	$name = strtok($name,"/");
	return $name;
	}


function get_tag($tag)
   {
   switch($tag)
       {
        case 'Mo': return 1;
                   break;
        case 'Di': return 2;
                   break;
        case 'Mi': return 3;
                   break;
        case 'Do': return 4;
                   break;
        case 'Fr': return 5;
                   break;
       }
   }

function einheit_to_time($einheit)
  {
   switch($einheit)
      {
       case 1: return '7:30 - 9:00';
               break;
       case 2: return '9:15 - 10:45';
               break;
       case 3: return '11:30 - 13:00';
               break;
       case 4: return '13:45 - 15:15';
               break;
       case 5: return '15:30 - 17:00';
               break;
       case 6: return '17:15 - 18:45';
               break;
       case 7: return '19:00 - 20:30';
               break;
      }
  }

function format_ausgabe($string,$typ)
  {
   $name = strtok($string,"+");
   $person = strtok("+");
   $raum = strtok("+");
   $art = strtok("+");

   $name = strtok($name,'/');
   $name = str_replace('_',' ',$name);
   $name = trim($name);

   switch($typ)
	{
	case 'ausgabe': $art = art_veranstaltung($art);
   			return '<span style="font-size:8pt">'.$art.'<br></span>
          			<span style="font-weight:bold; font-size:8pt">'.$name.'</span>
          			<span style="font-size:8pt"><br>'.$person.' '.$raum.'</span>';
			break;
	
	case 'art': return $art;
		    break; 

	case 'name': return $name;
		     break;
	}
  }

?> 
