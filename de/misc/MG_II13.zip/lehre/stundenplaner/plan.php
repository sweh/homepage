<?
require_once('../../config.inc'); seite(__FILE__);  
include("funktion.php");  
$semester = $_GET['sem'];

$stundenplan[1][1][1] = 0;
$_SESSION['stundenplan'] = $stundenplan;
?>
<center> 
<br> 
<img src="img/mi_stundenplaner.png" alt="Stundenplaner">
</center> 
<br>
<table width=80% align="center"> 
<tr><td>
        <table width=100% align="center">
        <tr>
        <?php
        for($i = 1;$i < 10; $i++)
	    echo '<td class="grau"><a href="plan.php?sem='.$i.'">'.$i.' Sem</a></td>';
            ?>
        </tr>
        </table>
</td></tr>
<?php if ($semester){ ?>
<tr><td class="liniehell">Lehrveranstaltungen, die im <?php echo $semester; ?> Semester angeboten werden:</td></tr>
<tr><td><br>
	<table width=90%>
	<?php 
	$abfrage = "SELECT DISTINCT einheit,vname FROM mi_lehre_veranstaltung 
		    WHERE vsem=".$semester."  
		    ORDER BY einheit";
	$daten = mysql_query($abfrage);
        if(mysql_num_rows($daten) == 0)
		{echo "F�r dieses Semester werden keine Lehrveranstaltungen angeboten.";
		 $nix = 1;
		}
        echo '<form action="anfrage.php" method="get">';
	echo '<input type="hidden" name="sem" value="'.$semester.'">';
	while(list($einheit,$vname) = mysql_fetch_row($daten))
		{
		$inhalt = "SELECT vnr,vart,vtag,vbeginn,vwoche,vdauer FROM mi_lehre_veranstaltung_zeit 
			   WHERE einheit =".$einheit." AND vaktiv != 0 AND vbeginn != 0 
			   ORDER BY vart, vnr";
		$daten_inhalt = mysql_query($inhalt);
		if (mysql_num_rows($daten_inhalt) != 0){
		echo '<tr><td class="grau"><b>'.$vname.'</b></td></tr>';
		echo '<tr><td>';
		echo '<table width=90% align = "center">';
		$zahler = 0;
		$nummer = 0;
 		while(list($vnr,$vart,$vtag,$vbeginn,$vwoche,$vdauer) = mysql_fetch_row($daten_inhalt))
			{
			if ($nummer == $vnr)
				{
				echo '<tr><td></td>';
				echo '<td>'.format_tag($vtag,$vwoche).'</td>';
				echo '<td align="right">'.format_zeit($vbeginn);
				echo "</td></tr>";
				} 
			else{
			echo '<tr><td width="40%"><input type="checkbox" name="'.$vname.'/'.$zaehler.'" value="'.$vnr.'">';
			echo art_veranstaltung($vart)."</td><td>".format_tag($vtag,$vwoche).'</td><td align="right">'.format_zeit($vbeginn);
			echo '</td></tr>';
			$nummer = $vnr;
			$zaehler++;
			}
		}
		echo "</table></td></tr>";
		}}	
	?>
	</table></td></tr>
</td></tr>
<?php if ($zaehler){ ?>
	<tr><td align="right"><input type="submit" value="planen" ></td></tr>
	<?php } else {if ($nix != 1) { ?>
	<tr><td>F�r die Veranstaltungen in diesem Semester sind zur Zeit keine aktuellen Daten verf�gbar.
	        �ber Inhalte und Anforderung kannst du dich aber unter <a href="../veranstaltungen/veranst_allg.php">
		Veranstaltungen</a> informieren.
	</td></tr>
<?php  }}}
else include("text.php");
?>
</table>
