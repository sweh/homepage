<table width=80% align="center">
<tr><td class="grau"><b>Sinn und Zweck</b></td></tr>
<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">
Mit diesem Tool soll die Planung Eures pers�nlichen Stundenplans unkomplizierter, schneller und damit effektiver von statten gehen. L�stiges Nachschlagen und Abschreiben im Vorlesungsverzeichnis bei der Auswahl der Pflichtf�cher der Vertiefungsrichtung Medieninformatik sollte damit der Vergangenheit angeh�ren. Dennoch empfielt es sich die Ergebnisse des Stundenplaners nocheinmal mit aktuellen Daten des Pr�fungsamtes gegenzulesen. 
</td></tr>
<tr><td class="grau"><b>Benutzung</b></td></tr>
<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">
Die Verwendung des Stundenplaners ist denkbar einfach. W�hle einfach das Semester, von welchem Du Deinen Stundenplan zusammenstellen m�chtest. W�hle danach die zur Auswahl stehenden �bungen bzw. Praktika und schicke das Formular ab. In einem neuen Fenster wird nun Dein individueller Stundenplan f�r das Vertiefungsgebiet aufgelistet. 
</td></tr>
<tr><td class="grau"><b>Hinweise und Gew�hrleistung</b> </td></tr>
<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt">
Dieses Tool soll die Stundenplanung des Studenten lediglich unterst�tzen. Es erspart in keinem Fall das �berpr�fen der aktuellen Daten des Pr�fungsamtes. Die Angaben sind daher ohne Gew�hr. Desweiteren kann eine individuelle Zusammenstellung des Studienablaufes im einen oder anderen Falle erfordlich werden. Die Vorgaben dieses Stundenplaners sind lediglich als Empfehlung anzusehen. Setze Dich in Fragef�llen �ber den Studienablauf mit der Fachstudienberatung in Verbindung oder schau einfach mal im Fachschaftsrat vorbei. 
</td></tr>
</table>
</center>
