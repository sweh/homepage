<?php
#####################################
#	         mysql.php          	#
#stellt Kontakt zum Mysql-Server her#
#	      created by sweh       	#
#	  last update: 28.01.2004   	#
#####################################

$mysql_vbg = @mysql_connect($mysql_server, $mysql_bn, $mysql_pw);
$mysql_status = @mysql_select_db($mysql_db, $mysql_vbg);

if (!$mysql_status)
  die("Es konnte keine Verbindung zur Datenbank aufgebaut werden. Bitte �berpr�fen Sie die Einstellungen!");
?>