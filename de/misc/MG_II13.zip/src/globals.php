<?php
##############################
#       globals.php          #
#Sammlung globaler Variablen #
#      created by sweh       #
#  last update: 28.01.2004   #
##############################

// hier werden Variablen definiert, die wir alle brauchen

// MySql-Daten
$mysql_server = ""; // Adresse des MySql-Servers
$mysql_bn = "";                // Benutzername
$mysql_pw = "";                       // Passwort
$mysql_db = "";                      // Datenbank

// Ordner-Namen
$dir_sources = "src/";
?>