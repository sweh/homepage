<?php
##############################
#      admin_menu.php        #
# Linkliste & Login/Logout   #
#      created by sweh       #
#  last update: 28.01.2004   #
##############################

// Logged ein
if ($_POST["action"] == "login")
{
	$result_admin = mysql_query("SELECT id, benutzername, passwort, last_login from mi_benutzer WHERE benutzername = '".$_POST["benutzername"]."' ORDER by id asc LIMIT 1");
	if (mysql_num_rows($result_admin))
		while ($row_admin = mysql_fetch_array($result_admin))
		{
			$_SESSION["benutzerid"] = $row_admin["id"];
			$db_passwort = $row_admin["passwort"];
			$_SESSION["last_login"] = $row_admin["last_login"];
		}
	if (md5($_POST["passwort"]) == $db_passwort)
	{
		$_SESSION["login"] = "true";
		mysql_query("UPDATE mi_benutzer set last_login = '".time()."' WHERE id = '".$_SESSION["benutzerid"]."' LIMIT 1");
	}
	else
		$_SESSION["login"] = "false";
}

//Logged aus
if ($_POST["action"] == "logout")
{
	if ($_POST["tues"] == "JA")
		$_SESSION["login"] = "false";
}

#6. Admin-Eintrag:
   $titel[' admin'] = 'Administration';
   $style[' admin'] = 'kopf';

	if ($_SESSION["login"] != "true")
	   $titel['admin/login.php'] = 'LogIn';
	else
	{
	   $titel['admin/logout.php'] = 'LogOut';
	
		if($_SESSION["benutzerid"] == "1")
			$titel['admin/benutzer.php'] = 'Benutzer bearbeiten';
		else
			$titel['admin/passwort.php'] = 'Passwort �ndern';
	
	   $titel['admin/mi_prof.php'] = 'Mitarbeiter verwalten';
	   $titel['admin/mi_prof_publik.php'] = 'Publikationen verwalten';
	   $titel['admin/mi_forschung.php'] = 'Forschung verwalten';
	   $titel['admin/mi_links.php'] = 'Links verwalten';
	   $titel['admin/mi_veranstaltung.php'] = 'Veranstaltung verwalten';
	   $titel['admin/mi_lehre_arbeiten.php'] = 'Studien- und Diplomarbeitsthemen verwalten';
	   $titel['admin/lehrveranstaltung.php'] = 'Lehrveranstaltung hinzuf�gen';
	   $titel['bild/index.php'] = 'Titelbilder verwalten';
	}
?>
