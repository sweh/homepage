<?
	// startet eine Session
	session_start();

// "errechnet" das vorhergehen Semster
function prev_sem($akt_sem){
$sem=substr($akt_sem,4,1);
$jahr=substr($akt_sem,0,4);
if($sem=='w'){$sem_2='s';$jahr_2=$jahr;}
else {$sem_2='w'; $jahr_2=$jahr-1;}
return $jahr_2.$sem_2;
}


//holt den datei-Typ aus dem namen
function datei_typ($name){
$typ = substr($name,strrpos($name,'.')+1);
return $typ;
}

// wandelt Datum JJJJ_MM_TT in TT.MM.JJJJ um
function date_conf($date){
$date_s=explode('-',$date);
if($date_s[1]!='0' and $date_s[1]!='' and $date_s[1]!='0')
{
 if($date_s[2]!='0' and $date_s[2]!='' and $date_s[2]!='0'){$datum = $date_s[2].'. ';}
 $monat=array('Jan.','Feb.','M&auml;rz','Apr.','Mai','Juni','Juli','Aug.','Sept.','Okt.','Nov.','Dez.');
 $datum = $datum.$monat[$date_s[1]-1].' ';
}
$datum = $datum.$date_s[0];
return $datum;
}


	// wandelt Timestamp in Semster um
function timestamp_to_semester($time){
$jahr = date ("Y" , $time);
$monat = date ("m" , $time);
if($monat>=4 and $monat<10){$semester='s';}
else {if($monat<4){$jahr=$jahr-1;} $semester='w';}
$semester=$jahr.$semester;
return $semester;
}

	// gibt aktuelles Semester zur�ck
function akt_semester(){
return timestamp_to_semester(time());
}

function jahre($anfang,$ende){
$time=time();
$jahr = date ("Y" , $time)+$ende;
$array[0]=$jahr-$anfang+1;
for($i=$anfang;$i<$jahr+2;$i++){
$array[$i-$anfang+1]=$i;
}
return $array;
}

    //aus Datum Timestamp
function date_to_timestamp ($date)
{
$split_date = split ('-', $date);
$timestamp = mktime ($split_date[3], $split_date[4], $split_date[5], $split_date[1], $split_date[2], $split_date[0]);
return $timestamp;
}

    // aus Timestamp Datum
function timestamp_to_date ($timestamp)
{
$date = date ("d.m.Y" , $timestamp);
return $date;
};

    // aus Timestamp Zeit
function timestamp_to_time ($timestamp)
{
$date = date ("G:i" , $timestamp);
return $date;
};

// f�gt den : in eine Zeit ein
function format_zeit($zeit) 
    { 
        $lang = strlen($zeit); 
        if ($lang == 3) 
           { 
            $stunde = substr($zeit,0,1); 
            $min = substr($zeit,1,2); 
           } 
        else 
           { 
        $stunde = substr($zeit,0,2); 
            $min = substr($zeit,2,2); 
           } 
        return $stunde.":".$min; 
    } 


    // k�rzte einen Text auf die gew�nschte l�nge und f�gt "..." an
function kurzundknapp($text,$l)
{
$text2=substr($text,0,$l);
if($text!=$text2){$text2=$text2.'...';}
return $text2;
};

    // macht aus einem Arry eine Auflistung (durch "_" getrennt)
    // und entfernt am Ende und Anfang �berfl�ssige "_"
function add($publik_nr_a){
$i=0;
while($publik_nr_a[$i]!=''){$str.='_'.$publik_nr_a[$i].'_';$i++;};
$str=str_replace("__","+",$str);
$str=str_replace("_","",$str);
$str=str_replace("+","_",$str);
return $str;
}

    // l�d bild hoch upload(Bildquelle,Bildtyp,id in db,Zielverzeichniss,Zielbildprefix)
function upload($bild,$bildtype,$id,$dir,$name){
$cert1 = "image/pjpeg"; //Jpeg type 1
$cert2 = "image/jpeg"; //Jpeg type 2
$cert3 = "image/gif"; //Gif type
$cert5 = "image/png"; //Png type
$cert10 = "image/x-png"; //PNG f�r IE :-(
$cert6 = "image/tiff"; //Tiff type
$cert7 = "image/bmp"; //Bmp Type
$cert8 = "application/pdf"; //pdf Type
$cert9 = "application/zip"; //zip Type
    if($bildtype==$cert10){$bildtype=$cert5;}
    $bildname=$name.$id.'.'.substr($bildtype,strrpos($bildtype,'/')+1);
    if (($bildtype == $cert1) or ($bildtype == $cert2) or ($bildtype == $cert3) or ($bildtype == $cert5) or ($bildtype == $cert6) or ($bildtype == $cert7)or ($bildtype == $cert8)or ($bildtype == $cert9) or ($bildtype == $cert10)) {
    if(move_uploaded_file($bild,$dir.$bildname)){echo 'Datei Erfolgreich hochgeladen.';}else{echo 'Fehler beim hochladen der Datei.';}
}
return $bildname;
}

    // �berpr�ft ob ein Wer in der Liste ist
    // Liste wird duch "_" getrennt
function is_in($str,$src){
$array=explode("_",$str);
$return='false';
$i=0;
while($array[$i]!=''){
    if($array[$i]==$src){$return='true';}
    $i++;
}
return $return;
} 


        // macht Titelbilder - text_pic(Text, Typ, Zielverzeichniss, Zielname)
        /*
        Typen:
        "prof" - Mitarbeiter
        "forum" - Forum
        "faq" - FAQ
        "stundenplan" - Stundenplaner
        "job" - Jobaussichten
        "diplom" - Diplom- und Studienarbeiten
        "studium" -  Infos zum Studium/ Medieninformatik
        "publik" Publikationen
        "mail" - Mailingliste
        "link" - Links
        "skript" - Skripte
        "forschung" - Forschung
        "zeit" - Veranstalung
        default - Lehrveranstaltungen
        */
function text_pic($text,$typ,$copydir,$copyname){

//$maindir="/afs/tu-chemnitz.de/home/urz/s/sweh/public_html/MG_II13/";
$maindir=substr($_SERVER["SCRIPT_FILENAME"],0,strrpos($_SERVER["SCRIPT_FILENAME"], '/')+1).'../';

$x=92; //x-Position (orginal:86)
$y=60; //y-Position (orginal:65)
$strlen=20; //Zeichenl�nge bis Umbruch
$schrift = "VeraBd.ttf";

$orgi=$maindir."bild/vorlagen/mi_".$typ.".png";

$copy = $copydir.$copyname;

$image = ImageCreateFromPng($orgi);
$col= imagecolorallocate($image, 41, 22, 112);

$dir=$maindir."bild/vorlagen/";

$len=strlen($text);
$zeilen=ceil(($len-($len*0.45))/($strlen*0.735));


$start=0;
for($i=0;$i<$zeilen;$i++){
$pos1=strrpos(substr($text,$start,$strlen+(($zeilen-1)*4)),' ')+$start;
$pos2=strrpos(substr($text,$start,$strlen+(($zeilen-1)*4)),'-')+$start;
if($pos1>$pos2){$ende=$pos1;}else{$ende=$pos2+1;}
$schriftgr=20-(($zeilen-1)*3);
if($i==$zeilen-1){$zeilentext[$i]=substr($text,$start);}
else{$zeilentext[$i]=substr($text,$start,$ende-$start);}
$schrifttop=($zeilen-1)*10;
$schrifty=$y-$schrifttop+($i*(1.45*$schriftgr));
if($ende==$pos1){$ende=$ende+1;}
$start=$ende;
}

      // Absch�tzung und Fehlerkorrektur
if(strlen($zeilentext[$zeilen-1])>($strlen+(($zeilen-1)*4))){$zeilen++;$strlen=$strlen-5;}
else {if(strlen($zeilentext[$i-2])<3 and $zeilen!=1){$zeilen--;}}

if($zeilen>5){$strlen=$strlen+6;$zeilen--;}


$start=0;
for($i=0;$i<$zeilen;$i++){
$pos1=strrpos(substr($text,$start,$strlen+(($zeilen-1)*4)),' ')+$start;
$pos2=strrpos(substr($text,$start,$strlen+(($zeilen-1)*4)),'-')+$start;
if($pos1>$pos2){$ende=$pos1;}else{$ende=$pos2+1;}
$schriftgr=20-(($zeilen-1)*3);
if($i==$zeilen-1){$zeilentext=substr($text,$start);}
else{$zeilentext=substr($text,$start,$ende-$start);}
$schrifttop=($zeilen-1)*10;
$schrifty=$y-$schrifttop+($i*(1.45*$schriftgr));
imagettftext($image, $schriftgr, 0, $x, $schrifty, $col, $dir.$schrift, $zeilentext);
if($ende==$pos1){$ende=$ende+1;}
$start=$ende;
}

imagepng($image, $copy);
}