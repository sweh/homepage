<?php require_once('../config.inc'); seite(__FILE__); ?>

<?php
$id=$_GET["id"];
$id=intval($id);

//wenn keine Projekt-ID �bergeben wurde (z.b. bei klicken auf Projekte in Menu-Leiste)
if ($id=="")
{
echo "<br><center><img src=\"img/mi_forschung.png\" align=\"center\">
    <table width=80% align=\"center\">
    <tr height=10><td></td></tr>
    <tr>
    <td align=\"left\" style=\"padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt\">Das Forschungsprofil der Professur Medieninformatik schlie�t an die Vorarbeiten des Stelleninhabers an. Die folgenden Seiten geben einen &Uuml;berblick �ber Forschungsvorhaben und Projekte, die in den Bereichen
       <ul>
        <li>Gestaltung von Benutzeroberfl&auml;chen und webbasierten Informationssystemen</li> 
        <li>Elektronisches Publizieren</li> 
        <li>Texttechnologie, insbesondere Text Mining</li> 
        <li>Medienanalyse und</li> 
        <li>Information Retrieval</li> 
       </ul>angesiedelt sind.</td>
    </tr>
    </table></center><br>";
}

//Anzeigen des Projekts (ID wurde �bertragen)
else
if (is_int($id))
{
$projekte=mysql_query("SELECT * FROM mi_forschung WHERE id=$id");
if (mysql_num_rows($projekte))
{
 $array=mysql_fetch_array($projekte);
 echo '<br><center><table width=80% align="center"><tr><td>';
 $titelimg= 'img/mi_forschung_titel_'.$id.'.png'; 
 if(is_readable($titelimg))
     echo '<img src="'.$titelimg.'" align="center" border="0" title="'.$array["name"].'" alt="'.$array["name"].'">';
  else echo '<h1 align="center">'.$array["name"].'</h1>';
  echo '</td></tr><tr height=10><td></td></tr>';

//Mitwirkende ausgeben
 if ($array["pid"])
 {
  $pid=explode("_",$array["pid"]);
  for ($i=0;$i<count($pid);$i++)
  {
   if ($query) $query.=" OR ";
   $query.="id=".$pid[$i];
  }
  $personen=mysql_query("SELECT id, name, vname, titel FROM mi_prof WHERE ".$query);
  if (mysql_num_rows($personen))
  {
   while ($parray=mysql_fetch_array($personen))
   {
    if ($mitwirkende) $mitwirkende.=", ";
    $mitwirkende.=$parray["titel"]."&nbsp;".$parray["vname"]."&nbsp;".$parray["name"];
   }
   echo "<tr><td class=\"grau\" align=\"left\"><b>&nbsp;Mitwirkende:</b></td></tr>
         <tr><td style=\"padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;\" align=\"left\">".$mitwirkende."</td></tr>";
  }
 }

//Beginn/Ende ausgeben
 if ($array["anfang"] or $array["ende"])
   if ($array["ende"]==0) echo "<tr><td class=\"grau\" align=\"left\"><b>&nbsp;Beginn:</b></td></tr>
                                <tr><td style=\"padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;\" align=\"left\">".$array["anfang"]."</td></tr>";
   else echo "<tr><td class=\"grau\" align=\"left\"><b>Zeitraum:</b></td></tr>
              <tr><td style=\"padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;\" align=\"left\">von ".$array["anfang"]." bis ".$array["ende"]."</td></tr>";

//F�rderung ausgeben
 if ($array["foerderung"]) echo "<tr><td class=\"grau\" align=\"left\"><b>&nbsp;F&ouml;rderung:</b></td></tr>
                                 <tr><td style=\"padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;\" align=\"left\">".$array["foerderung"]."</td></tr>";

//Beschreibung ausgeben
 if ($array["beschreibung"]) 
  echo "<tr><td class=\"grau\" align=\"left\"><b>&nbsp;Beschreibung:</b></td></tr>
        <tr><td style=\"padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;\" align=\"left\">".$array["beschreibung"]."</td></tr>";

//Download-Link ausgeben 
 if ($array["anhang"] and is_readable("doc/".$array["anhang"]))  
   echo "<tr><td style=\"padding-left:10pt;padding-right:10pt;padding-bottom:10pt\" colspan=3 align=\"left\">Weitere Infos als <a href=\"doc/".$array["anhang"]."\">Download</a> (".datei_typ($array["anhang"]).", ca. ".(round(filesize("doc/".$array["anhang"])/1000))."kB)</td></tr>";  

//externen Link ausgeben
 if ($array["link"]) echo '<tr><td style="padding-left:10pt;padding-right:10pt;padding-bottom:10pt" align="left">Hier gehts zur <a href="'.$array["link"].'" target="_blank">Projekt-Homepage</a></td></tr>';

//Bild ausgeben
  if ($array["bild"]) echo "<tr><td style=\"padding-bottom:10pt\"><img src=\"img/".$array["bild"]."\"></td></tr>";

//Literatur ausgeben
 if ($array["literatur"]) echo "<tr><td class=\"grau\" align=\"left\"><b>&nbsp;Literatur:</b></td></tr>
                                <tr><td style=\"padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt;\" align=\"left\">".$array["literatur"]."</td></tr>";


 
echo "</table></center><br>";
}
}

//Ausgeben der Projekte als liste
echo "
    <center><table width=80% align=\"center\">
    <tr><th align=\"left\"><b>&nbsp;Projekte und Forschungsvorhaben</b></th></tr>";

//Laufende Projekte
$projekte=mysql_query("SELECT id, name FROM mi_forschung WHERE ende='0' ORDER BY anfang DESC");
if (mysql_num_rows($projekte))
{
 echo "<tr><td style=\"padding-left:12pt;padding-top:7pt\" align=\"left\"><b>Laufende Projekte:</b></td></tr>";
 echo "<tr><td align=\"left\"><ul>";
 while ($array=mysql_fetch_array($projekte))
 {
  echo "<div style=\"margin-top:5pt\"><li type=square>";
    if ($_SESSION["login"] == "true"){echo '
<a href="../admin/mi_forschung.php?aktion=add&nr='.$array["id"].'"><img src="../admin/img/edit_s.gif" border="0" alt="Eintrag bearbeiten" title="Eintrag bearbeiten"></a><a href="../admin/mi_forschung.php?aktion=del&nr='.$array["id"].'"><img src="../admin/img/del_s.gif" border="0" alt="Eintrag l�schen" title="Eintrag l�schen"></a>';}
  if ($id!=$array["id"]) echo "<a href=\"projekte.php?id=".$array["id"]."\">".$array["name"]."</a></li></div>";
  else echo $array["name"]."</li></div>";
 }
 echo "</ul></td></tr>";
}

//Abgeschlossene Projekte
$projekte=mysql_query("SELECT id, name FROM mi_forschung WHERE ende!='0' ORDER BY anfang DESC");
if (mysql_num_rows($projekte))
{
 echo "<tr><td style=\"padding-left:12pt;padding-top:7pt\" align=\"left\"><b>Abgeschlossene Projekte:</b></td></tr>";
 echo "<tr><td align=\"left\"><ul>";
 while ($array=mysql_fetch_array($projekte))
 {
  echo "<div style=\"margin-top:5pt\"><li type=square>";
    if ($_SESSION["login"] == "true"){echo '
<a href="../admin/mi_forschung.php?aktion=add&nr='.$array["id"].'"><img src="../admin/img/edit_s.gif" border="0" alt="Eintrag bearbeiten" title="Eintrag bearbeiten"></a><a href="../admin/mi_forschung.php?aktion=del&nr='.$array["id"].'"><img src="../admin/img/del_s.gif" border="0" alt="Eintrag l�schen" title="Eintrag l�schen"></a>';}
  if ($id!=$array["id"]) echo "<a href=\"projekte.php?id=".$array["id"]."\">".$array["name"]."</a></li></div>";
  else echo $array["name"]."</li></div>";
 }
 echo "</ul></td></tr>";
}
echo "</table></center><p align=right>"; if ($_SESSION["login"] == "true"){echo '
<a href="../admin/mi_forschung.php?aktion=add"><img src="../admin/img/new_s.gif" border="0" alt="Eintrag hinzuf�gen" title="Eintrag hinzuf�gen"></a>';} echo "</p>";

?>
