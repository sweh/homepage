<?php require_once('../config.inc'); seite(__FILE__); ?> 

<?php 

$id=$_GET["id"];
$id=intval($id);

$seite=$_GET["seite"];
$seite=intval($seite);
if ($seite==0) $seite=1;
$offset=($seite-1)*15;

$sort=$_GET["sort"];

//keine Publikations-ID �bergeben (z.b. auf Projekte in Menu-Leiste geklickt)
if ($id=='')
{
//Anzahl Publikationen ermitteln f�r Seiten-Navigation
 $pubs=mysql_query("SELECT id FROM mi_prof_publik");
 $anzahl=mysql_num_rows($pubs);
 $seitenanzahl=ceil($anzahl/15);

//Feststellen wie sortiert werden soll
  switch ($sort)
  {
   case '1': $sortby='datum ASC';break;
   case '2': $sortby='name DESC';break;
   case '3': $sortby='name ASC';break;
   default: $sortby='datum DESC';
  }

//Publikationen als Liste ausgeben
 $publikationen=mysql_query("SELECT id, datum, name FROM mi_prof_publik ORDER BY ".$sortby." LIMIT $offset,15");
 if (mysql_num_rows($publikationen))
 {
  echo '<br><center><img src="img/mi_publik.png" align="center">
        <table width=80% align="center">
        <tr><td align="left" colspan=2 style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt">Hier sind noch einmal die Publikationen der Professoren aufgelistet. Sie k&ouml;nnen sich diese auf- und absteigend, sowie alphabetisch anzeigen lassen.</td></tr>
        <tr><th width=23%>Datum <a href="publikationen.php?sort=1"><img src="img/up.gif" border=0></a><a href="publikationen.php"><img src="img/down.gif" border=0></a></th>
            <th>Name <a href="publikationen.php?sort=3"><img src="img/up.gif" border=0></a><a href="publikationen.php?sort=2"><img src="img/down.gif" border=0></a></th></tr></table>';
  echo '<table width=80% align="center">';
  while ($array=mysql_fetch_array($publikationen))
  {
   echo "<tr>";
      if ($_SESSION["login"] == "true"){echo '<td>
 <a href="../admin/mi_prof_publik.php?aktion=add&nr='.$array["id"].'"><img src="../admin/img/edit_s.gif" border="0" alt="Eintrag bearbeiten" title="Eitrag bearbeiten"></a><a href="../admin/mi_prof_publik.php?aktion=del&nr='.$array["id"].'"><img src="../admin/img/del_s.gif" border="0" alt="Eintrag l�schen" title="Eintrag l�schen"></a></td>';}
 echo "
 <td width=23% style=\"padding-left:10pt;padding-right:0pt;padding-top:5pt\" align=\"left\" valign=\"top\">".date_conf($array["datum"])."</td><td colspan=2 style=\"padding-left:0pt;padding-right:10pt;padding-top:5pt\" align=\"left\" valign=\"top\"><a href=\"publikationen.php?id=".$array["id"]."&seite=".$seite."&sort=".$sort."\">".$array["name"]."</td></tr>";
  }
  echo "</table>";

//Seiten-Navigation
  if ($seitenanzahl>1)
  {
  echo "<table cellspacing=0 align=\"center\" width=80%>
        <tr height=10><td></td></tr>
        <tr class=\"grau\"><td width=23% style=\"padding-left:10pt;padding-right:0pt\" align=\"left\">";
  if ($seite>1) echo "<a href=\"publikationen.php?seite=".($seite-1)."&sort=".$sort."\">&lt;&lt; zur&uuml;ck</a>";
  echo "</td><td align=\"center\" style=\"padding-left:10pt;padding-right:10pt\" align=\"left\">";
  for ($i=1;$i<=$seitenanzahl;$i++)
      if ($seite==$i) echo "[".$i."]&nbsp;";
      else echo "<a href=\"publikationen.php?seite=".$i."&sort=".$sort."\">[".$i."]</a>&nbsp;";
  echo "</td><td width=20% style=\"padding-left:10pt;padding-right:10pt\" align=\"right\">";
  if ($seite<$seitenanzahl) echo "<a href=\"publikationen.php?seite=".($seite+1)."&sort=".$sort."\">weitere &gt;&gt;</a>";
  echo "</td></tr></table>";
  }
  echo '</center>';
  if ($_SESSION["login"] == "true"){echo '<p align=right>
 <a href="../admin/mi_prof_publik.php?aktion=add"><img src="../admin/img/new_s.gif" border="0" alt="Eintrag hinzuf�gen" title="Eintrag hinzuf�gen"></a>';} echo"</p>";
 }
}

//Projekt-ID �bergeben, Projekt ausgeben
else
if (is_int($id))  
{  
 $publikation=mysql_query("SELECT id, datum, name, beschreibung, anhang, link FROM mi_prof_publik WHERE  id=$id");  
 if (mysql_num_rows($publikation))  
 {  
  $pubarray=mysql_fetch_array($publikation);  
  echo "<br><center><table width=80% align=\"center\"><tr><td align=\"center\">";

//Name der Publikation als Bild oder �berschrift
  $titelimg='img/mi_publik_titel_'.$id.'.png';
  if(is_readable($titelimg)) 
     echo '<img src="'.$titelimg.'" align="center" border="0" title="'.$pubarray["name"].'" alt="'.$pubarray["name"].'">'; 
  else echo '<h1 align="center">'.$pubarray["name"].'</h1>'; 
  echo '</td></tr><tr height=10><td></td></tr>'; 

//Datum der Publikation ausgeben 
  if ($pubarray["datum"])  
   echo "<tr><td class=\"grau\" colspan=2 align=\"left\"><b>&nbsp;Datum:</br></td></tr> 
        <tr><td style=\"padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt\" colspan=2 align=\"left\">".date_conf($pubarray["datum"])."</td></tr>";  

//Beteiligte an Publikation ermitteln und ausgeben 
  $prof=mysql_query("SELECT id, name, vname, titel, ende, publik_nr FROM mi_prof WHERE publik_nr LIKE '%".$id."' OR publik_nr LIKE '%_".$id."_%' OR publik_nr LIKE '".$id."_%'");  
  if (mysql_num_rows($prof))  
   while ($array=mysql_fetch_array($prof))  
   {  
    if ($beteiligte) $beteiligte.=", ";  
    $beteiligte.=$array["titel"]."&nbsp;".$array["vname"]."&nbsp;".$array["name"];  
   } 
  if ($beteiligte)  
   echo "<tr><td class=\"grau\" colspan=2 align=\"left\"><b>&nbsp;Beteiligte:</br></td></tr> 
        <tr><td style=\"padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt\" colspan=2 align=\"left\">".$beteiligte."</td></tr>";  

//Beschreibung ausgeben 
  if ($pubarray["beschreibung"])  
   echo "<tr><td class=\"grau\" colspan=2 align=\"left\"><b>&nbsp;Beschreibung:</br></td></tr> 
        <tr><td style=\"padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt\" colspan=2 align=\"left\">".$pubarray["beschreibung"]."</td></tr>";  

  //Download-Link ausgeben 
  if ($pubarray["anhang"] and is_readable("doc/".$pubarray["anhang"]))  
    echo "<tr><td style=\"padding-left:10pt;padding-right:10pt;padding-bottom:10pt\" colspan=3 align=\"left\">Weitere Infos als <a href=\"doc/".$pubarray["anhang"]."\">Download</a> (".datei_typ($pubarray["anhang"]).", ca. ".(round(filesize("doc/".$pubarray["anhang"])/1000))."kB)</td></tr>";  

//externen Link zur Publikation ausgeben 
  if ($pubarray["link"])  
    echo "<tr><td style=\"padding-left:10pt;padding-right:10pt;padding-bottom:10pt\" colspan=2 align=\"left\">Hier ein externer <a href=\"".$pubarray["link"]."\" target=\"_blank\">Link</a> zur Publikation</td></tr>";  
 
//Link zur�ck zu Publikationen ausgeben
 echo '<tr><td style="padding-left:10pt;padding-right:10pt;padding-top:10pt;padding-bottom:10pt" align="left"><a href="publikationen.php?seite='.$seite.'&sort='.$sort.'">&lt;&lt; zur&uuml;ck zur �bersicht Publikationen</a></td></tr>';

 echo "</table></center>";

 }  
}  


?>
