<?php
/**********************************/
/* Funktionen f�r den Studenplaner*/
/*  By stanja                     */
/*  31.05.2004                    */
/**********************************/

/************************/
/* standart Funktionen */
/**********************/

//wandelt woche in eine Zahl um
function getwoche_nummer($woche)
        {
        switch($woche)
                {
                case 'immer':    return 0;
                                 break;
                case 'ungerade': return 1;
                                 break;
                case 'gerade':   return 2;
                                 break;
                }
        }

//Ermittelt die Veranstaltungsnummer
function getVeranstaltungsnummer($veranstaltungs_zeit_id)
        {
         $string = "SELECT vstg_art_id FROM veranstaltung_art_termine WHERE id = $veranstaltungs_zeit_id";
         $datensatz = mysql_query($string);
         list($vstg_art_id) = mysql_fetch_row($datensatz);

         $string = "SELECT vstg_id FROM veranstaltung_art WHERE id = $vstg_art_id";
         $daten = mysql_query($string);
         list($nummer) = mysql_fetch_row($daten);

         return $nummer;
        }

function getTag($tag)
        {
        switch($tag)
                {
                case "Mo":        return "Montag";
                                break;
                case "Di":        return "Dienstag";
                                break;
                case "Mi":        return "Mittwoch";
                                break;
                case "Do":        return "Donnerstag";
                                break;
                case "Fr":        return "Freitag";
                                break;
                }
        }

function getWoche_format($woche)
        {
        switch ($woche)
                {
                case 'ungerade':        return '1';
                                        break;
                case 'immer' :                break;
                case 'gerade':                return '2';
                                        break;
                }
        }

function getEinheit($zeit, $dauer)
        {
        $einheit = 0;

        switch ($zeit)
                {
                case 1:        $einheit = '7:30 - ';
                        if ($dauer == 1)
                                {
                                $einheit = $einheit.'9:00';
                                return $einheit;
                                break;
                                }
                        $dauer = $dauer - 1;

                case 2: if($einheit == 0)
                                {
                                $einheit = '9:15 - ';
                                }
                        if($dauer == 1)
                                {
                                $einheit = $einheit.'10:45';
                                return $einheit;
                                break;
                                }
                        $dauer = $dauer - 1;

                case 3: if($einheit == 0)
                                {
                                $einheit = '11:30 - ';
                                }
                        if($dauer == 1)
                                {
                                $einheit = $einheit.'13:00';
                                return $einheit;
                                break;
                                }
                        $dauer = $dauer - 1;

                case 4: if($einheit == 0)
                                {
                                $einheit = '13:45 - ';
                                }
                        if($dauer == 1)
                                {
                                $einheit = $einheit.'15:15';
                                return $einheit;
                                break;
                                }
                        $dauer = $dauer - 1;

                case 5: if($einheit == 0)
                                {
                                $einheit = '15:30 - ';
                                }
                        if($dauer == 1)
                                {
                                $einheit = $einheit.'17:00';
                                return $einheit;
                                break;
                                }
                        $dauer = $dauer - 1;

                case 6: if($einheit == 0)
                                {
                                $einheit = '17:15 - ';
                                }
                        $einheit = $einheit.'20:30';
                        return $einheit;
                        break;
                }
        }


function warenkorb($sessionid, $nummer)
        {
	 if (($nummer != 'modul') AND ($nummer != 'absenden'))
		{
		$string = "SELECT id FROM veranstaltung_art_termine WHERE vstg_nr=$nummer";
		$daten = mysql_query($string);
		while(list($vstg_zeit_id) = mysql_fetch_row($daten))
			{
			//jetzt in den Warenkorb legen	
			inWarenkorb($sessionid, $vstg_zeit_id);
			}
		}
        }

function bezeichner($einheit, $tag)
        {
        switch ($tag)
                {
                 case 1: return 'Mo'.$einheit;
                         break;
                 case 2: return 'Di'.$einheit;
                         break;
                 case 3: return 'Mi'.$einheit;
                         break;
                 case 4: return 'Do'.$einheit;
                         break;
                 case 5: return 'Fr'.$einheit;
                         break;
                }
        }

function getArtID($zeit_id)
        {
         $string = "SELECT vstg_art_id FROM veranstaltung_art_termine WHERE id = $zeit_id";
         $datensatz = mysql_query($string);
         list($id) = mysql_fetch_row($datensatz);

         return($id);
        }

function getName($vstg_id)
        {
         $string = "SELECT name FROM veranstaltung WHERE id=$vstg_id";
         $daten = mysql_query($string);
         list($name) = mysql_fetch_row($daten);

           return $name;
        }

function getArt($vstg_art_id)
        {
         $string = "SELECT art FROM veranstaltung_art WHERE id=$vstg_art_id";
         $daten = mysql_query($string);
         list($art) = mysql_fetch_row($daten);

         return $art;
        }

function getRaum($vstg_zeit_id)
        {
         $string = "SELECT raum FROM veranstaltung_art_termine WHERE id=$vstg_zeit_id";
         $daten = mysql_query($string);
         list($raum) = mysql_fetch_row($daten);

          return $raum;
        }

/*************************************/
/* MODUL Einf�gen in den Wochenplan */
/***********************************/


//Ermittelt wieviel Veranstaltungen bereits zur gleichen Zeit gespeichert sind
function getAnzahl($wochenplan, $name, $woche)
        {
        $anzahl = 1;
        while($wochenplan[$name][$woche][$anzahl]) $anzahl++;

        return $anzahl;
        }


//Veranstaltung in den Wochenplan hinzuf�gen
function hinzufuegenWochenplan(&$wochenplan, $nummer)
        {
        /*Daten aus der Datanbank holen*/
        $string = "SELECT tag, woche, einheit, dauer FROM veranstaltung_art_termine WHERE id = $nummer";
        $datensatz = mysql_query($string);
        list($tag, $woche, $einheit, $dauer) = mysql_fetch_row($datensatz);

        /*Woche in worten, wie zum Beispiel 'immer' in eine Zahl umwandeln, also 0*/
        $woche = getwoche_nummer($woche);

        /*Geht eine Veranstaltung �ber mehrere Einheiten, dann wird sie f�r jede Eineheit gesondert eingetragen*/
        /*also z�hlt die Schleife von 0 bis zum ende der Dauer*/
        for ($n = 0; $n < $dauer; $n++)
                {
                /* Bezeichnung in der folgenden Form: Tag/Einheit:
                   MO1 w�rde also hei�en Montag, 1. Einheit*/
                $name = $tag.$einheit;
                $einheit++;                        /*Falls die Veranstaltung �ber mehrere Einheiten geht*/

                switch($woche)
                        {
                        case 0:        /*Jede Woche, also ungerade und gerade woche testen*/
                                $anzahl_geradeWoche = getAnzahl($wochenplan, $name, 2);
                                $anzahl_ungeradeWoche = getAnzahl($wochenplan, $name, 1);

                                $wochenplan[$name][1][$anzahl_ungeradeWoche] = $nummer;        /*ungerade Woche eintragen*/
                                $wochenplan[$name][2][$anzahl_geradeWoche] = $nummer; /*gerade Woche eintragen*/
                                break;

                        case 1: $anzahl_ungeradeWoche = getAnzahl($wochenplan, $name, 1);
                                $wochenplan[$name][1][$anzahl_ungeradeWoche] = $nummer;
                                break;

                        case 2: $anzahl_geradeWoche = getAnzahl($wochenplan, $name, 2);
                                $wochenplan[$name][2][$anzahl_geradeWoche] = $nummer;
                                break;
                        }

                }
        return $wochenplan;
        }

/*************************************/
/* MODUL Einf�gen der Veranstaltung */
/***********************************/

//Wurden bereits alle Veranstaltungen hinzugef�gt, muss nur noch zu der aktuell
//ausgew�hlten Veranstaltung das Bit gesetzt werden

function setAuswahl(&$veranstaltung, $nummer, $vstg_id, $i)
        {
        $string = "Select vstg_art_id FROM veranstaltung_art_termine WHERE id = $nummer";
        $datensatz = mysql_query($string);
        list($art_id) = mysql_fetch_row($datensatz);

        $daten = mysql_query("SELECT art FROM veranstaltung_art WHERE id= $art_id");
        list($art) = mysql_fetch_row($daten);

        $j = 0;
        $akt_nummer = 0;
        while($nummer != $akt_nummer)
                {
                $j = $j + 1;
                $akt_nummer = $veranstaltung[$i][$art][$j]["nummer"];
                }
        $veranstaltung[$i][$art][$j]["auswahl"] = 1;
        return $veranstaltung;
        }


/*F�gt alle Veranstaltungen hinzu, die zu dieser ausgew�hlten Veranstaltung geh�ren*/

function hinzufuegenVeranstaltungen(&$Veranstaltung, $nummer)
        {
        /*Hauptnummer ermitteln = vstg_id*/
        $vstg_id = getVeranstaltungsnummer($nummer);
        $anzahl_eintraege = count($Veranstaltung) + 1;	

        /*Gibt es diese Veranstaltung schon einmal?*/
        for ($i = 0; $i < $anzahl_eintraege; $i++)
                {
		$enthalten = false;
                if ($Veranstaltung[$i]["haupt"][1]["nummer"] == $vstg_id)
                        {
                        /*Diese Veranstaltung wurde bereits eingetraen*/
                         setAuswahl($Veranstaltung, $nummer, $vstg_id, $i);
			 $enthalten = true;	
                        }
		if ($enthalten) return $Veranstaltung;
                }

        /* Wieviel Vorlesungen sind schon gespeichert? */

        $Veranstaltung[$anzahl_eintraege]["haupt"][1]["nummer"] = $vstg_id;
        $Veranstaltung[$anzahl_eintraege]["haupt"][1]["auswahl"] = 1;

        /*Was f�r Veranstaltungen werden angeboten?*/
        $string = "SELECT id, art FROM veranstaltung_art WHERE vstg_id = $vstg_id";
        $datensatz = mysql_query($string);
        while(list($vstg_art_id, $art) = mysql_fetch_row($datensatz))
                {
                /*Alle Veranstaltungen dieser Art suchen*/
                $string = "SELECT id FROM veranstaltung_art_termine WHERE vstg_art_id = $vstg_art_id";
                $daten = mysql_query($string);
                $i = 1;
                while(list($id) = mysql_fetch_row($daten))
                        {
                        $Veranstaltung[$anzahl_eintraege][$art][$i]["nummer"] = $id;
                        if($id == $nummer) { $Veranstaltung[$anzahl_eintraege][$art][$i]["auswahl"] = 1; }
                        else  {$Veranstaltung[$anzahl_eintraege][$art][$i]["auswahl"] = 0; }
                        $i++;
                        }
                }
        return $Veranstaltung;
        }

/*************************************/
/* MODUL Ausgabe der Auswahl        */
/***********************************/

function test_ueberschneidung($wochenplan, $tag, $einheit, $woche)
        {
         $bezeichner = $tag.$einheit;
         if ($wochenplan[$bezeichner][getwoche_nummer($woche)][2])
                {
                return 1;
                }
        }

function anzeige($Veranstaltung, $wochenplan, $nummer, $art)
        {
         $anzahl = count($Veranstaltung[$nummer][$art]) + 1;
         if ($anzahl > 1)
                {
                echo "<tr><td>mit $art: <br></td></tr>";
                }
         echo '<tr><td>';
         echo '<menu>';
	 $test = false;    
      	 $testgerade = false;
	 $testungerade = false;
	 
	 for ($i = 1; $i < $anzahl; $i++)
                {
                 $vstg_zeit_id = $Veranstaltung[$nummer][$art][$i]["nummer"];
                 $string = "SELECT vstg_nr, tag, woche, einheit, raum, dauer FROM veranstaltung_art_termine WHERE id = $vstg_zeit_id";
                 $datensatz = mysql_query($string);
                 list($vstg_nr, $tag, $woche, $einheit, $raum, $dauer) = mysql_fetch_row($datensatz);
                 echo '<input type="checkbox" name="'.$vstg_nr.'" value="1" ';
                 if ($Veranstaltung[$nummer][$art][$i]["auswahl"] == '1')
                         { 
			  echo 'checked'; 
			 }

                 echo '>';
		 echo '<input type="hidden" name="'.$vstg_nr.'"value="e">';

                 if ($Veranstaltung[$nummer][$art][$i]["auswahl"] == '1')
                         {
                         $testeinheit = $einheit;
			 $tdauer = $dauer;
                         while(($tdauer > 0) AND ($test != true))   //bei l�ngerer dauer m�ssen alle einheiten getestet werden
                                 {
                                 if ($woche == 'immer')
                                        {
                                         //es wird jede woche angeboten, also woche 1 und woche 2 testen.
					 if ((test_ueberschneidung($wochenplan, $tag, $testeinheit, 'gerade') == 1) OR 
					     (test_ueberschneidung($wochenplan, $tag, $testeinheit, 'ungerade') == 1))
						$test = 1; 					
                                        }
                                 else
                                        {
                                        if (test_ueberschneidung($wochenplan, $tag, $testeinheit, $woche) == 1)
						$test = 1;
                                        }

                                 $testeinheit = $testeinheit + 1;
                                 $tdauer = $tdauer - 1;
                                 }
                         if ($test == true) {echo '<span style="color:red">'; }
                              }
                echo getTag($tag).getWoche_format($woche)." ".getEinheit($einheit, $dauer)." ".$raum."<br>";

                if ($test)
                        {
                        echo "</span>";
                        $ueberschneidung = true;
                        }

                $test = false;
                }

         echo "</menu></td></tr>";
         if ($ueberschneidung) {return true;}
        }


function ausgabe($Veranstaltung, $wochenplan)
        {
         $anzahl_eintraege = count($Veranstaltung) + 1;

         echo '<table>';

         for($i = 1; $i < $anzahl_eintraege; $i++)
                {
                $vstg_id = $Veranstaltung[$i]["haupt"][1]["nummer"];
                $string = "SELECT name, fak, prof FROM veranstaltung WHERE id = $vstg_id";
                $datensatz = mysql_query($string);
                list($veranstaltungsname, $fakultaet, $prof) = mysql_fetch_row($datensatz);
                echo '<tr><td class="grau">';
                echo '<b>'.$veranstaltungsname.' </b> '.$prof.'</td></tr><tr><td><br></td></tr>';
                $testVorlesung = anzeige($Veranstaltung, $wochenplan, $i, "Vorlesung");
                $tesstUebung   = anzeige($Veranstaltung, $wochenplan, $i, "Uebung");
                $testPraktikum = anzeige($Veranstaltung, $wochenplan, $i, "Praktikum");
                $testSeminar   = anzeige($Veranstaltung, $wochenplan, $i, "Seminar");

                if(($testVorlesung) OR ($testUebung) OR ($testPraktikum) OR ($testSeminar))
                        {
                        $fehler = true;
                        }
                }

        echo '<tr><td><input type="submit" name="absenden" value="planen"></td></tr>';
        echo '</table>';
        if ($fehler) {return true; }
        }

/*************************************/
/* MODUL Ausgabe des Stundenplans   */
/***********************************/

function stundenplan($wochenplan, $woche)
        {
?>
        <table width=100% align="center">
        <tr align="center" bgcolor="#319A9C"><td width="80"><b>Zeit</b></td>
                    <td><b>Montag</b></td>
                  <td><b>Dienstag</b></td>
                    <td><b>Mittwoch</b></td>
                    <td><b>Donnerstag</b></td>
                    <td><b>Freitag</b></td></tr>

        <?php
        for($i=1; $i<7; $i++)  //es gibt 6 einheiten
                {
                echo '<tr>';
                echo '<td align="center" bgcolor="#319A9C">'.getEinheit($i, 1).'</td>';
                for ($j=1; $j<6; $j++)  //es gibt 5 tage
                        {
                         echo '<td align="center" class="grau">';
                         $vstg_zeit_id = $wochenplan[bezeichner($i, $j)][$woche][1];
                         $vstg_art_id = @getArtID($vstg_zeit_id);
                         $vstg_id = @getVeranstaltungsnummer($vstg_zeit_id);
                         echo @getArt($vstg_art_id).'<br>';
                         echo '<b>'.@getName($vstg_id).'</b><br>';
                         echo @getRaum($vstg_zeit_id);
                         echo '</td>';
                        }
                echo '</tr>';
                }
        ?>
        </table>
<?php
        }
?>
