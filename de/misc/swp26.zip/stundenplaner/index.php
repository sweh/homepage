<?php

/**************************************************************************/
/* Stundenplaner                                                          */
/* By stanja                                                                  */
/*                                                                          */
/*Bemerkung:                                                                  */
/*                                                                          */
/*Der Stundenplaner bassiert auf zwei Arrays. In das eine (Wochenplan)   */
/*werden die                                                                  */
/*einzelnen Veranstaltungen nach Tag, und Einheit gespeichert.            */
/* Beispiel: wochenplan[Mo1][2][1] = 12345;   */
/*bedeutet: die Veranstaltung 12345 findet Montag in der 1. Einheit, in jeder geraden   */
/*Woche statt und wurde an stelle 1 eingetragen.  */
/*            */
/*Das 2. Array, mit dem Namen Veranstaltung speichert alle Veranstaltungen, die zu der*/
/*gew�hlten geh�ren.                                  */
/* Beispiel: Veranstaltung[1]["Vorlesung"][1]["nummer"] = 001;
/*bedeutet: die Veranstaltung wurde an 1. stelle gespeichert. Es handelt sich um eine Vorlesung. */
/*die erste davon hat die nummer 001 */
/**************************************************************************************/




// Mysql-Verbindung herstellen

//$mysql_vbg = @mysql_connect("mysql.hrz.tu-chemnitz.de", "sweh", "swp_vlz");
//$mysql_status = @mysql_select_db("swp_vlz", $mysql_vbg);

//if (!$mysql_status)
//  die("Es konnte keine Verbindung zur Datenbank aufgebaut werden. Bitte �berpr�fen Sie die Einstellungen!");

//require_once('../config.inc'); seite(__FILE__);
//require_once('../includes/globals.inc.php');

include("function.php");
echo '<center><img src="icons/stundenplaner_titel.gif"></center><br><br>';
//getSessionid;
$Sessionid = session_id();

if($_GET['plan'])  //der stundenplan soll angezeigt werden
        {
        $string = "SELECT `vstg_art_termin_id` FROM `warenkorb` WHERE `sessionid` = '$Sessionid'";
        $datensatz = mysql_query($string);

        while(list($vstg_art_termin_id) = mysql_fetch_row($datensatz))
                {
                $wochenplan = hinzufuegenWochenplan($wochenplan, $vstg_art_termin_id);
                }

        echo 'gerade Woche:';
        stundenplan($wochenplan, 2);
        echo 'ungerade Woche:';
        stundenplan($wochenplan, 1);
        }

else
        {
	$erwartet = 0;
        $query_string = $_SERVER['QUERY_STRING'];
	
        $teil_string = explode("&", $query_string);	
	
        foreach ($teil_string as $teil)
                {
		$nummer = strtok($teil, "=");
		$value = strtok("=");
		switch($value)
		  {
		  case 'e':	if ($erwartet == 1) 
					{
					$erwartet = 0;
					break;
					}
				else 
			   		{
			   		$string = "SELECT id FROM veranstaltung_art_termine WHERE vstg_nr=$nummer";
			   		$daten = mysql_query($string);
			   		while(list($vstg_zeit_id) = mysql_fetch_row($daten))
						{	
						l�scheWarenkorb($Sessionid, $vstg_zeit_id); 
						}
			   		}
				break;
		   
		  case '1':	$erwartet = 1;
				warenkorb($Sessionid, $nummer);
		  }
                }

        $string = "SELECT `vstg_art_termin_id` FROM `warenkorb` WHERE `sessionid` = '$Sessionid'";
        $datensatz = mysql_query($string);
	$anzahl = mysql_num_rows($datensatz);
	if($anzahl == 0)
		{?>
		<table width=80% align="center"> 
		<tr><td class="grau"><b>Sinn und Zweck</b></td></tr> 
		<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt"> 
			Mit diesem Tool soll die Planung Eures pers�nlichen Stundenplans unkomplizierter, schneller und damit 
			effektiver von statten gehen. L�stiges Nachschlagen und Abschreiben im Vorlesungsverzeichnis sollte 
			damit der Vergangenheit angeh�ren.  
		</td></tr> 
		<tr><td class="grau"><b>Benutzung</b></td></tr> 
		<tr><td style="padding-left:10pt; padding-right:10pt; padding-top:10pt; padding-bottom:10pt"> 
		Die Verwendung des Stundenplaners ist denkbar einfach. W�hle einfach im Vorlesungsverzeichnis die gew�nschten 
		Lehrveranstaltungen aus. Diese kannst du dann �ber "hinzuf�gen" in den Stundenplaner legen. Hast du dir alle
		Veranstaltungen zusammengesammelt, so kannst du in den Stundenplaner wechseln und dir hier anschauen, welche 
		Veranstaltungen die gew�hlt hast und ob sie sich �berschneiden... 
		</td></tr> 
		</table> 
<?php
		}
	else
		{	
        	while(list($vstg_art_termin_id) = mysql_fetch_row($datensatz))
                	{
   	                $wochenplan = hinzufuegenWochenplan($wochenplan, $vstg_art_termin_id);
        	        $veranstaltung = hinzufuegenVeranstaltungen($veranstaltung, $vstg_art_termin_id);
                	}

  	      	echo '<form action="index.php" method="get">';
	
		echo '<input type="hidden" name="modul" value="splan">';

		echo '<table width=80% align="center"><tr><td>';	
        	$fehler = ausgabe($veranstaltung, $wochenplan);
	
        	if (($_GET['absenden']) AND ($fehler != true))  //Der Stundenplan kann jetzt erstellt werden
                	{
                	echo '<input type="submit" name="plan" value="jetzt Stundenplan anzeigen">';
                	}
		echo '</td></tr></table>';

        	echo '</form>';
        	}
	}
?>
