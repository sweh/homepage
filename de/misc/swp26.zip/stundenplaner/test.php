<?php
include('function.php');

test();
?>
