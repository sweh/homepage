<?php
//***************************************
// Funktionen f�r Vorlesungsverzeichnis
//***************************************

// Liefert Studiengangname und dazugeh�rigen Fakult�ts_ID zur�ck
function GetStud_name ($stud_id)
{
	$studiengang=mysql_query("SELECT name, fak_id FROM studiengang WHERE id='$stud_id' LIMIT 1");
	if (mysql_num_rows($studiengang)) 
	{
		$array_stud=mysql_fetch_array($studiengang);
		return $array_stud;
	}
	else return false;
}

// Liefert Fakult�tsname zur�ck
function GetFak_name ($fak_id)
{
	$fakultaet=mysql_query("SELECT name FROM fakultaet WHERE id='$fak_id' LIMIT 1");
	if (mysql_num_rows($fakultaet))
	{
		$array_fak=mysql_fetch_array($fakultaet);
		return $array_fak["name"];
	}
	else return false;
}

// Liefert Veranstaltungsnamen zur�ck
function GetVstg_name ($vstg_id)
{
	$veranstaltung=mysql_query("SELECT name FROM veranstaltung WHERE id='$vstg_id' LIMIT 1");
	if (mysql_num_rows($veranstaltung))
	{
		$vstg_array=mysql_fetch_array($veranstaltung);
		return $vstg_array["name"];
	}
	else return false;
}

// Liefert Anfangsbuchstaben der Veranstaltungsart zur�ck 
// (Vorlesung=V, �bung=�, Seminar=S, Praktikum=P)
function Abk_vstg_art ($vstg_art)
{
	switch ($vstg_art)
	{
		case 'Vorlesung': return 'V';
		case 'Uebung'	: return '�';
		case 'Seminar'	: return 'S';
		case 'Praktikum': return 'P';
		default			: return false;
	}
}

// Liefert den Wochentag mit Angabe ungerade/gerade
// (z.B. Mo1 , Di2)
function Wochentag ($tag, $woche)
{
	switch ($woche)
	{
		case 'ungerade'	: return $tag.'1';
		case 'gerade'	: return $tag.'2';
		default			: return $tag;
	}
}

// Liefert Veranstaltungszeit zur�ck
// (z.B. 9.15-10.45)
// �bergeben wird Einheit in der die Vstg beginnt und wieviele Einheiten sie dauert
function Zeitspanne ($einheit, $anz_einheiten)
{
	$beginn=array('7:30-','9:15-','11:30-','13:45-','15:30-','17:15-','19:00-',);
	$ende=array('9:00','10:45','13:00','15:15','17:00','18:45','20:30');
	return $beginn[$einheit-1].$ende[$einheit+$anz_einheiten-2];
}

// Liefert Veranstaltungszeit zur�ck
// �bergeben wird vstg_art_termine_id 
function Zeit_Ausnahmen ($vstg_art_termine_id)
{
	$ausnahme=mysql_query("SELECT begin, ende FROM veranstaltung_art_termine_ausnahmen WHERE vstg_art_termine_id='$vstg_art_termine_id'");
	if (mysql_num_rows($ausnahme))
	{
		$ausnahme_array=mysql_fetch_array($ausnahme);
		$beginn=$ausnahme_array["begin"];
		$ende=$ausnahme_array["ende"];
		return date("G:i",$beginn).'-'.date("G:i",$ende);
	}
	else return false;
}

// Liefert Veranstaltungsdatum zur�ck
// �bergeben wird vstg_art_termine_id
function Datum_Ausnahmen ($vstg_art_termine_id)
{
	$ausnahme=mysql_query("SELECT begin, ende FROM veranstaltung_art_termine_ausnahmen WHERE vstg_art_termine_id='$vstg_art_termine_id'");
	if (mysql_num_rows($ausnahme))
	{
		$ausnahme_array=mysql_fetch_array($ausnahme);
		$beginn=$ausnahme_array["begin"];
		$beginn=date("d.m.y",$beginn);
		$ende=$ausnahme_array["ende"];
		$ende=date("d.m.y",$ende);
		if ($beginn==$ende)
			return $beginn;
		else return $begin.'-'.$ende;
	}
	else return false;	
}

?>