<?php 

include ('vorlesungsverzeichnis.php');

$fak_id=intval($_GET["fak"]); 
$stud_id=intval($_GET["stud"]); 
$semester=intval($_GET["sem"]); 
$anz=$_GET["anz"]; 

echo '<center><img src="icons/vlvz_titel.gif">
      <table width=80%>'; 


if (!empty($fak_id)) 
    if ($anz=='komm') 
	{	// Anzeigen des Kommentierten Vorlesungsverzeichnisses
		echo '
		<tr>
			<td>'; 
        kommentiertes($fak_id); 
		echo '</td>
		</tr>';
	}
    else 
    {   // Auflisten aller Studieng�nge einer Fakult�t
        echo '
        <tr>
			<td>Hier k&ouml;nnen Sie auch das <a href="index.php?modul=vlz&anz=komm&fak='.$fak_id.'">Komentierte Vorlesungsverzeichnis</a> anzeigen lassen.</td>
		</tr>
		<tr>
			<td style="padding-top:10pt"><b>Studieng&auml;nge:</b></td>
		</td>
        <tr>
			<td>';
		studiengaenge($fak_id);
		echo '</td>
		</tr>';
	}
else 
    if (!empty($stud_id) and !empty($semester)) 
    {   // Auflisten aller Veranstaltungen eines Studienganges 
        veranstaltungen($stud_id,$semester);
        echo '<p align=right><a href="index.php?modul=splan"><img src="icons/stundenplaner.gif" border=0 alt="Zum Stundenplaner"></a></p>';
	}
    else 
    { 
        // Auflisten aller Fakultaeten 
        echo '
        <tr>
			<td>Hier finden Sie das Vorlesungsverzeichnis mit integrierten Stundenplaner. W&auml;hlen Sie die gew�nschten Veranstaltungen f&uuml;r den Stundenplaner aus dem angebotenen Vorlesungsverzeichnis aus.</td>
		</tr>
        <tr>
			<td style="padding-top:10pt">W&auml;hlen Sie eine Fakult&auml;t:</td>
		</tr>
        <tr>
			<td>';
		fakultaeten();
		echo '</td>
		</tr>';
    } 

echo '</table></center>';

?> 
