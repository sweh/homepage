<?php

//-------------------------------------------------------------------
//*******************************************************************
//* Modul f�r das Vorlesungsverzeichnis								*
//* enthalten:	- Fakult�ten auflisten								*
//*				- Studieng�nge einer Fakult�t auflisten				*
//*				  (Parameter: Fakult�ts-ID)							*
//*				- Veranstaltungen f�r einen Studiengang auflisten	*
//*				  (Parameter: Studiengang-ID,Semester)				*
//*				- kommentiertes Vorlesungsverzeichnis einer Fakult�t*
//*				  (Parameter: Fakult�ts-ID)							*
//*******************************************************************
//-------------------------------------------------------------------

include ('functions.php');

// Auflisten aller Fakult�ten
// Brauch keine �bergebenen Parameter
function fakultaeten ()
{
	$faks=mysql_query("SELECT id, name FROM fakultaet"); 
    if (mysql_num_rows($faks)) 
    { 
		echo '<ul>'; 
		while($array=mysql_fetch_array($faks)) 
  		     echo '<li><a href="index.php?modul=vlz&fak='.$array["id"].'">'.$array["name"].'</a></li>'; 
		echo '</ul>'; 
	} 
	return 0;
}


// Auflisten aller Studieng�nge zu einer Fakult�t
// �bergeben der Fakult�ts-ID
function studiengaenge ($fak_id)
{
	$fak_id=intval($fak_id);
    // Studiengang_ID ermitteln 
    $studiengang=mysql_query("SELECT id, name FROM studiengang WHERE fak_id='$fak_id'"); 
    if (mysql_num_rows($studiengang)) 
    { 
        while ($stud_array=mysql_fetch_array($studiengang)) 
        { 
            // f�r jeden Studiengang die Semester ermitteln 
            $sem_count=array(0,0,0,0,0,0,0,0,0,0,0,0); 
            $stud_id=$stud_array["id"]; 
            $semester=mysql_query("SELECT sem FROM studiengang_vstg WHERE studgang_id='$stud_id'"); 
            if (mysql_num_rows($semester))
                while ($sem_array=mysql_fetch_array($semester)) 
                    $sem_count[$sem_array["sem"]]=$sem_array["sem"]; 
            echo '<ul>'; 
            foreach ($sem_count as $elem) 
                if ($elem!=0) 
                    // Ausgabe: "<Studiengang> <Semesterzahl>. Semester" 
                    echo '<li><a href="index.php?modul=vlz&stud='.$stud_array["id"].'&sem='.$elem.'">'.$stud_array["name"].' '.$elem.'. Semester</a></li>'; 
            echo '</ul>';
        } 
    }
    else echo 'Keine Studieng&auml;nge vorhanden.'; 
    return 0;
}


// Erstellt Tabelle der angebotenen Veranstaltungen f�r einen Studiengang
// �bergeben der Studiengang-ID und des Semesters
function veranstaltungen ($stud_id,$semester)
{
	$stud_id=intval($stud_id);
	$semester=intval($semester);
	
	// Veranstaltung zum Warenkorb hinzuf�gen
	$terminid=intval($_GET["terminid"]);
	$s_id=session_id();
	if ($terminid)
	{
		if ($_GET["aktion"]=='insert')
			$ausgabe=inWarenkorb($s_id,$terminid);
		else if ($_GET["aktion"]=='delete')
			 {
				loescheWarenkorb($s_id,$terminid);
				$ausgabe='Veranstaltung aus Stundenplaner gl&oumlscht.';
			 }
		if ($ausgabe=='OK')
			$ausgabe='Veranstaltung zum Stundenplaner hinzugef&uuml;gt.';
		else
			if ($ausgabe=='DOPPELT')
				$ausgabe='Veranstaltung bereits zum Stundenplaner hinzugef&uuml;gt.';
			else 
				if ($ausgabe=='FEHLER')
					$ausgabe='Es ist ein Fehler aufgetreten.';
	} 
	
	// Auslesen der bereits im Warenkorb enthaltenen Veranstaltungen (als Array)
	$vstg_warenkorb=ausWarenkorb($s_id);
	
    // Name des Studiengangs auslesen 
    $stud_array=GetStud_name($stud_id); 
    if ($stud_array)  
    {     
        $stud_name=$stud_array["name"]; 
        $fak_id=$stud_array["fak_id"]; 
        // Name der dazugeh�rigen Fakult�t 
        $fak_name=GetFak_name($fak_id); 
        if ($fak_name) 
        { 
            echo '<h1>Fakult&auml;t '.$fak_name.'</h1> 
                  <h5>Vorlesungsverzeichnis f�r Studiengang '.$stud_name.' '.$semester.'.Semester</h5>';
			echo $ausgabe; 
             
// Veranstaltungen f�r Studiengang auflisten 

            // alle Veranstaltungen zum Studiengang durchgehen 
            $veranstaltungen=mysql_query("SELECT vstg_id FROM studiengang_vstg WHERE studgang_id='$stud_id' and sem='$semester'"); 
            if (mysql_num_rows($veranstaltungen)) 
            { 
                echo '<table width=100%>'; 
                while ($array_vstg=mysql_fetch_array($veranstaltungen)) 
                { 
                    // alle Veranstaltungsarten einer Veranstaltungen durchgehen 
                    $dunkler=0; 
                    $vstg_id=$array_vstg["vstg_id"]; 
                    $vstg_art=mysql_query("SELECT id, art, sws FROM veranstaltung_art WHERE vstg_id='$vstg_id' ORDER BY art ASC"); 
                    if (mysql_num_rows($vstg_art)) 
                    { 
                        while ($vstg_art_array=mysql_fetch_array($vstg_art)) 
                        { 
                            // Veranstaltungsname, Veranstaltungsart und SWS 
                            $vstg_name=GetVstg_name($vstg_id); 
                            $vstg_art_id=$vstg_art_array["id"]; 
                            $vstg_art_abk=Abk_vstg_art($vstg_art_array["art"]);  
                            $count=0; 
                             
                            // alle Veranstaltungen einer Veranstaltungsart durchgehen 
                            $vstg_art_termin=mysql_query("SELECT id, vstg_nr, tag, woche, einheit, raum, status, dauer, leiter FROM veranstaltung_art_termine WHERE vstg_art_id='$vstg_art_id' ORDER BY vstg_nr ASC"); 
                            if (mysql_num_rows($vstg_art_termin)) 
                            { 
                                while ($vstg_art_termin_array=mysql_fetch_array($vstg_art_termin)) 
                                { 
                                    // Veranstaltungsnr., Raum, Wochentag, Zeit 
									$termin_id=$vstg_art_termin_array["id"];
                                    $vstg_nr=$vstg_art_termin_array["vstg_nr"]; 
                                    $leiter=$vstg_art_termin_array["leiter"]; 
                                    $raum=$vstg_art_termin_array["raum"];
									$sws=$vstg_art_termin_array["dauer"]*2;
                                    $tag=Wochentag($vstg_art_termin_array["tag"], $vstg_art_termin_array["woche"]); 
                                    $dauer=$dauer+$vstg_art_termin_array["dauer"]; 
                                    if ($vstg_art_termin_array["einheit"]!='') 
                                        $zeit=Zeitspanne($vstg_art_termin_array["einheit"], $vstg_art_termin_array["dauer"]); 
                                    else  
                                        $zeit=Zeit_Ausnahmen ($vstg_art_termin_array["id"]); 
                                     
// Ausgabe der Veranstaltungen eines Studiengangs 
                                    if ($count==0)     // Initialisieren der Ausgabewerte beim ersten Durchlauf 
                                    { 
                                        $vstg_nr_prev=$vstg_nr; 
                                        $vstg_name_prev=$vstg_name; 
                                        $vstg_art_abk_prev=$vstg_art_abk; 
                                        $sws_prev=$sws; 
                                        $leiter_prev=$leiter; 
                                        $tag_prev=$tag; 
                                        $zeit_prev=$zeit; 
                                        $raum_prev=$raum;
										if (in_array($termin_id,$vstg_warenkorb))
											$link='<a href="'.$_SERVER["PHP_SELF"].'?modul=vlz&stud='.$stud_id.'&sem='.$semester.'&terminid='.$termin_id.'&aktion=delete">l�schen</a>';
										else
											$link='<a href="'.$_SERVER["PHP_SELF"].'?modul=vlz&stud='.$stud_id.'&sem='.$semester.'&terminid='.$termin_id.'&aktion=insert">hinzuf�gen</a>';										
                                    } 
                                    else 
                                        if ($vstg_nr==$vstg_nr_prev) // Ausgabewerte erweitern solange gleich Veranstaltungsnr. 
                                        {     
                                            $sws_prev=$sws_prev+$sws; 
                                            $leiter_prev=$leiter_prev.'<br>'.$leiter; 
                                            $tag_prev=$tag_prev.'<br>'.$tag; 
                                            $zeit_prev=$zeit_prev.'<br>'.$zeit; 
                                            $raum_prev=$raum_prev.'<br>'.$raum;
											if (in_array($termin_id,$vstg_warenkorb))
												$link=$link.'<br><a href="'.$_SERVER["PHP_SELF"].'?modul=vlz&stud='.$stud_id.'&sem='.$semester.'&terminid='.$termin_id.'&aktion=delete">l�schen</a>'; 
											else
												$link=$link.'<br><a href="'.$_SERVER["PHP_SELF"].'?modul=vlz&stud='.$stud_id.'&sem='.$semester.'&terminid='.$termin_id.'&aktion=insert">hinzuf�gen</a>'; 
                                        } 
                                        else 
                                        { 
                                            if ($dunkler==0)    // Erster Veranstaltungsarteintrag wird dunkelgrau hinterlegt 
                                                $zeilenfarbe='c0c0c0'; 
                                            else  
                                            {    $zeilenfarbe='eeeeee'; 
                                                switch ($vstg_art_abk_prev) 
                                                {    case '�': $vstg_name_prev='mit �bung';break; 
                                                    case 'P': $vstg_name_prev='mit Praktikum';break; 
                                                    case 'S': $vstg_name_prev='mit Seminar';break; 
                                                } 
                                            } 
                                            $dunkler++; 
                                            echo '<tr bgcolor=#'.$zeilenfarbe.'> 
                                                    <td valign="top">'.$vstg_nr_prev.'</td> 
                                                    <td valign="top">'.$vstg_name_prev.'</td> 
                                                    <td width=20 align="center" valign="top">'.$vstg_art_abk_prev.'</td> 
                                                    <td width=20 align="center" valign="top">'.$sws_prev.'</td> 
                                                    <td>'.$leiter_prev.'</td> 
                                                    <td width=30 align="center">'.$tag_prev.'</td> 
                                                    <td>'.$zeit_prev.'</td> 
                                                    <td width=50>'.$raum_prev.'</td> 
													<td>'.$link.'</td>
                                                  </tr>'; 
                                            $vstg_nr_prev=$vstg_nr;    // Veranstaltung mit neuer Veranstaltungsnr. 
                                            $vstg_name_prev=$vstg_name; 
                                            $vstg_art_abk_prev=$vstg_art_abk; 
                                            $sws_prev=$sws; 
                                            $leiter_prev=$leiter; 
                                            $tag_prev=$tag; 
                                            $zeit_prev=$zeit; 
                                            $raum_prev=$raum;
											if (in_array($termin_id,$vstg_warenkorb))
												$link='<a href="'.$_SERVER["PHP_SELF"].'?modul=vlz&stud='.$stud_id.'&sem='.$semester.'&terminid='.$termin_id.'&aktion=delete">l�schen</a>';
											else
												$link='<a href="'.$_SERVER["PHP_SELF"].'?modul=vlz&stud='.$stud_id.'&sem='.$semester.'&terminid='.$termin_id.'&aktion=insert">hinzuf�gen</a>';										
                                        }     
                                    if ($count+1==mysql_num_rows($vstg_art_termin)) 
                                    { 
                                        if ($dunkler==0)    // Erster Veranstaltungsarteintrag wird dunkelgrau hinterlegt 
                                            $zeilenfarbe='c0c0c0'; 
                                        else  
                                        {    $zeilenfarbe='eeeeee'; 
                                            switch ($vstg_art_abk_prev) 
                                            {    case '�': $vstg_name_prev='mit �bung';break; 
                                                case 'P': $vstg_name_prev='mit Praktikum';break; 
                                                case 'S': $vstg_name_prev='mit Seminar';break; 
                                            } 
                                        } 
                                        $dunkler++; 
                                        echo '<tr bgcolor=#'.$zeilenfarbe.'> 
                                                <td valign="top">'.$vstg_nr_prev.'</td> 
                                                <td valign="top">'.$vstg_name_prev.'</td> 
                                                <td width=20 align="center" valign="top">'.$vstg_art_abk_prev.'</td> 
                                                <td width=20 align="center" valign="top">'.$sws_prev.'</td> 
                                                <td>'.$leiter_prev.'</td> 
                                                <td width=30 align="center">'.$tag_prev.'</td> 
                                                <td>'.$zeit_prev.'</td> 
                                                <td width=50>'.$raum_prev.'</td> 
												<td>'.$link.'</td>
                                              </tr>'; 
                                    }     
                                    $count++; 
                                } 
                            } 
                        } 
                    } 
     
                } 
                echo '</table>'; 
            } 
        } 
    }
	return 0; 
}


// Ausgabe des Kommentierten Vorlesungsverzeichnis 
// �bergeben der Fakult�ts-ID
function kommentiertes ($fak_id)
{
	$fak_id=intval($fak_id);
	$veranstaltungen=mysql_query ("SELECT id, name, prof, inhalt FROM veranstaltung WHERE fak='$fak_id'");
	if (mysql_num_rows($veranstaltungen))
	{
		echo '<center>
				<h5>Kommentiertes Vorelsungsverzeichnis der Fakult&auml;t '.GetFak_name($fak_id).'</h5>
			  </center>';
		while ($veranstaltungen_array=mysql_fetch_array($veranstaltungen))
		{
			echo '<table width=100%>
					<tr>
						<th>'.$veranstaltungen_array["name"].'</th>
					</tr>
					<tr>
						<td>'.$veranstaltungen_array["prof"].'</td>
					</tr>';
			$veranstaltungen_id=$veranstaltungen_array["id"];
			$arten=mysql_query ("SELECT art, sws FROM veranstaltung_art WHERE vstg_id='$veranstaltungen_id' ORDER BY art DESC");
			if (mysql_num_rows($arten))
			{
				echo '<tr><td><ul>';
				while ($arten_array=mysql_fetch_array($arten))
				{
					echo '<li>'.$arten_array["sws"].' SWS '.$arten_array["art"].'</li>';
				}
				echo '</ul></td></tr>';
			}
			echo 	'<tr>
						<td>'.$veranstaltungen_array["inhalt"].'</td>
					</tr>
				</table>';
		}
	}
	return 0;
}



?>