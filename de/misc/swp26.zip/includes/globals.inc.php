<?php

///////////////////////////////////////
//	SWP26 Stundenplaner
//	globals.inc.php
//	
//	Hier werden alle globalen Varaiblen abgelegt und k�nnen im Projekt
//	jederzeit aufgerufen werden.
//
//	bitte alle Varaiblen gut Dokumentieren und GROSSSCHREIBEN
///////////////////////////////////////

// Maximale Zeitdauer des Speicherns eines Stundenplaneintrags im Warenkorb
$MAX_WARENKORB_DAUER = 60*60*2;	// 2h maximal.

?>