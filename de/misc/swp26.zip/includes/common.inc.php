<?php

///////////////////////////////////////
//	SWP26 Stundenplaner
//	common.inc.php
//	
//	allgemeine Funktionen, die verschiedene Module ben�tigen
///////////////////////////////////////

/////////////
// Funktionen
/////////////

/*	leereWarenkorb ()
	
	l�scht Eintr�ge im Warenkorb die schon zu lange dort liegen, und keiner mehr ben�tigt.
*/
function leereWarenkorb()
{	
	// globale wird ben�tigt
	global $MAX_WARENKORB_DAUER;
	
	// sollte die Zeit 0 sein, werden die daten so nicht gel�scht
	if ( $MAX_WARENKORB_DAUER )
	{
		// aktuelle Zeit bestimmen
		$time = time() - $MAX_WARENKORB_DAUER;
	
		// Eintr�ge aus db holen, die bereits l�nger als MAX_WARENKORB_DAUER drinne liegen
		$r = mysql_query("SELECT id FROM warenkorb WHERE time < $time");
	
		if ( $r )	// die Abfrage hat Daten gefunden
		{
			while( $data = mysql_fetch_array( $r ))	// Datensatz durchlaufen und f�r jeden Datensatz den Eintrag l�schen
				mysql_query("DELETE FROM warenkorb WHERE id = '".$data["id"]."'");
		}
	}
}

/*	inWarenkorb ()
	
	f�gt einen TerminID in den Warenkorb ein zu einer bestimmten SessionID ein
	Jeder Benutzer bekommt eine SessionID, wenn er die Seite aufruft
*/
function inWarenkorb( $session_id, $termin_id = 0 )
{
	// aktuellen TimeStamp laden
	$time = time();
	
	// alle Eintr�ge zu dieser SessionID aktualisieren	
	mysql_query("UPDATE warenkorb SET time = $time WHERE sessionid = '".$session_id."'");
	
	if ( mysql_error() )
		return "FEHLER";
	
	// wurde eine TerminID gesetzt, diese noch in die Datenbank ablegen
	if ( $termin_id )
	{
		// pr�fen ob Eintrag bereits in der Datenbank vorhanden ist
		$r = mysql_query("SELECT id FROM warenkorb WHERE sessionid = '$session_id' AND vstg_art_termin_id = $termin_id");

		if ( !mysql_fetch_row($r) )	// wenn kein Eintrag in DB, den Eintrag hinzuf�gen
		{
			mysql_query("INSERT INTO warenkorb SET sessionid = '$session_id', vstg_art_termin_id = $termin_id, time = $time" );
			
			if ( mysql_error() )
				$return = "FEHLER";
			else 
				$return = "OK";
		}
		else
			$return = "DOPPELT";
	}
	else
		$return = "OK";
	
	// �berfl�ssige und veraltete Eintr�ge l�schen
	leereWarenkorb();
	
	return $return;
}

/*	 ausWarenkorb ()
	
	liest f�r eine SessionID alle Eintr�ge aus der Datenbank aus
	und gibt diese entweder als Array oder als MYSQL Ressource zur�ck
*/
function ausWarenkorb( $session_id, $as_ressource = false )
{
	// alle Daten zu �bergebener Sessionid auslesen
	$r = mysql_query( "SELECT * FROM warenkorb WHERE sessionid = '$session_id'" );
	
	// soll die R�ckgabe als Ressource erfolgen
	if ( $as_ressource )
	{
		// aktualisiere Datensatz und gebe $r zur�ck
		leereWarenkorb();
		return $r;
	}
	else
	{
		$a = array();	// array f�r R�ckgabe anlegen
		
		// array f�llen
		while( $data = mysql_fetch_array( $r ) )
		{
			$a[] = $data["vstg_art_termin_id"];	// neues Element an $a anh�ngen
		}
		
		// aktualisiere Datensatz und gebe $a zur�ck
		leereWarenkorb();
		return $a;
	}		
}

/*	l�scheWarenkorb ()
	
	l�scht entweder einen Eintrag mit der termin_id aus der DB
	oder l�scht alle Eintr�ge mit der session_id aus der DB ( sozusagen ein l�schen des stundenplans )
*/
function l�scheWarenkorb( $session_id, $termin_id = 0 )
{
	// wurde termin_id �bergeben, den extrateil des querys erstellen
	$query = "";
	if ( $termin_id )
		$query = " AND `vstg_art_termin_id`='$termin_id'";
	
	// l�schen der Daten aus der DB
	$r = mysql_query( "DELETE FROM warenkorb WHERE sessionid = '$session_id' ".$query );	
	// �berfl�ssige und veraltete Eintr�ge l�schen
	leereWarenkorb();
	return $r;
}

/*	admin_rights ()

	gibt die ID's der Fakult�ten in Form eines Arrays zur�ck
	die der Admin bearbeiten kann
*/
function admin_rights( $admin_id )
{
	$r = mysql_query("SELECT fakultaet from verwalter_rechte WHERE benutzer_id = '$admin_id'");
	if (@mysql_num_rows($r))
	{
		while($row_table = mysql_fetch_array($r))
			$admin_rights_id[] = $row_table["fakultaet"];
	}
	else
		$admin_rights_id = false;

	return $admin_rights_id;
}

/*	fak_name ()

	gibt den Namen der Fakult�t zur�ck
*/
function fak_name( $fak_id )
{
	$r = mysql_query("SELECT name from fakultaet WHERE id = '$fak_id' LIMIT 1");
	if (@mysql_num_rows($r))
	{
		while($row_table = mysql_fetch_array($r))
			$fakultaetsname = $row_table["name"];
	}
	else
		$fakultaetsname = false;

	return $fakultaetsname;
}

/*	vls_name ()

	gibt den Namen der Vorlesung zur�ck
*/
function vls_name( $vls_id )
{
	$r = mysql_query("SELECT name from veranstaltung WHERE id = '$vls_id' LIMIT 1");
	if (@mysql_num_rows($r))
	{
		while($row_table = mysql_fetch_array($r))
			$vlsname = $row_table["name"];
	}
	else
		$vlsname = false;

	return $vlsname;
}
			
?>
