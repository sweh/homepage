<?php 
// Session starten
	session_start();

// Mysql-Verbindung herstellen

$mysql_vbg = @mysql_connect("mysql.hrz.tu-chemnitz.de", "sweh", "swp_vlz");
$mysql_status = @mysql_select_db("swp_vlz", $mysql_vbg);

if (!$mysql_status)
  die("Es konnte keine Verbindung zur Datenbank aufgebaut werden. Bitte �berpr�fen Sie die Einstellungen!");

require_once('config.inc'); seite(__FILE__);
require_once('includes/globals.inc.php');
require_once('includes/common.inc.php');

// Admin-Test-Zeile - WICHTIG F�R WIWI - NICHT L�SCHEN
if ($_GET["modul"] == "admin")
	include_once("admin/index.php");

if ($_GET["modul"] == "useradmin")
	include_once("admin/useradmin.php");

if ($_GET["modul"]=='vlz' or $_GET["modul"]=='')
        include_once('vlz/index.php');

if ($_GET["modul"] == 'splan')
	include_once('stundenplaner/index.php');
?> 
