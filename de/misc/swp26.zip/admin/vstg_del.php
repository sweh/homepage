<?php
/*
erstellt von: sweh
Funktion: L�schen einer veranstaltung

�bergebene Daten: ID der Veranstaltung
*/


if (is_numeric($_GET["id"]))
{
	if (!$_POST["doit"])
	{
		echo "Sind Sie sicher, dass Sie die Vorlesung";
		echo "<p align=\"center\"><b>".vls_name($_GET["id"])."</b></p>";
		echo "<div align=\"right\">l�schen m�chten?</div>";
		?>
		<form action="<?php echo $_SERVER["REQUEST_URI"]; ?>" method="post">
		<table width="100%">
			<tr>
				<td align="center"><input type="submit" name="doit" value="Ja"></td>
				<td align="center"><input type="submit" name="doit" value="Nein"></td>
			</tr>
		</table>
		</form>
		<?php
	}
	elseif ($_POST["doit"] == "Ja")
	{
		$result_del = mysql_query("DELETE from veranstaltung WHERE id = ".$_GET["id"]." AND fak = ".$_GET["fak"]." LIMIT 1");
		if ($result_del)
		{
			$result_del_2 = mysql_query("SELECT id from veranstaltung_art WHERE vstg_id = ".$_GET["id"]);
			if (mysql_num_rows($result_del_2))
				while($row_del_2 = mysql_fetch_array($result_del_2))
				{
					$result_del_3 = mysql_query("SELECT id from veranstaltung_art_termine WHERE vstg_art_id = ".$row_del_2["id"]);
					if (mysql_num_rows($result_del_3))
						while($row_del_3 = mysql_fetch_array($result_del_3))
							mysql_query("DELETE from veranstaltung_art_termine_ausnahmen WHERE vstg_art_termine_id = ".$row_del_3["id"]);
				mysql_query("DELETE from veranstaltung_art_termine WHERE vstg_art_id = ".$row_del_2["id"]);
				}
			mysql_query("DELETE from veranstaltung_art WHERE vstg_id = ".$_GET["id"]);
			mysql_query("DELETE from studiengang_vstg WHERE vstg_id = ".$_GET["id"]);
			echo "Die Veranstaltung wurde erfolgreich gel�scht!";
			echo "<br><div align=\"right\"><a href=\"index.php?modul=".$_GET["modul"]."&fak=".$_GET["fak"]."\">zur�ck</a></div>";
		}

	}

}
?>