<?php
/*
erstellt von: sweh
Funktion: Reset der Datenbank
*/


if ($_POST["doit"] == "Ausf�hren")
{
	mysql_query("DELETE from studiengang_vstg");
	mysql_query("DELETE from veranstaltung");
	mysql_query("DELETE from veranstaltung_art");
	mysql_query("DELETE from veranstaltung_art_termine");
	mysql_query("DELETE from veranstaltung_art_termine_ausnahmen");
	mysql_query("DELETE from warenkorb");

	echo "Die Datenbank wurde erfolgreich resettet!";
}
else
{
	if ($_SESSION["admin_typ"] == "benutzeradmin")
	{
	?>
		<b>Sind Sie sicher, dass Sie die gesamte Datenbank leeren wollen? Alle Daten gehen unwiederruflich verloren!</b>
		<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
			<input type="submit" name="doit" value="Ausf�hren">
		</form>		
	<?php
	}
}
?>