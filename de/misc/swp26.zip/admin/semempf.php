<?php
/*
erstellt von: sweh
Funktion: Semesterempfehlungen bearbeiten
*/
?>
<table height="100%" width="100%">
	<tr>
		<th>Semesterempfehlungen</th>
	</tr>
	<tr>
		<td>
	<?php
		if (is_numeric($_GET["vstg_id"])) // �ndern der Semesterempfehlung f�r eine bestimmte Veranstaltung
		{
			if ($_POST["doit"])	//eintragen in die Datenbank
			{
				for ($i=0;$i<count($_POST["studgang_id"]);$i++)
				{
					if (!$_POST["studgang"][$i] && $_POST["studg_vlsg"][$i]) //L�SCHEN
						mysql_query("DELETE from studiengang_vstg WHERE id = ".$_POST["studg_vlsg"][$i]);
					elseif ($_POST["studg_vlsg"][$i]) //UPDATE
						mysql_query("UPDATE studiengang_vstg SET sem = '".$_POST["sem"][$i]."' WHERE id = ".$_POST["studg_vlsg"][$i]);
					elseif ($_POST["studgang"][$i] && !$_POST["studg_vlsg"][$i])//NEU
						mysql_query("INSERT into studiengang_vstg (studgang_id, vstg_id, sem) VALUES ('".$_POST["studgang_id"][$i]."', '".$_GET["vstg_id"]."', '".$_POST["sem"][$i]."')");
				}
				echo "Alle Aufgaben erfolgreich ausgef�hrt! <a href='index.php?modul=admin&action=semempf'>zur�ck</a>";
			}
	?>
	<table width="100%">
		<tr>
			<td align="center">
				<?php
					$result_vlsg = mysql_query("SELECT name from veranstaltung WHERE id = ".$_GET["vstg_id"]." LIMIT 1");
					if (@mysql_num_rows($result_vlsg))
						while($row_vlsg = mysql_fetch_array($result_vlsg))
							echo "<b>".$row_vlsg["name"]."</b>";
				?>
			</td>
		</tr>
		<tr>
			<td>
			<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
			<table width="100%">
	<?php
			$admin_rechte = admin_rights($_SESSION["admin_login"]);
			for ($i=0; $i<count($admin_rechte); $i++)
			{
				$j=0;
				echo "<tr><td><b>".fak_name($admin_rechte[$i])."</b></td></tr>";
				$result_studgang = mysql_query("SELECT id, name from studiengang WHERE fak_id = ".$admin_rechte[$i]." ORDER by name ASC");
				if (@mysql_num_rows($result_studgang))
				{
					while($row_studgang = mysql_fetch_array($result_studgang))
					{
						unset($result_studg_vlsg);
						unset($row_studg_vlsg);
						$result_studg_vlsg = mysql_query("SELECT id, sem from studiengang_vstg WHERE studgang_id = ".$row_studgang["id"]." AND vstg_id = ".$_GET["vstg_id"]." LIMIT 1");
						if (mysql_num_rows($result_studg_vlsg))
							$row_studg_vlsg = mysql_fetch_array($result_studg_vlsg)
							?>
							<tr>
								<td>
									&nbsp;&nbsp;&nbsp;<input type='hidden' name='studgang_id[<?php echo $j; ?>]' value='<?php echo $row_studgang["id"]; ?>'>
									<?php if ($row_studg_vlsg["id"]) echo "<input type='hidden' name='studg_vlsg[$j]' value='".$row_studg_vlsg["id"]."'>"; ?>
									<input type='checkbox' name='studgang[<?php echo $j; ?>]' value='<?php echo $row_studgang["name"]; ?>' <?php if ($row_studg_vlsg["id"]) echo "checked='checked'"; ?>> <?php echo $row_studgang["name"]; ?> im
									<input type='text' name='sem[<?php echo $j; ?>]' size="3" value="<?php echo $row_studg_vlsg["sem"]; ?>" maxlenght="1">. Semester
								</td>
							</tr>
				<?php
					$j++;
					}
				}
				else
					echo "<tr><td>Noch keine Studieng�nge vorhanden</td></tr>";
			}
	?>
			</table>
			</td>
		</tr>
		<tr>
			<td><input type="submit" name="doit" value="Abschicken"></td>
		</tr>
	</table>
	</form>
	<?php
		}
		else		// ausgabe _aller_ Veranstaltungen
		{
	?>
			<table width="100%">
				<tr>
					<td><b>Name</b></td><td><b>Fakult�t</b></td><td></td></tr>
			<?php
				$result_vstg = mysql_query("SELECT id, name, fak from veranstaltung ORDER by fak, name ASC");
				if (mysql_num_rows($result_vstg))
					while($row_vstg=mysql_fetch_array($result_vstg))
						echo "<tr><td>".$row_vstg["name"]."</td><td>".fak_name($row_vstg["fak"])."</td><td><a href=\"index.php?modul=".$_GET["modul"]."&action=".$_GET["action"]."&vstg_id=".$row_vstg["id"]."\"><img src=\"./icons/bearbeiten.gif\" border=0 title=\"�ndern\">�ndern</a></td></tr>";

			?>
			</table>
		<?php
		}
		?>

		</td>
	</tr>
</table>