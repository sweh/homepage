<?php
/*
erstellt von: sweh
Funktion: Berarbeiten der Fakult�ten
*/
?>
<table width="100%">
	<tr>
		<th>Fakult�tenadministration</th>
	</tr>
<?php
if ($_SESSION["admin_typ"] == "benutzeradmin")
{
	if ($_GET["doit"] == "new")
	{
		echo "<tr><td>";
		if ($_POST["weiter"] == "Abschicken")
		{
			mysql_query("INSERT into fakultaet (name) VALUES ('".$_POST["name"]."')");
			echo "Fakul�t erfolgreich hinzugef�gt! <a href=\"index.php?modul=".$_GET["modul"]."&action=".$_GET["action"]."\">zur�ck</a>";
		}
		else
		{
			?>
			<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
				<table width="100%">
					<tr>
						<td align="right">Name der Fakult�t</td>
						<td align="left"><input type="text" name="name" value="<?php echo $_POST["name"]; ?>" size="30" maxlenght="150"></td>
					</tr>
					<tr>
						<td colspan="2" align="center"><input type="submit" name="weiter" value="Abschicken"></td>
					</tr>
				</table>
			</form>
			<?php
		}
		echo "</td></tr>";
	}
	elseif (($_GET["doit"] == "edit") && (is_numeric($_GET["id"])))
	{
		echo "<tr><td>";
		if ($_POST["weiter"] == "Abschicken")
		{
			mysql_query("UPDATE fakultaet SET name = '".$_POST["name"]."' WHERE id = '".$_GET["id"]."'");
			echo "Fakul�t erfolgreich ge�ndert! <a href=\"index.php?modul=".$_GET["modul"]."&action=".$_GET["action"]."\">zur�ck</a>";
		}
		else
		{
			$result_fak = mysql_query("SELECT name from fakultaet WHERE id = '".$_GET["id"]."' LIMIT 1");
			if (mysql_num_rows($result_fak))
				$row_fak = mysql_fetch_array($result_fak);
			?>
			<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
				<table width="100%">
					<tr>
						<td align="right">Name der Fakult�t</td>
						<td align="left"><input type="text" name="name" value="<?php echo $row_fak["name"]; ?>" size="30" maxlenght="150"></td>
					</tr>
					<tr>
						<td colspan="2" align="center"><input type="submit" name="weiter" value="Abschicken"></td>
					</tr>
				</table>
			</form>
			<?php
		}
		echo "</td></tr>";
	}
	elseif($_GET["doit"] == "del")
	{
		echo "<tr><td>";
		if (is_numeric($_GET["id"]))
		{
			if ($_POST["submit"] == "Abschicken")
			{
				mysql_query("DELETE from fakultaet WHERE id = '".$_GET["id"]."' LIMIT 1");
				mysql_query("DELETE from verwalter_rechte WHERE fakultaet = '".$_GET["id"]."'");
				if ($_POST["delall"] == "true")
					mysql_query("DELETE from studiengang WHERE fak_id = ".$_GET["id"]) or die(mysql_error());
				echo "Die Fakult�t wurde gel�scht!";
			}
			else
			{
			?>
			<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
			zu l�schende Fakult�t: <b><?php echo fak_name($_GET["id"]); ?></b><br><br>
			<input type="checkbox" name="delall" value="true" checked="checked"> L�sche auch alle Studieng�nge, die zu dieser Fakult�t geh�ren
			<br><input type="submit" name="submit" value="Abschicken">
			</form>
			<?php
			}
		}
		echo "</td></tr>";
	}
	else
	{
?>
	<tr>
		<td align="center"><a href="index.php?modul=<?php echo $_GET["modul"]; ?>&action=<?php echo $_GET["action"]; ?>&doit=new"><img src="./icons/neu.gif" border=0 title="neue Fakult�t hinzuf�gen">Neue Fakult�t hinzuf�gen</a></td>
	</tr>
	<tr>
		<td>
		<table width="100%">
<?php
	$result = mysql_query("SELECT id, name from fakultaet ORDER by name ASC");
	if (mysql_num_rows($result))
		while($row = mysql_fetch_array($result))
			echo "<tr><td>".$row["name"]."</td><td><a href=\"index.php?modul=".$_GET["modul"]."&action=".$_GET["action"]."&id=".$row["id"]."&doit=edit\"><img src=\"./icons/bearbeiten.gif\" border=0 title=\"bearbeiten\">bearbeiten</a></td><td><a href=\"index.php?modul=".$_GET["modul"]."&action=".$_GET["action"]."&id=".$row["id"]."&doit=del\"><img src=\"./icons/loeschen.gif\" border=0 title=\"l�schen\">l�schen</a></td></tr>";

?>
		</table>
		</td>
	</tr>
<?php
	}
}
else
	echo "<tr><td>Kein Zugriff</td></tr>";

?>
</table>