// erstellt von sweh
// enth�lt alle von mir verwendeten Funktionen

/*	admin_rights ()

	gibt die ID's der Fakult�ten in Form eines Arrays zur�ck
	die der Admin bearbeiten kann
*/
function admin_rights( $admin_id )
{
	$r = mysql_query("SELECT fakultaet from verwalter_rechte WHERE benutzer_id = '$admin_id'");
	if (@mysql_num_rows($r))
	{
		while($row_table = mysql_fetch_array($r))
			$admin_rights_id[] = $row_table["fakultaet"];
	}
	else
		$admin_rights_id = false;

	return $admin_rights_id;
}

/*	fak_name ()

	gibt den Namen der Fakult�t zur�ck
*/
function fak_name( $fak_id )
{
	$r = mysql_query("SELECT name from fakultaet WHERE id = '$fak_id' LIMIT 1");
	if (@mysql_num_rows($r))
	{
		while($row_table = mysql_fetch_array($r))
			$fakultaetsname = $row_table["name"];
	}
	else
		$fakultaetsname = false;

	return $fakultaetsname;
}

/*	vls_name ()

	gibt den Namen der Vorlesung zur�ck
*/
function vls_name( $vls_id )
{
	$r = mysql_query("SELECT name from veranstaltung WHERE id = '$vls_id' LIMIT 1");
	if (@mysql_num_rows($r))
	{
		while($row_table = mysql_fetch_array($r))
			$vlsname = $row_table["name"];
	}
	else
		$vlsname = false;

	return $vlsname;
}