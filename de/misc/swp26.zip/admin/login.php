<?php
/*
erstellt von: sweh
Funktion: Einloggen des Admins - �berpr�fen, ob eingelogged
*/

if ($_GET["action"] == "logout")
{
	session_destroy();
	unset($_SESSION["admin_login"]);
}
if (!$_SESSION["admin_login"])
{
	if ($_POST["benutzername"] && $_POST["passwort"]) // Login-Formular wurde ausgef�llt und abgeschickt
	{
		$admin_login_result = mysql_query("SELECT id, passwort from verwalter WHERE name = '".$_POST["benutzername"]."' LIMIT 1");
		if (@mysql_num_rows($admin_login_result))
		{
			while ($admin_login_daten = @mysql_fetch_array($admin_login_result))
			{
				$datenbank_passwort = $admin_login_daten["passwort"];
				$admin_id = $admin_login_daten["id"];
			}
		}
		else
			die ("Benutzer nicht gefunden!");
	
		if ($datenbank_passwort == md5($_POST["passwort"])) // �berpr�fen des Passwortes
			$_SESSION["admin_login"] = $admin_id;
		else
			die ("Dass eingegebene Passwort ist falsch!");
	}
	else
	{
	?>
	<form method="POST" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
	<table>
		<tr>
			<td>Benutzername:</td>
			<td><input type="text" name="benutzername" maxlenght="50" size="25"></td>
		</tr>
		<tr>
			<td>Passwort:</td>
			<td><input type="password" name="passwort" maxlenght="50" size="25"></td>
		</tr>
		<tr>
			<td colspan="2"><input type="submit" value="Einloggen"></td>
		</tr>
	</table>
	</form>
	<?php
	}
}
if (isset($_SESSION["admin_login"])) // Admin ist eingelogged
{
	$result_status = mysql_query("SELECT name,status from verwalter WHERE id = '".$_SESSION["admin_login"]."' LIMIT 1");
		if (mysql_num_rows($result_status))
			$array_admin_status = mysql_fetch_array($result_status);
				$_SESSION["admin_typ"] = $array_admin_status["status"];
?>
<table width="100%">
	<tr>
		<td>Herzlich Willkommen, <b><?php echo $array_admin_status["name"]; ?></b>, Sie sind als <b>
			<?php
				if ($array_admin_status["status"] == "benutzeradmin") 
					echo "Benutzerverwalter";
				else
					echo "Datenverwalter";
			?>
			</b> eingelogged!</td>
		<td align="right"><a href="index.php?modul=<?php echo $_GET["modul"]; ?>&action=logout">Sitzung beenden</a></td>
	</tr>
</table>
<?php
$admin_ist_eingelogged = TRUE;
}
?>