<?php
/*
erstellt von: sweh
Funktion: Berarbeiten der Fakult�ten
*/
?>
<table width="100%">
	<tr>
		<th>Studiengangadministration</th>
	</tr>
<?php
if ($_SESSION["admin_typ"] == "benutzeradmin")
{
	if (($_GET["doit"] == "new") && is_numeric($_GET["fak_id"]))
	{
		echo "<tr><td>";
		if ($_POST["weiter"] == "Abschicken")
		{
			mysql_query("INSERT into studiengang (name, fak_id) VALUES ('".$_POST["name"]."', '".$_GET["fak_id"]."')");
			echo "Studiengang erfolgreich hinzugef�gt! <a href=\"index.php?modul=".$_GET["modul"]."&action=".$_GET["action"]."\">zur�ck</a>";
		}
		else
		{
			?>
			<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
				<table width="100%">
					<tr>
						<td align="right">Name des Studiengangs</td>
						<td align="left"><input type="text" name="name" value="<?php echo $_POST["name"]; ?>" size="30" maxlenght="150"></td>
					</tr>
					<tr>
						<td colspan="2" align="center"><input type="submit" name="weiter" value="Abschicken"></td>
					</tr>
				</table>
			</form>
			<?php
		}
		echo "</td></tr>";
	}
	elseif (($_GET["doit"] == "edit") && (is_numeric($_GET["id"])) && (is_numeric($_GET["fak_id"])))
	{
		echo "<tr><td>";
		if ($_POST["weiter"] == "Abschicken")
		{
			mysql_query("UPDATE studiengang SET name = '".$_POST["name"]."', fak_id = '".$_POST["fak_id"]."' WHERE id = '".$_GET["id"]."'");
			echo "Studiengang erfolgreich ge�ndert! <a href=\"index.php?modul=".$_GET["modul"]."&action=".$_GET["action"]."\">zur�ck</a>";
		}
		else
		{
			$result_fak = mysql_query("SELECT name, fak_id from studiengang WHERE id = '".$_GET["id"]."' LIMIT 1")or die(mysql_error());
			if (mysql_num_rows($result_fak))
				$row_fak = mysql_fetch_array($result_fak);
			?>
			<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
				<table width="100%">
					<tr>
						<td align="right">Name der Fakult�t</td>
						<td align="left"><input type="text" name="name" value="<?php echo $row_fak["name"]; ?>" size="30" maxlenght="150"></td>
					</tr>
					<tr>
						<td align="right">geh�rt zur Fakult�t</td>
						<td align="left"><select name="fak_id" size="1">
							<?php
								$result_fak = mysql_query("SELECT id, name from fakultaet ORDER by name ASC");
								if (mysql_num_rows($result_fak))
									while($row_fak=mysql_fetch_array($result_fak))
									{
										echo "<option value='".$row_fak["id"]."' ";
										if ($row_fak["id"] == $_GET["fak_id"])
											echo "selected='selected'";
										echo ">".$row_fak["name"]."</option>";
									}
							?>
						</select>
						</td>
					</tr>
					<tr>
						<td colspan="2" align="center"><input type="submit" name="weiter" value="Abschicken"></td>
					</tr>
				</table>
			</form>
			<?php
		}
		echo "</td></tr>";
	}
	elseif($_GET["doit"] == "del")
	{
		echo "<tr><td>";
		if (is_numeric($_GET["id"]))
		{
			if ($_POST["submit"] == "Abschicken")
			{
				mysql_query("DELETE from studiengang WHERE id = '".$_GET["id"]."' LIMIT 1");
				mysql_query("DELETE from studiengang_vstg WHERE studgang_id = '".$_GET["id"]."' LIMIT 1");
				echo "Der Studiengang wurde gel�scht!";
			}
			else
			{
			?>
			<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
			Hierber wird der Studiengang gel�scht! (er kann nicht wiederhergestellt werden)
				<br><input type="submit" name="submit" value="Abschicken">
			</form>
			<?php
			}
		}
		echo "</td></tr>";
	}
	else
	{
		$r_fak = mysql_query("SELECT id from fakultaet");
		if(mysql_num_rows($r_fak))
			while($row_fak = mysql_fetch_array($r_fak))
				$admin_rechte[] = $row_fak["id"];
		for ($i=0;$i<count($admin_rechte);$i++)
		{
		?>
		<tr>
			<td align="left"><b><?php echo fak_name($admin_rechte[$i]); ?></b></td>
		</tr>
		<tr>
			<td align="center"><a href="index.php?modul=<?php echo $_GET["modul"]; ?>&action=<?php echo $_GET["action"]; ?>&fak_id=<?php echo $admin_rechte[$i]; ?>&doit=new"><img src="./icons/neu.gif" border=0 title="Neuen Studiengang hinzuf�gen">Neuen Studiengang hinzuf�gen</a></td>
		</tr>
		<tr>
			<td>
			<table width="100%">
	<?php
		$result = mysql_query("SELECT id, name from studiengang WHERE fak_id = ".$admin_rechte[$i]." ORDER by name ASC");
		if (@mysql_num_rows($result))
			while($row = mysql_fetch_array($result))
				echo "<tr><td>".$row["name"]."</td><td><a href=\"index.php?modul=".$_GET["modul"]."&action=".$_GET["action"]."&fak_id=".$admin_rechte[$i]."&id=".$row["id"]."&doit=edit\"><img src=\"./icons/bearbeiten.gif\" border=0 title=\"bearbeiten\">bearbeiten</a></td><td><a href=\"index.php?modul=".$_GET["modul"]."&action=".$_GET["action"]."&fak_id=".$admin_rechte[$i]."&id=".$row["id"]."&doit=del\"><img src=\"./icons/loeschen.gif\" border=0 title=\"l�schen\">l�schen</a></td></tr>";
	
	?>
			</table>
			</td>
		</tr>
	<?php
		}
	}
}
else
	echo "<tr><td>Kein Zugriff</td></tr>";

?>
</table>