<?php
/*
erstellt von: sweh
Funktion: Adminseite �bersicht
*/
echo '<center><img src="icons/admin_titel.gif"></center><br><br>';
require("login.php");

if ($admin_ist_eingelogged) // Admin ist eingelogged
{
?>
<table width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="top">
      <?php
		if (is_numeric($_GET["fak"]))
		{
			// zeige Veranstaltungsmen�
			include("vstg.php");
		}
		elseif ($_GET["action"] == "semempf")
		{
			// zeige Semesterempfehlungsmen�
			include("semempf.php");
		}
		elseif ($_GET["action"] == "fakadmin")
		{
			// zeige Fakult�tsadminmen�
			include("fakadmin.php");
		}
		elseif ($_GET["action"] == "studadmin")
		{
			// zeige Studienmen�
			include("studadmin.php");
		}
		elseif ($_GET["action"] == "benutzer")
		{
			// zeige Useradminmen�
			include("useradmin.php");
		}
		elseif ($_GET["action"] == "dbreset")
		{
			// zeige DB-Resetmen�
			include("dbreset.php");
		}
		else
			echo "Bitte w�hlen Sie auf der rechte Seite die Aufgabe aus!";
      ?>
    </td>
	<th width="1px">
	</th>
	<td width="200" valign="top">
		<table width="100%">
		<?php
			if ($admin_rechte = admin_rights($_SESSION["admin_login"]))
			{
			?>
				<tr>
					<th>Fakult�t bearbeiten</th>
				</tr>
				<tr>
					<td>
						<b>Fakult�tsauswahl:</b>
						<ul>
						<?php
						for ($i=0;$i<count($admin_rechte);$i++)
							echo "<li><a href=\"index.php?modul=".$_GET["modul"]."&fak=".$admin_rechte[$i]."\">".fak_name($admin_rechte[$i])."</a></li>";
						?>
						</ul>
					</td>
				</tr>
				<tr>
					<th>diverses</th>
				</tr>
				<tr>
					<td>
						<ul>
							<li><a href="index.php?modul=<?php echo $_GET["modul"]; ?>&action=semempf">Semesterempfehlungen</a></li>
						</ul>
					</td>
				</tr>
			<?php
			}
			if ($_SESSION["admin_typ"] == "benutzeradmin")
			{
			?>
				<tr>
					<th>Administration</th>
				</tr>
				<tr>
					<td>
						<ul>
							<li><a href="index.php?modul=<?php echo $_GET["modul"]; ?>&action=fakadmin">Fakult�t</a></li>
							<li><a href="index.php?modul=<?php echo $_GET["modul"]; ?>&action=studadmin">Studiengang</a></li>
							<li><a href="index.php?modul=<?php echo $_GET["modul"]; ?>&action=benutzer">Benutzer</a></li>
						</ul>
					</td>
				</tr>
				<tr>
					<th>diverses</th>
				</tr>
				<tr>
					<td>
						<ul>
							<li><a href="index.php?modul=<?php echo $_GET["modul"]; ?>&action=dbreset">Datenbankreset</a></li>
						</ul>
					</td>
				</tr>
			<?php
			}
		?>
		</table>
	</td>
  </tr>
  <tr>
	<th colspan="3">
	</th>
  </tr>
</table>
<?php 
}
?>
