<?php
/*
erstellt von: sweh
Funktion: Ausgabe der Veranstaltungen

�bergebene Daten: ID der Fakult�t
*/
?>
<table height="100%" width="100%">
	<tr>
		<th><?php echo fak_name($_GET["fak"]); ?></th>
	</tr>
	<?php
	if (is_numeric($_GET["id"]))
	{
		echo "<tr><td>";
		if ($_GET["action"] == "edit")
			include_once("vstg_edit.php");
		elseif ($_GET["action"] == "del")
			include_once("vstg_del.php");
		echo "</td></tr>";
	}
	elseif ($_GET["action"] == "new")
	{
		echo "<tr><td>";
		include_once("vstg_new.php");
		echo "</td></tr>";
	}
	else
	{
	?>
	<tr>
		<td align="center">
			<a href="index.php?modul=<?php echo $_GET["modul"]; ?>&fak=<?php echo $_GET["fak"]; ?>&action=new"><img src="./icons/neu.gif" border=0 title="neue Veranstaltung hinzuf�gen">Neue Veranstaltung hinzuf�gen</a>
		</td>
	</tr>
	<tr>
		<td>
			<b>Veranstaltungs�bersicht:</b>
			<table width="100%">
			<?php
				$result_vstg = mysql_query("SELECT id, name from veranstaltung WHERE fak = '".$_GET["fak"]."'");
				if (mysql_num_rows($result_vstg))
				{
					while($row_entry = mysql_fetch_array($result_vstg))
					{
						echo "<tr><td>".$row_entry["name"]."</td>";
						echo "<td><a href=\"index.php?modul=".$_GET["modul"]."&fak=".$_GET["fak"]."&id=".$row_entry["id"]."&action=edit\"><img src=\"./icons/bearbeiten.gif\" border=0 title=\"bearbeiten\">bearbeiten</a></td>";
						echo "<td><a href=\"index.php?modul=".$_GET["modul"]."&fak=".$_GET["fak"]."&id=".$row_entry["id"]."&action=del\"><img src=\"./icons/loeschen.gif\" border=0 title=\"l�schen\">l�schen</a></td></tr>";
					}
				}
				else
					echo "<tr><td>Im Moment keine Eintr�ge in der Datenbank</td></tr>";
			?>
			</table>
		</td>
	</tr>
	<?php
	}
	?>
</table>