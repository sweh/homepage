<?php
/*
erstellt von: sweh
Funktion: Berarbeiten einer veranstaltung
*/

if ($_POST["Abschicken"] == "weiter")
{
	mysql_query("UPDATE veranstaltung SET name = '".$_POST["name"]."', prof = '".$_POST["prof"]."', inhalt = '".$_POST["inhalt"]."' WHERE id = '".$_GET["id"]."'");
	for ($i=0;$i<4;$i++)
	{
		if ($_POST["art"][$i])
		{
			if ($_POST["id"][$i])
				mysql_query("UPDATE veranstaltung_art SET art = '".$_POST["art"][$i]."', sws = '".$_POST["sws"][$i]."' WHERE id = '".$_POST["id"][$i]."'");
			else
				mysql_query("INSERT into veranstaltung_art (vstg_id, art, sws) VALUES ('".$_GET["id"]."', '".$_POST["art"][$i]."', '".$_POST["sws"][$i]."')");
		}
		elseif ($_POST["id"][$i])
			mysql_query("DELETE from veranstaltung_art WHERE id = '".$_POST["id"][$i]."'");
	}
	$_POST["vstg_id"] = $_GET["id"];
}
elseif (($_POST["Abschicken"] != "next") && ($_POST["do_it"] != "del") && ($_POST["do_it"] != "edit"))
{
	$result_vstg = mysql_query("SELECT name, prof, inhalt from veranstaltung WHERE id = ".$_GET["id"]." && fak = ".$_GET["fak"]." LIMIT 1");
	if (mysql_num_rows($result_vstg))
		while($row_vstg = mysql_fetch_array($result_vstg))
		{
			$db_vstg["name"] = $row_vstg["name"];
			$db_vstg["prof"] = $row_vstg["prof"];
			$db_vstg["inhalt"] = $row_vstg["inhalt"];
		}

	unset($result_vstg);
	$result_vstg = mysql_query("SELECT id, art, sws from veranstaltung_art WHERE vstg_id = ".$_GET["id"]);
	if (mysql_num_rows($result_vstg))
		while($row_vstg = mysql_fetch_array($result_vstg))
		{
			$db_art[$row_vstg["art"]]["id"] = $row_vstg["id"];
			$db_art[$row_vstg["art"]]["sws"] = $row_vstg["sws"];
		}
?>
<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
<table width="100%">
	<tr>
		<td colspan="2"><b>allgemeine Informationen:</b></td>
	</tr>
	<tr>
		<td align="right">Veranstaltungsname</td>
		<td align="left"><input type="text" name="name" value="<?php echo $db_vstg["name"]; ?>" size="30" maxlenght="150"></td>
	</tr>
	<tr>
		<td align="right">Professor</td>
		<td align="left"><input type="text" name="prof" value="<?php echo $db_vstg["prof"]; ?>" size="30" maxlenght="150"></td>
	</tr>
	<tr>
		<td align="right">Inhalt</td>
		<td align="left"><textarea name="inhalt" cols=23 rows=5><?php echo $db_vstg["inhalt"]; ?></textarea></td>
	</tr>
	<tr>
		<td colspan="2"><b>Veranstaltungsarten:</b></td>
	</tr>
	<tr>
		<td align="right"><input type="checkbox" name="art[0]" value="Vorlesung" <?php if ($db_art["Vorlesung"]["id"]) echo "checked=\"checked\""; ?>> Vorlesung mit </td>
		<td><input type="hidden" name="id[0]" value="<?php echo $db_art["Vorlesung"]["id"]; ?>"><input type="text" name="sws[0]" value="<?php echo $db_art["Vorlesung"]["sws"]; ?>" size="2" maxlenght="1"> SWS</td>
	</tr>
	<tr>
		<td align="right"><input type="checkbox" name="art[1]" value="Uebung" <?php if ($db_art["Uebung"]["id"]) echo "checked=\"checked\""; ?>> �bung mit </td>
		<td><input type="hidden" name="id[1]" value="<?php echo $db_art["Uebung"]["id"]; ?>"><input type="text" name="sws[1]" value="<?php echo $db_art["Uebung"]["sws"]; ?>" size="2" maxlenght="1"> SWS</td>
	</tr>
	<tr>
		<td align="right"><input type="checkbox" name="art[2]" value="Praktikum" <?php if ($db_art["Praktikum"]["id"]) echo "checked=\"checked\""; ?>> Praktikum mit </td>
		<td><input type="hidden" name="id[2]" value="<?php echo $db_art["Praktikum"]["id"]; ?>"><input type="text" name="sws[2]" value="<?php echo $db_art["Praktikum"]["sws"]; ?>" size="2" maxlenght="1"> SWS</td>
	</tr> 
	<tr>
		<td align="right"><input type="checkbox" name="art[3]" value="Seminar" <?php if ($db_art["Seminar"]["id"]) echo "checked=\"checked\""; ?>> Seminar mit </td>
		<td><input type="hidden" name="id[3]" value="<?php echo $db_art["Seminar"]["id"]; ?>"><input type="text" name="sws[3]" value="<?php echo $db_art["Seminar"]["sws"]; ?>" size="2" maxlenght="1"> SWS</td>
	</tr>
	<tr>
		<td colspan="2" align="center"><input type="submit" name="Abschicken" value="weiter"></td>
	</tr>
	<tr>
		<td colspan="2" align="center">weiter zur n�chste Seite, wo die Termine eingerichtet werden k�nnen!</td>
	</tr>
</table>
</form>
<?php
}

if ($_POST["vstg_id"])
{
	if ($_POST["Abschicken"] == "next")
	{
		if ($_POST["do_it2"] == "edit")
		{
			mysql_query("UPDATE veranstaltung_art_termine SET vstg_art_id = '".$_POST["vstg_art_id"]."',  vstg_nr = '".$_POST["vstg_nr"]."', tag = '".$_POST["tag"]."', woche = '".$_POST["woche"]."', einheit = '".$_POST["einheit"]."',  raum = '".$_POST["raum"]."', status = 'geaendert',  dauer = '".$_POST["dauer"]."', leiter = '".$_POST["leiter"]."' WHERE id = '".$_POST["edit_id"]."'")or die(mysql_error());
			if ($_POST["termin_auswahl"] == 1)
			{
				$termin_begin = mktime($_POST["bstunde"], $_POST["bminute"], $_POST["bsekunde"], $_POST["bmonat"], $_POST["btag"], $_POST["bjahr"]);
				$termin_ende = mktime($_POST["estunde"], $_POST["eminute"], $_POST["esekunde"], $_POST["emonat"], $_POST["etag"], $_POST["ejahr"]);
				if ($_POST["id_ausnahmen"])
					mysql_query("UPDATE veranstaltung_art_termine_ausnahmen SET begin = '$termin_begin', ende = '$termin_ende' WHERE id = '$id_ausnahmen'")or die(mysql_error());
				else
					mysql_query("INSERT into veranstaltung_art_termine_ausnahmen (vstg_art_termine_id, begin, ende) VALUES ('".$_POST["edit_id"]."', '".$termin_begin."', '".$termin_ende."')");					
			}
			elseif ($_POST["id_ausnahmen"])
				mysql_query("DELETE from veranstaltung_art_termine_ausnahmen WHERE id = '".$_POST["id_ausnahmen"]."' LIMIT 1")or die(mysql_error());
		echo "�nderungen erfolgreich";
		}
		else
		{
			if ($_POST["termin_auswahl"] == 0)
				mysql_query("INSERT into veranstaltung_art_termine (vstg_art_id, vstg_nr, tag, woche, einheit, raum, dauer, leiter) VALUES ('".$_POST["vstg_art_id"]."', '".$_POST["vstg_nr"]."', '".$_POST["tag"]."', '".$_POST["woche"]."', '".$_POST["einheit"]."', '".$_POST["raum"]."', '".$_POST["dauer"]."', '".$_POST["leiter"]."')");
			else
			{
				$termin_begin = mktime($_POST["bstunde"], $_POST["bminute"], $_POST["bsekunde"], $_POST["bmonat"], $_POST["btag"], $_POST["bjahr"]);
				$termin_ende = mktime($_POST["estunde"], $_POST["eminute"], $_POST["esekunde"], $_POST["emonat"], $_POST["etag"], $_POST["ejahr"]);
				mysql_query("INSERT into veranstaltung_art_termine (vstg_art_id, vstg_nr, raum, leiter) VALUES ('".$_POST["vstg_art_id"]."', '".$_POST["vstg_nr"]."', '".$_POST["raum"]."' ,'".$_POST["leiter"]."')");			
				mysql_query("INSERT into veranstaltung_art_termine_ausnahmen (vstg_art_termine_id, begin, ende) VALUES ('".mysql_insert_id()."', '".$termin_begin."', '".$termin_ende."')");			
			}
		}

	}
	if ($_POST["do_it"] == "del")
	{
		if ($_POST["submit_art"] == "Streichen")
			mysql_query("UPDATE veranstaltung_art_termine SET status = 'gestrichen' WHERE id = ".$_POST["del_id"]);
		else
			mysql_query("DELETE from veranstaltung_art_termine WHERE id = ".$_POST["del_id"]);
	}
	if($_POST["do_it"] == "edit")
	{
		$result_edit = mysql_query("SELECT vstg_art_id, vstg_nr, tag, woche, einheit, raum, status, dauer, leiter from veranstaltung_art_termine WHERE id = ".$_POST["edit_id"]." LIMIT 1");
		if (mysql_num_rows($result_edit))
			while ($row_edit = mysql_fetch_array($result_edit))
			{
				$vstg_art_id = $row_edit["vstg_art_id"];
				$vstg_nr = $row_edit["vstg_nr"];
				$tag = $row_edit["tag"];
				$woche = $row_edit["woche"];
				$einheit = $row_edit["einheit"];
				$raum = $row_edit["raum"];
				$dauer = $row_edit["dauer"];
				$leiter = $row_edit["leiter"];
			}
		$result_edit2 = mysql_query("SELECT id, begin, ende from veranstaltung_art_termine_ausnahmen WHERE vstg_art_termine_id = ".$_POST["edit_id"]." LIMIT 1");
		if (mysql_num_rows($result_edit2))
			while($row_edit2 = mysql_fetch_array($result_edit2))
			{
				$id_ausnahmen = $row_edit2["id"];
				$begin = $row_edit2["begin"];
				$ende = $row_edit2["ende"];
			}
	?>
<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
<input type="hidden" name="vstg_id" value="<?php echo $_POST["vstg_id"]; ?>">
<input type="hidden" name="edit_id" value="<?php echo $_POST["edit_id"]; ?>">
<input type="hidden" name="edit_id2" value="<?php echo $id_ausnahmen; ?>">
<input type="hidden" name="do_it2" value="edit">
<table width="100%">
	<tr>
		<td colspan="2"><b>allgemeine Informationen:</b></td>
	</tr>
	<tr>
		<td align="right">Veranstaltungsart</td>
		<td align="left">
			<select name="vstg_art_id">
				<?php
					$result_vstg_art = mysql_query("SELECT id, art from veranstaltung_art WHERE vstg_id = ".$_POST["vstg_id"]);
					if (mysql_num_rows($result_vstg_art))
						while($row_vstg_art = mysql_fetch_array($result_vstg_art))
						{
							echo "<option value=\"".$row_vstg_art["id"]."\" ";
							if ($vstg_art_id == $row_vstg_art["id"])
								echo "selected='selected'";
							echo ">".$row_vstg_art["art"]."</option>";
						}
				?>
			</select>
		</td>
	</tr>
	<tr>
		<td align="right">Veranstaltungsnummer</td>
		<td align="left"><input type="text" name="vstg_nr" value="<?php echo $vstg_nr; ?>" size="10" maxlenght="8"></td>
	</tr>
	<tr>
		<td align="right">Raum</td>
		<td align="left"><input type="text" name="raum" value="<?php echo $raum; ?>" size="6" maxlenght="5"></td>
	</tr>
	<tr>
		<td align="right">Leiter</td>
		<td align="left"><input type="text" name="leiter" value="<?php echo $leiter; ?>" size="25" maxlenght="150"></td>
	</tr>
	<tr>
		<td colspan="2"><input type="radio" name="termin_auswahl" value="0"<?php if(!$id_ausnahmen) echo " checked='checked'"; ?>><b>detaillierte Termindaten:</b>*</td>
	</tr>
	<tr>
		<td align="right">Wochentag</td>
		<td align="left">
			<select name="tag" size=1>
				<option value="Mo" <?php if($tag == "Mo") echo "selected='selected'"; ?>>Montag</option>
				<option value="Di" <?php if($tag == "De") echo "selected='selected'"; ?>>Dienstag</option>
				<option value="Mi" <?php if($tag == "Mi") echo "selected='selected'"; ?>>Mittwoch</option>
				<option value="Do" <?php if($tag == "Do") echo "selected='selected'"; ?>>Donnerstag</option>
				<option value="Fr" <?php if($tag == "Fr") echo "selected='selected'"; ?>>Freitag</option>
			</select>
		</td>
	</tr>
	<tr>
		<td align="right">Woche</td>
		<td align="left">
			<select name="woche" size=1>
				<option value="immer" <?php if($woche == "immer") echo "selected='selected'"; ?>>jede Woche</option>
				<option value="ungerade" <?php if($woche == "ungerade") echo "selected='selected'"; ?>>ungerade Woche</option>
				<option value="gerade" <?php if($woche == "gerade") echo "selected='selected'"; ?>>gerade Woche</option>
			</select>
		</td>
	</tr>
	<tr>
		<td align="right">Einheit</td>
		<td align="left">
			<select name="einheit" size=1>
				<?php
					for ($i=1; $i<10; $i++)
					{
						echo "<option value=\"$i\" ";
						if ($einheit == $i)
							echo "selected='selected'";
						echo ">$i</option>";
					}
				?>
			</select>
		</td>
	</tr>
	<tr>
		<td align="right">Dauer</td>
		<td align="left">
			<select name="dauer" size=1>
				<?php
					for ($i=1; $i<10; $i++)
					{
						echo "<option value=\"$i\" ";
						if ($dauer == $i)
							echo "selected='selected'";
						echo ">$i</option>";
					}
				?>
			</select> Einheiten
		</td>
	</tr>
	<tr>
		<td colspan="2"><input type="radio" name="termin_auswahl" value="1"<?php if($id_ausnahmen) echo " checked='checked'"; ?>><b>Datumseingabe:</b>*</td>
	</tr>
	<tr>
		<td align="left" colspan="2">Beginn</td>
	</tr>
	<tr>
		<td align="left" colspan="2">
			<input type="text" name="btag" size="3" maxlenght="2" value="<?php if ($id_ausnahmen) echo date("d", $begin); ?>">.
			<input type="text" name="bmonat" size="3" maxlenght="2" value="<?php if ($id_ausnahmen) echo date("m", $begin); ?>">.
			<input type="text" name="bjahr" size="5" maxlenght="4" value="<?php if ($id_ausnahmen) echo date("Y", $begin); ?>">
			<input type="text" name="bstunde" size="3" maxlenght="2" value="<?php if ($id_ausnahmen) echo date("H", $begin); ?>">:
			<input type="text" name="bminute" size="3" maxlenght="2" value="<?php if ($id_ausnahmen) echo date("i", $begin); ?>">:
			<input type="text" name="bsekunde" size="3" maxlenght="2" value="<?php if ($id_ausnahmen) echo date("s", $begin); ?>"> Uhr
		</td>
	</tr>
	<tr>
		<td align="left" colspan="2">Ende</td>
	</tr>
	<tr>
		<td align="left" colspan="2">
			<input type="text" name="etag" size="3" maxlenght="2" value="<?php if ($id_ausnahmen) echo date("d", $ende); ?>">.
			<input type="text" name="emonat" size="3" maxlenght="2" value="<?php if ($id_ausnahmen) echo date("m", $ende); ?>">.
			<input type="text" name="ejahr" size="5" maxlenght="4" value="<?php if ($id_ausnahmen) echo date("Y", $ende); ?>">
			<input type="text" name="estunde" size="3" maxlenght="2" value="<?php if ($id_ausnahmen) echo date("H", $ende); ?>">:
			<input type="text" name="eminute" size="3" maxlenght="2" value="<?php if ($id_ausnahmen) echo date("i", $ende); ?>">:
			<input type="text" name="esekunde" size="3" maxlenght="2" value="<?php if ($id_ausnahmen) echo date("s", $ende); ?>"> Uhr
		</td>
	</tr>
	<tr>
		<td colspan="2" align="center"><input type="hidden" name="Abschicken" value="next"><input type="submit" value="�ndern"></td>
	</tr>
</table>
*) bitte ausw�hlen
</form>	

	<?php
	}
	else
	{
	echo "<table width=\"100%\"><tr><td><b>Veranstaltungsnummer</b></td><td></td><td></td></tr>";
	$result_1 = mysql_query("SELECT id from veranstaltung_art WHERE vstg_id = ".$_POST["vstg_id"]);
	if (@mysql_num_rows($result_1))
		while($row =  mysql_fetch_array($result_1))
		{
			$result_2 = mysql_query("SELECT id, vstg_nr, status from veranstaltung_art_termine WHERE vstg_art_id = '".$row["id"]."'");
			if (mysql_num_rows($result_2))
				while($row_termine = mysql_fetch_array($result_2))
				{
					echo "<tr><td align=\"center\">".$row_termine["vstg_nr"]."</td><td align=\"center\"><form method=\"post\" action=\"".$_SERVER["REQUEST_URI"]."\"><input type=\"hidden\" name=\"do_it\" value=\"edit\"><input type=\"hidden\" name=\"edit_id\" value=\"".$row_termine["id"]."\"><input type=\"hidden\" name=\"vstg_id\" value=\"".$_POST["vstg_id"]."\"><input type=\"submit\" value=\"bearbeiten\"></form></td><td align=\"center\"><form method=\"post\" action=\"".$_SERVER["REQUEST_URI"]."\"><input type=\"hidden\" name=\"do_it\" value=\"del\"><input type=\"hidden\" name=\"del_id\" value=\"".$row_termine["id"]."\"><input type=\"hidden\" name=\"vstg_id\" value=\"".$_POST["vstg_id"]."\">";
					if ($row_termine["status"] != "gestrichen")
						echo "<input type=\"submit\" name=\"submit_art\" value=\"Streichen\">";
					else
						echo "gestrichen";
					echo "<input type=\"submit\" name=\"submit_art\" value=\"L�schen\">";
					echo "</form></td></tr>";
				}
		}
	echo "<tr><th colspan=4></th>";
	echo "</table>";
?>



<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
<input type="hidden" name="vstg_id" value="<?php echo $_POST["vstg_id"]; ?>">
<table width="100%">
	<tr>
		<td colspan="2"><b>allgemeine Informationen:</b></td>
	</tr>
	<tr>
		<td align="right">Veranstaltungsart</td>
		<td align="left">
			<select name="vstg_art_id">
				<?php
					$result_vstg_art = mysql_query("SELECT id, art from veranstaltung_art WHERE vstg_id = ".$_POST["vstg_id"]);
					if (mysql_num_rows($result_vstg_art))
						while($row_vstg_art = mysql_fetch_array($result_vstg_art))
							echo "<option value=\"".$row_vstg_art["id"]."\">".$row_vstg_art["art"]."</option>";
				?>
			</select>
		</td>
	</tr>
	<tr>
		<td align="right">Veranstaltungsnummer</td>
		<td align="left"><input type="text" name="vstg_nr" size="10" maxlenght="8"></td>
	</tr>
	<tr>
		<td align="right">Raum</td>
		<td align="left"><input type="text" name="raum" size="6" maxlenght="5"></td>
	</tr>
	<tr>
		<td align="right">Leiter</td>
		<td align="left"><input type="text" name="leiter" size="25" maxlenght="150"></td>
	</tr>
	<tr>
		<td colspan="2"><input type="radio" name="termin_auswahl" value="0" checked="checked"><b>detaillierte Termindaten:</b>*</td>
	</tr>
	<tr>
		<td align="right">Wochentag</td>
		<td align="left">
			<select name="tag" size=1>
				<option value="Mo">Montag</option>
				<option value="Di">Dienstag</option>
				<option value="Mi">Mittwoch</option>
				<option value="Do">Donnerstag</option>
				<option value="Fr">Freitag</option>
			</select>
		</td>
	</tr>
	<tr>
		<td align="right">Woche</td>
		<td align="left">
			<select name="woche" size=1>
				<option value="immer">jede Woche</option>
				<option value="ungerade">ungerade Woche</option>
				<option value="gerade">gerade Woche</option>
			</select>
		</td>
	</tr>
	<tr>
		<td align="right">Einheit</td>
		<td align="left">
			<select name="einheit" size=1>
				<?php
					for ($i=1; $i<10; $i++)
						echo "<option value=\"$i\">$i</option>";
				?>
			</select>
		</td>
	</tr>
	<tr>
		<td align="right">Dauer</td>
		<td align="left">
			<select name="dauer" size=1>
				<?php
					for ($i=1; $i<10; $i++)
						echo "<option value=\"$i\">$i</option>";
				?>
			</select> Einheiten
		</td>
	</tr>
	<tr>
		<td colspan="2"><input type="radio" name="termin_auswahl" value="1"><b>Datumseingabe:</b>*</td>
	</tr>
	<tr>
		<td align="left" colspan="2">Beginn</td>
	</tr>
	<tr>
		<td align="left" colspan="2">
			<input type="text" name="btag" size="3" maxlenght="2">.
			<input type="text" name="bmonat" size="3" maxlenght="2">.
			<input type="text" name="bjahr" size="5" maxlenght="4">
			<input type="text" name="bstunde" size="3" maxlenght="2">:
			<input type="text" name="bminute" size="3" maxlenght="2">:
			<input type="text" name="bsekunde" size="3" maxlenght="2"> Uhr
		</td>
	</tr>
	<tr>
		<td align="left" colspan="2">Ende</td>
	</tr>
	<tr>
		<td align="left" colspan="2">
			<input type="text" name="etag" size="3" maxlenght="2">.
			<input type="text" name="emonat" size="3" maxlenght="2">.
			<input type="text" name="ejahr" size="5" maxlenght="4">
			<input type="text" name="estunde" size="3" maxlenght="2">:
			<input type="text" name="eminute" size="3" maxlenght="2">:
			<input type="text" name="esekunde" size="3" maxlenght="2"> Uhr
		</td>
	</tr>
	<tr>
		<td colspan="2" align="center"><input type="submit" name="Abschicken" value="next"></td>
	</tr>
	<tr>
		<td colspan="2" align="center">auf der n�chste Seite k�nnen Sie noch einen Termin eingeben!</td>
	</tr>
</table>
*) bitte ausw�hlen
</form>	
<?php
	}
}
?>