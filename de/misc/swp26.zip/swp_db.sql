-- MySQL dump 10.9
--
-- Host: mysql.hrz.tu-chemnitz.de    Database: swp_vlz
-- ------------------------------------------------------
-- Server version	4.1.20-standard-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fakultaet`
--

DROP TABLE IF EXISTS `fakultaet`;
CREATE TABLE `fakultaet` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(150) collate latin1_german1_ci NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

--
-- Dumping data for table `fakultaet`
--


/*!40000 ALTER TABLE `fakultaet` DISABLE KEYS */;
LOCK TABLES `fakultaet` WRITE;
INSERT INTO `fakultaet` VALUES (1,'Informatik'),(2,'Maschinenbau');
UNLOCK TABLES;
/*!40000 ALTER TABLE `fakultaet` ENABLE KEYS */;

--
-- Table structure for table `studiengang`
--

DROP TABLE IF EXISTS `studiengang`;
CREATE TABLE `studiengang` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(150) collate latin1_german1_ci NOT NULL default '',
  `fak_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

--
-- Dumping data for table `studiengang`
--


/*!40000 ALTER TABLE `studiengang` DISABLE KEYS */;
LOCK TABLES `studiengang` WRITE;
INSERT INTO `studiengang` VALUES (1,'AIF',1),(2,'IF',1);
UNLOCK TABLES;
/*!40000 ALTER TABLE `studiengang` ENABLE KEYS */;

--
-- Table structure for table `studiengang_vstg`
--

DROP TABLE IF EXISTS `studiengang_vstg`;
CREATE TABLE `studiengang_vstg` (
  `id` int(11) NOT NULL auto_increment,
  `studgang_id` int(10) NOT NULL default '0',
  `vstg_id` int(8) NOT NULL default '0',
  `sem` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

--
-- Dumping data for table `studiengang_vstg`
--


/*!40000 ALTER TABLE `studiengang_vstg` DISABLE KEYS */;
LOCK TABLES `studiengang_vstg` WRITE;
INSERT INTO `studiengang_vstg` VALUES (4,1,8,4),(2,1,5,4),(3,1,7,4),(6,1,9,4),(9,1,12,4);
UNLOCK TABLES;
/*!40000 ALTER TABLE `studiengang_vstg` ENABLE KEYS */;

--
-- Table structure for table `veranstaltung`
--

DROP TABLE IF EXISTS `veranstaltung`;
CREATE TABLE `veranstaltung` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(150) collate latin1_german1_ci NOT NULL default '',
  `fak` int(10) NOT NULL default '0',
  `prof` varchar(150) collate latin1_german1_ci NOT NULL default '',
  `inhalt` text collate latin1_german1_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

--
-- Dumping data for table `veranstaltung`
--


/*!40000 ALTER TABLE `veranstaltung` DISABLE KEYS */;
LOCK TABLES `veranstaltung` WRITE;
INSERT INTO `veranstaltung` VALUES (8,'Testveranstaltung',1,'Susi',''),(5,'Mahte IV',1,'Prof. Silbermann','Es geht um inhalte der Mathematik'),(7,'Medienapplikation',1,'Dr. Klamma','irgendwelcher mist'),(9,'test',1,'TEST',''),(12,'Test',1,'jsh','sdsa');
UNLOCK TABLES;
/*!40000 ALTER TABLE `veranstaltung` ENABLE KEYS */;

--
-- Table structure for table `veranstaltung_art`
--

DROP TABLE IF EXISTS `veranstaltung_art`;
CREATE TABLE `veranstaltung_art` (
  `id` int(11) NOT NULL auto_increment,
  `vstg_id` int(10) NOT NULL default '0',
  `art` enum('Vorlesung','Uebung','Praktikum','Seminar') collate latin1_german1_ci NOT NULL default 'Vorlesung',
  `sws` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

--
-- Dumping data for table `veranstaltung_art`
--


/*!40000 ALTER TABLE `veranstaltung_art` DISABLE KEYS */;
LOCK TABLES `veranstaltung_art` WRITE;
INSERT INTO `veranstaltung_art` VALUES (15,8,'Uebung',4),(14,8,'Vorlesung',3),(7,5,'Uebung',2),(6,5,'Vorlesung',2),(13,7,'Praktikum',2),(12,7,'Uebung',2),(11,7,'Vorlesung',2),(16,9,'Vorlesung',4),(23,12,'Praktikum',2),(21,12,'Vorlesung',2);
UNLOCK TABLES;
/*!40000 ALTER TABLE `veranstaltung_art` ENABLE KEYS */;

--
-- Table structure for table `veranstaltung_art_termine`
--

DROP TABLE IF EXISTS `veranstaltung_art_termine`;
CREATE TABLE `veranstaltung_art_termine` (
  `id` int(11) NOT NULL auto_increment,
  `vstg_art_id` int(10) NOT NULL default '0',
  `vstg_nr` int(8) NOT NULL default '0',
  `tag` enum('Mo','Di','Mi','Do','Fr') collate latin1_german1_ci NOT NULL default 'Mo',
  `woche` enum('immer','ungerade','gerade') collate latin1_german1_ci NOT NULL default 'immer',
  `einheit` int(1) NOT NULL default '0',
  `raum` varchar(5) collate latin1_german1_ci NOT NULL default '',
  `status` enum('standard','geaendert','gestrichen') collate latin1_german1_ci NOT NULL default 'standard',
  `dauer` int(1) NOT NULL default '0',
  `leiter` varchar(150) collate latin1_german1_ci NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

--
-- Dumping data for table `veranstaltung_art_termine`
--


/*!40000 ALTER TABLE `veranstaltung_art_termine` DISABLE KEYS */;
LOCK TABLES `veranstaltung_art_termine` WRITE;
INSERT INTO `veranstaltung_art_termine` VALUES (26,15,0,'Mo','immer',1,'','gestrichen',1,''),(21,14,111111,'Mo','immer',1,'111','standard',1,'me'),(22,14,111111,'Di','ungerade',1,'222','standard',1,'metoo'),(25,16,333333,'Mo','immer',0,'245','standard',0,'miche'),(11,6,225,'Mo','immer',3,'1/345','standard',1,'Prof. Silbermann'),(17,11,23645,'Mi','immer',3,'1/216','standard',1,'Dr. Klamma'),(12,7,22,'Do','immer',4,'2/543','standard',1,'Frau Rost'),(24,15,123456,'Fr','immer',2,'123','standard',1,'11'),(18,12,23646,'Mo','immer',3,'1/316','geaendert',1,'Hilbert'),(19,13,23647,'Fr','immer',4,'1/654','standard',2,'Hilbert'),(23,15,0,'Fr','immer',2,'','standard',1,''),(34,21,123445,'Di','ungerade',2,'1/223','standard',2,'Hr'),(35,22,12343,'Mo','immer',1,'23','standard',1,'4332');
UNLOCK TABLES;
/*!40000 ALTER TABLE `veranstaltung_art_termine` ENABLE KEYS */;

--
-- Table structure for table `veranstaltung_art_termine_ausnahmen`
--

DROP TABLE IF EXISTS `veranstaltung_art_termine_ausnahmen`;
CREATE TABLE `veranstaltung_art_termine_ausnahmen` (
  `id` int(11) NOT NULL auto_increment,
  `vstg_art_termine_id` int(10) NOT NULL default '0',
  `begin` int(14) default NULL,
  `ende` int(14) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

--
-- Dumping data for table `veranstaltung_art_termine_ausnahmen`
--


/*!40000 ALTER TABLE `veranstaltung_art_termine_ausnahmen` DISABLE KEYS */;
LOCK TABLES `veranstaltung_art_termine_ausnahmen` WRITE;
INSERT INTO `veranstaltung_art_termine_ausnahmen` VALUES (3,25,1088251200,1088262000);
UNLOCK TABLES;
/*!40000 ALTER TABLE `veranstaltung_art_termine_ausnahmen` ENABLE KEYS */;

--
-- Table structure for table `verwalter`
--

DROP TABLE IF EXISTS `verwalter`;
CREATE TABLE `verwalter` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) collate latin1_german1_ci NOT NULL default '',
  `passwort` varchar(50) collate latin1_german1_ci NOT NULL default '',
  `email` varchar(150) collate latin1_german1_ci NOT NULL default '',
  `status` enum('datenadmin','benutzeradmin','deaktiviert') collate latin1_german1_ci NOT NULL default 'datenadmin',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

--
-- Dumping data for table `verwalter`
--


/*!40000 ALTER TABLE `verwalter` DISABLE KEYS */;
LOCK TABLES `verwalter` WRITE;
INSERT INTO `verwalter` VALUES (1,'admin','d56b699830e77ba53855679cb1d252da','admin@tu-chemnitz.de','benutzeradmin'),(8,'marcel','47da6384bb76c5621f5b4137ffce0f76','shadow@shadow3d.de','benutzeradmin'),(19,'susi','d56b699830e77ba53855679cb1d252da','test@test.de','datenadmin'),(20,'WiWi','7e7780fb8365cf70448fa64bbf1b61d9','test@test.de','datenadmin'),(22,'noggi','274b23c0c05bf5ef629dc34e3ca928f7','mfri@hrz.tu-chemnitz.de','benutzeradmin');
UNLOCK TABLES;
/*!40000 ALTER TABLE `verwalter` ENABLE KEYS */;

--
-- Table structure for table `verwalter_rechte`
--

DROP TABLE IF EXISTS `verwalter_rechte`;
CREATE TABLE `verwalter_rechte` (
  `id` int(11) NOT NULL auto_increment,
  `benutzer_id` int(10) NOT NULL default '0',
  `fakultaet` int(2) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

--
-- Dumping data for table `verwalter_rechte`
--


/*!40000 ALTER TABLE `verwalter_rechte` DISABLE KEYS */;
LOCK TABLES `verwalter_rechte` WRITE;
INSERT INTO `verwalter_rechte` VALUES (24,20,1),(23,19,1),(27,19,2);
UNLOCK TABLES;
/*!40000 ALTER TABLE `verwalter_rechte` ENABLE KEYS */;

--
-- Table structure for table `warenkorb`
--

DROP TABLE IF EXISTS `warenkorb`;
CREATE TABLE `warenkorb` (
  `id` int(11) NOT NULL auto_increment,
  `sessionid` varchar(32) collate latin1_german1_ci NOT NULL default '',
  `vstg_art_termin_id` int(11) NOT NULL default '0',
  `time` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

--
-- Dumping data for table `warenkorb`
--


/*!40000 ALTER TABLE `warenkorb` DISABLE KEYS */;
LOCK TABLES `warenkorb` WRITE;
INSERT INTO `warenkorb` VALUES (275,'5dafe4dc577c5f2cfaf54031271440df',19,1086881502),(274,'5dafe4dc577c5f2cfaf54031271440df',18,1086881502),(273,'5dafe4dc577c5f2cfaf54031271440df',17,1086881502),(272,'5dafe4dc577c5f2cfaf54031271440df',6,1086881502),(271,'ae00265d79293b33419ac8a8edccbbe0',17,1086880627),(270,'ae00265d79293b33419ac8a8edccbbe0',12,1086880627),(268,'ae00265d79293b33419ac8a8edccbbe0',14,1086880627),(265,'89acf49a80afca0d2863c9180077fd24',16,1086877830),(266,'89acf49a80afca0d2863c9180077fd24',14,1086877830),(262,'89acf49a80afca0d2863c9180077fd24',12,1086877830),(269,'ae00265d79293b33419ac8a8edccbbe0',6,1086880627),(260,'89acf49a80afca0d2863c9180077fd24',6,1086877830),(259,'89acf49a80afca0d2863c9180077fd24',19,1086877830),(258,'89acf49a80afca0d2863c9180077fd24',17,1086877830),(256,'89acf49a80afca0d2863c9180077fd24',1,1086877830),(257,'89acf49a80afca0d2863c9180077fd24',11,1086877830),(276,'5dafe4dc577c5f2cfaf54031271440df',14,1086881502),(277,'5dafe4dc577c5f2cfaf54031271440df',2,1086881502),(278,'5dafe4dc577c5f2cfaf54031271440df',7,1086881502),(291,'c2a92829ed5587845a791721191a354a',11,1087292389),(292,'c2a92829ed5587845a791721191a354a',12,1087292389),(293,'c2a92829ed5587845a791721191a354a',17,1087292389),(294,'c2a92829ed5587845a791721191a354a',18,1087292389),(295,'c2a92829ed5587845a791721191a354a',19,1087292389),(299,'87a7c9b2e68f0f90a4b03dab30b2a8bc',12,1087340357),(297,'87a7c9b2e68f0f90a4b03dab30b2a8bc',19,1087340357),(373,'1018d8f1ade48efd95af15f57fb96db5',22,1089573630),(300,'87a7c9b2e68f0f90a4b03dab30b2a8bc',17,1087340357),(314,'4c6c3327fc9401c935196c3dd9020fe7',18,1089562136),(381,'07a406f08e3602ea1e0a3f8b1d37c779',21,1089887627),(372,'1018d8f1ade48efd95af15f57fb96db5',21,1089573630),(368,'3c5da030ea4d41df222b2598f69caeb9',18,1089568776),(369,'3c5da030ea4d41df222b2598f69caeb9',19,1089568776),(338,'78a042feab747c9d255a47063ea5d372',18,1089566953),(367,'3c5da030ea4d41df222b2598f69caeb9',17,1089568776),(336,'78a042feab747c9d255a47063ea5d372',21,1089566953),(337,'78a042feab747c9d255a47063ea5d372',17,1089566953),(382,'07a406f08e3602ea1e0a3f8b1d37c779',22,1089887627),(383,'07a406f08e3602ea1e0a3f8b1d37c779',24,1089887627),(427,'8b382873fcc981a531374796db74de6c',12,1089974992),(413,'d41c3df0e52400bcfd4a240d5a6939f6',11,1089927664),(401,'d41c3df0e52400bcfd4a240d5a6939f6',21,1089927664),(412,'d41c3df0e52400bcfd4a240d5a6939f6',28,1089927664),(426,'8b382873fcc981a531374796db74de6c',11,1089974992),(421,'ab9df654eadbd04320d99d3d0eefcaa2',11,1089928143),(422,'ab9df654eadbd04320d99d3d0eefcaa2',17,1089928143),(428,'8b382873fcc981a531374796db74de6c',17,1089974992),(431,'8b382873fcc981a531374796db74de6c',19,1089974992),(463,'fa1a57a59af84bfabafaaa8a857c286d',17,1130171137),(434,'2ffd47e0cd48d44080ed0c7bbf411a04',18,1112561593),(435,'2ffd47e0cd48d44080ed0c7bbf411a04',17,1112561593),(436,'2ffd47e0cd48d44080ed0c7bbf411a04',12,1112561593),(455,'1dbc0c97efc5074eaaf247a6c60cbf0c',24,1129624701),(453,'8cb2f56a584419bb46b640688e4beaec',21,1113481963),(456,'1dbc0c97efc5074eaaf247a6c60cbf0c',34,1129624701),(462,'fa1a57a59af84bfabafaaa8a857c286d',19,1130171137),(464,'fa1a57a59af84bfabafaaa8a857c286d',18,1130171137),(465,'d38243258ccf6830aeeb20085ae90569',12,1138864415),(466,'c7fcccc0a8f754c2e168294da37cde51',24,1138864434),(467,'fc80a3e4ac34c9fd233a438869e2e1b9',34,1138864440),(468,'f52a6fb079b496f23a3550091df8203e',18,1138864446),(469,'c5c7ab22fe2d7783616fbcf0183f16fc',21,1138864447),(470,'1880a8cde8860a3a8a285a3a1de833bc',19,1138864448),(471,'735b26fd71e3ac85cbb2e2a747675fb3',11,1138864452),(472,'fcb23c07b94ad642db3292408cb0bd6b',25,1138864457),(473,'77a3283634db28acfc68ba245115a636',22,1138864458),(474,'dfdd5c5657ddf9880c95703bbc8537e6',17,1138864459),(475,'d227744f60701c181ed240b6fb9623a0',26,1138864460),(476,'0185295a89cee232819cf75e48b36e21',23,1138869263),(477,'0ff22c4dedeff2c55e42ef1bf4252f99',23,1139819033),(478,'d6a9ba552e16e3d050d310cc17b73faf',19,1139947107),(479,'afe9b82210611d4e13eb55f59bfd6e8e',18,1140095938),(480,'10821834aae020bbef41b514a51c32c0',17,1140096066),(481,'9034fc8c3d8303a6ad0068cfd58b74b1',21,1140096487),(482,'94808f66b5b33a8251e41673409ccd86',34,1140097350),(483,'b5681848d1a35ff0a2b11c8d862e7bea',25,1140097605),(484,'1912ad58805cd0be269aaa17908c8ab4',26,1140128178),(485,'208acb608ffbfd32a8b1e8a087a05138',12,1140141676),(486,'1ed5028be46ff902fc5777326744080a',24,1140141683),(487,'eb5b076e3cb4ea89011da893eb4b559e',22,1140141723),(488,'3fa247e11b48390f3aeb77b9240ea407',11,1140147942),(489,'517707fec438f52d67eff53870212d8b',21,1140411291),(490,'a0a1813fa30bc4d8dcb361d138e88762',22,1141152414),(491,'84837f9782ba1788553f12fbd9b6df8e',19,1141154349),(492,'e048f4d113e83d939a8562f0f7eb92cd',34,1141154352),(493,'5cbe3d4eeafdb6128fc1accc50c7ed43',21,1141482910),(494,'744349fcaab1b086ead04629e3daf535',19,1141532238),(495,'2f3ae2679a5b82dd3a34860f3abc59fb',22,1141534102),(496,'90e091767750336b471af74646ce56c9',34,1141541255),(497,'42bced0d4d0f0e9277bec2fb0ffabf62',21,1142565967),(498,'9cc1e94c3e9d784bc2cc9b56b2fa3c3c',22,1143713472),(499,'4ab9d95b81e6d6bce1ed8b51708e19de',19,1143713484),(500,'3a53a490caafdb0825579d1fba947226',34,1143713537),(501,'e30ca6fe4ae09dc9e69ab216a1767020',21,1145707376),(502,'f19cd7015f30b2f44749427802c6fecc',19,1146749812),(503,'83728204ad29d1634bad7f75d7080639',22,1146751538),(504,'fc1bbfc1aa0d4bcd40c835abc25c6937',34,1146753399),(505,'892787497494e6c101ebb912b8107a0c',21,1148549034),(506,'5381908f3ff692255530fb186b4f9a5e',19,1148556458),(507,'9e84c5375c3f37c8cffe098f53bddcdb',34,1148556559),(508,'7abff1623cd32c6cc57b1e21bcc31c2b',22,1148556585),(509,'9d01cf4043ef0cf4cc49b642906e495c',34,1150440977),(510,'944993aed963ef59e3c41502eef47992',19,1150441042),(511,'fbf3a55636f52123d6fc1bc9b4369918',22,1150444411),(512,'55d0c145fb8ca22e685a9d274350f5cb',22,1150698479),(513,'75af1cbc0c47581a3af60aeb3142aece',19,1150698481),(514,'d36332a84a3ca8e5c22793f2232d023f',34,1150698541),(515,'c49e32e24268999da61a5ae4374c0503',11,1153371884),(516,'d58395473d346cd84fdbb1732442912b',11,1156430105),(517,'0f8e2415234171d28cd3911b572e19fd',11,1156466097),(518,'529a8610adfc19d7e9d2273045531083',21,1156728155),(519,'bd6bf42936b323b19c5ab90fabb6164e',11,1157521228),(520,'0356f4174894bc3144d42b5118e17b6f',11,1158403402),(521,'7b3dfbe302f7ca971f5f746a39a2cd6c',11,1159293228),(522,'ddf95f2cd82ef1a528d0e9c85781fa5b',11,1161707841),(523,'2ff4afc595dec543d89a6e083ea09a30',21,1163212016),(524,'374753bc8de87cee24ad16f8cf1a978d',11,1166489280),(525,'60b499d80c9477fc3e77dfbfcc742941',11,1166511222),(526,'c1f5e7cbef46e884561d1f1f200f6d96',21,1171465813),(527,'1e9efc2d00b973f16e243bde98177de0',11,1174693596),(528,'4f4fe8c26f65a1b392df38610ce28802',17,1176276488),(529,'50f5c6bff3e3d47ce481aefc8aa2b80d',17,1178683337),(532,'191113cbd7686d88cc93cd379e22b813',26,1179769710),(531,'191113cbd7686d88cc93cd379e22b813',17,1179769710),(533,'191113cbd7686d88cc93cd379e22b813',23,1179769710),(534,'86e07d83e55f25e5b71755137ee457cd',21,1181100205),(535,'c2f9fe9fa3089264e793877c8ebab20b',21,1184463349),(536,'f985aea122b01915f3da5b13728e4929',11,1184472248);
UNLOCK TABLES;
/*!40000 ALTER TABLE `warenkorb` ENABLE KEYS */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

