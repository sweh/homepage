/***************************************************************************
    begin       : Thu Jul 02 2009
    copyright   : (C) 2009 by Martin Preuss
    email       : martin@libchipcard.de

 ***************************************************************************
 *          Please see toplevel file COPYING for license details           *
 ***************************************************************************/



#ifndef TYPEMAKER2_BUILDER_C_H
#define TYPEMAKER2_BUILDER_C_H


#include "tm_builder.h"


TYPEMAKER2_BUILDER *Typemaker2_Builder_C_new();



#endif




